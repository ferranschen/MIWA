
//function to get a selector matrix for an element
//input: web element
//output: selector matrix
function getSelectorMatrix(documentWhichElementBelongsTo, element) {
    if(typeof element === 'string'){
        element = getElementByXpath(documentWhichElementBelongsTo, element)
    }
    let parentList = []
    for(let cur = element; cur && cur.nodeType === Node.ELEMENT_NODE; cur = cur.parentNode){
        parentList.unshift(cur)
    }
    let dependenceMatrix = createArray(parentList.length, parentList.length)
    for(let i = 0; i < parentList.length; ++i){
        for(let j = i+1; j < parentList.length; ++j){
            dependenceMatrix[i][j] = getSelectorGivenParentAndChildren(documentWhichElementBelongsTo, parentList[i],parentList[j])
        }
    }
    dependenceMatrix[0][1] = ["//body"]

    return dependenceMatrix
}


function getSelectorGivenParentAndChildren(documentWhichElementBelongsTo, parent, children)
{
    let selectors = []
    //this is special case when parent is the direct parent of the children element
    if(parent && children && (parent === children.parentNode)){
        let attributeList = attributesFilter(children)
        for(let attribute of attributeList){
            if(attribute.nodeName === "_tag"){
                let query = "/"+attribute.nodeValue
                let index = matchElementInSnapshot(children, getElementsByXpath(documentWhichElementBelongsTo, query,parent))
                selectors.push(index === -1?query:query+"["+index+"]")
                continue
            }
            if(attribute.nodeName === "_text"){
                let query = "/"+children.tagName.toLowerCase() + "[text()='" +attribute.nodeValue + "']"
                let index = matchElementInSnapshot(children, getElementsByXpath(documentWhichElementBelongsTo, query,parent))
                selectors.push(index === -1?query:query+"["+index+"]")
                continue
            }
            let query = "/"+children.tagName.toLowerCase() + "[@"+attribute.nodeName + "='" +attribute.nodeValue + "']"
            let index = matchElementInSnapshot(children, getElementsByXpath(documentWhichElementBelongsTo, query,parent))
            selectors.push(index === -1?query:query+"["+index+"]")
        }
    }
    else if(children && parent)
    {
        let attributeList = attributesFilter(children)
        for(let attribute of attributeList){
            if(attribute.nodeName === "_tag"){
                let query = "//"+attribute.nodeValue
                let index = matchElementInSnapshot(children, getElementsByXpath(documentWhichElementBelongsTo, query,parent))
                selectors.push(index === -1?query:query+"["+index+"]")
                continue
            }
            if(attribute.nodeName === "_text"){
                let query = "//"+children.tagName.toLowerCase() + "[text()='" +attribute.nodeValue + "']"
                let index = matchElementInSnapshot(children, getElementsByXpath(documentWhichElementBelongsTo, query,parent))
                selectors.push(index === -1?query:query+"["+index+"]")
                continue
            }
            let query = "//"+children.tagName.toLowerCase() + "[@"+attribute.nodeName + "='" +attribute.nodeValue + "']"
            let index = matchElementInSnapshot(children, getElementsByXpath(documentWhichElementBelongsTo, query,parent))
            selectors.push(index === -1?query:query+"["+index+"]")
        }
    }
    else{
        console.log(parent)
        console.log(children)
    }


    return selectors
}

function matchElementInSnapshot(element, snapshot){
    if(snapshot.snapshotLength === 1){
        return -1
    }
    for(let i = 0; i < snapshot.snapshotLength; ++i){
        if(snapshot.snapshotItem(i) === element){
            return i+1
        }
    }
    return -2;
}

//given an element, return the usable attributes for that element
function attributesFilter(element){
    let result = []
    let whiteList = ["class", "id", "name", "title", "value", "item", "item-prop" ]
    for(let att of element.attributes){
        if(att.nodeValue === ""){
            continue
        }
        if(whiteList.includes(att.nodeName) || att.nodeName.indexOf("aria") !== -1 || att.nodeName.indexOf("data")!== -1){
            if(att.nodeValue.length < 40 && att.nodeValue.indexOf("{") === -1 && att.nodeValue.indexOf("}") === -1
                && att.nodeValue.indexOf("(") === -1
                && att.nodeValue.indexOf(")") === -1){
                result.push({"nodeName":att.nodeName, "nodeValue":att.nodeValue })
            }

        }
    }
    //  if(element.text && element.text !== ""){
    //     result.push({"nodeName":"_text","nodeValue":element.text })
    // }
    result.push({"nodeName":"_tag", "nodeValue":element.tagName.toLowerCase()})
    return result
}

function createArray(length) {
    let arr = new Array(length || 0),
        i = length;

    if (arguments.length > 1) {
        let args = Array.prototype.slice.call(arguments, 1);
        while(i--) arr[length-1 - i] = createArray.apply(this, args);
    }

    return arr;
}

function mergeTwoSelectorResults(parentSelectors,childrenSelectors){
    let result = []
    for(let itemParent of parentSelectors){
        for(let itemChildren of childrenSelectors){
            result.push(itemParent.concat(itemChildren))
        }
    }
    return result
}