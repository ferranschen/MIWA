class DOMNode {
    nodePartList= []

    static constructFromString(domNodeString){
        let tmp = new DOMNode()
        let dividedArray = domNodeString.split("/")
        for(let i = 1; i < dividedArray.length; ++i){
            if(dividedArray[i] === ""){
                tmp.nodePartList.push(DOMNodePartPredicate.constructFromString(dividedArray[i+1],PredicateSearchType.Descendant))
                i = i+1
            }
            else{
                tmp.nodePartList.push(DOMNodePartPredicate.constructFromString(dividedArray[i],PredicateSearchType.Child))
            }
        }
        return tmp
    }

    toString(){
        let result = ""
        for(let nodePart of this.nodePartList){
            if(nodePart instanceof DOMNodePartPredicate){
                if(nodePart.searchType === PredicateSearchType.Child){
                    result += "/"
                }
                if(nodePart.searchType === PredicateSearchType.Descendant){
                    result += "//"
                }
                result += nodePart.predicate.toString() + (nodePart.index === 0? "" : ("[" + nodePart.index + "]"))
            }
        }
        return result
    }


}
class DOMNodePartPredicate{
    searchType
    index = 0
    predicate

    constructor(searchType, index, predicate) {
        this.searchType = searchType
        this.index = index
        this.predicate = predicate
    }

    static constructFromString(str,searchType){
        //there are following kinds of DOMNodePartPredicate:
        //p -- case I
        //p[1] -- case II
        //p[@attribute=name] -- case III
        //p[@attribute=name][2] -- case IV
        let firstBracketLeftDividerIndex = str.indexOf("[")
        let firstBracketRightDividerIndex = str.indexOf("]")
        let secondBracketLeftDividerIndex = str.lastIndexOf("[")
        let secondBracketRightDividerIndex = str.lastIndexOf("]")

        if(firstBracketLeftDividerIndex === -1){
            //case I
            return new DOMNodePartPredicate(searchType,0,new PredicateConst(str, "", ""))
        }
        if(firstBracketLeftDividerIndex !== -1 && secondBracketLeftDividerIndex !== -1 && firstBracketLeftDividerIndex !== secondBracketLeftDividerIndex){
            //case IV
            let equalSignDividerIndex = str.indexOf("=")
            let tagName = str.substring(0,firstBracketLeftDividerIndex)
            let predicateName = str.substring(firstBracketLeftDividerIndex+1,equalSignDividerIndex)
            let predicateValue = str.substring(equalSignDividerIndex+1,firstBracketRightDividerIndex)
            let index = parseInt(str.substring(secondBracketLeftDividerIndex+1,secondBracketRightDividerIndex))
            return new DOMNodePartPredicate(searchType, index,new PredicateConst(tagName, predicateName, predicateValue))
        }
        if(firstBracketLeftDividerIndex !== -1 && firstBracketLeftDividerIndex === secondBracketLeftDividerIndex){
            let tagName = str.substring(0,firstBracketLeftDividerIndex)
            let numberToParse = parseInt(str.substring(firstBracketLeftDividerIndex+1,firstBracketRightDividerIndex))
            if(Number.isNaN(numberToParse)){
                //case III
                let equalSignDividerIndex = str.indexOf("=")
                let predicateName = str.substring(firstBracketLeftDividerIndex+1,equalSignDividerIndex)
                let predicateValue = str.substring(equalSignDividerIndex+1,firstBracketRightDividerIndex)
                let index = 0
                return new DOMNodePartPredicate(searchType, index,new PredicateConst(tagName, predicateName, predicateValue))
            }
            else{
                //case II
                return new DOMNodePartPredicate(searchType, numberToParse,new PredicateConst(tagName, "", ""))
            }
        }
        throw "shouldn't reach here"
    }

    static constructFromStringWithSearchType(str)
    {
        if(str.length < 2){
            throw "Shouldn't reach here - too short to construct. Trying to construct DOMNodePart with string " + str
        }

        if(str[1] !== '/'){
            return DOMNodePartPredicate.constructFromString(str.substring(1),PredicateSearchType.Child)
        }
        if(str[1] === '/'){
            return DOMNodePartPredicate.constructFromString(str.substring(2),PredicateSearchType.Descendant)
        }

        throw "Shouldn't reach here - should covered all cases"

    }


    toString(){
        let result = ""
        if(this.searchType === PredicateSearchType.Child){
            result += "/"
        }
        if(this.searchType === PredicateSearchType.Descendant){
            result += "//"
        }
        result += this.predicate.toString() + (this.index === 0? "" : ("[" + this.index + "]"))
        return result
    }
}
class PredicateConst{
    _attributeValue= ""
    tagName
    attributeName=""
    constructor(tagName, attributeName, attributeValue) {
        this.tagName = tagName
        this.attributeName = attributeName
        this._attributeValue = attributeValue
    }
    getAttributeValue(){
        return this._attributeValue
    }

    toString(){
        if(this.attributeName === ""){
            return this.tagName
        }
        else{
            return this.tagName + "[" + this.attributeName + "=" + this._attributeValue.toString() + "]"
        }
    }
}

const PredicateSearchType = {
    Child:0,
        Descendant:1,
        Root:2
}

function getElementsByXpath(doc,xpath, parentNode){
    return doc.evaluate("."+xpath, parentNode, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
}
// function getElementByXpath(doc,xpath_expression) {
//     return doc.evaluate(xpath_expression, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue
// }
function getElementByXpath(doc, xpath_expression) {
    console.log("debug findding by " + xpath_expression)
    let target = DOMNode.constructFromString(xpath_expression)
    console.log("debug constructed DOMNode")
    console.log(target)
    //recover xpath to DOMNode
    let currentNode= doc
    for(let node of target.nodePartList){
        if(node instanceof DOMNodePartPredicate){
            let queryString = ""
            if(node.searchType === PredicateSearchType.Descendant)
            {
                queryString += "//"
            }
            else if(node.searchType === PredicateSearchType.Child)
            {
                queryString += "/"
            }
            queryString += node.predicate.tagName
            if(node.predicate.attributeName !== ""){
                queryString += "[" + node.predicate.attributeName + "=" + node.predicate.getAttributeValue() +"]"
            }

            let snapshots = getElementsByXpath(doc, queryString,currentNode)
            if(snapshots.snapshotLength === 0){
                console.log("evaluated failed - 1.")
                return null
            }
            if(node.index === 0 || node.index === 1){
                if(snapshots.snapshotLength >= 1){
                    let tmp = snapshots.snapshotItem(0)
                    if(tmp){
                        currentNode = tmp
                    }
                    continue
                }
                else{
                    console.log("evaluated failed - 2.")
                    return null
                }
            }else if(node.index > 1){
                if(snapshots.snapshotLength >= node.index){
                    let tmp = snapshots.snapshotItem(node.index-1)
                    if(tmp) {
                        currentNode = tmp
                    }
                    continue
                }
                else{
                    console.log("evaluated failed - 3.")
                    return null
                }
            }
            else{
                throw "negative index in getElementByXpath. xpath expression is " + xpath_expression +" and recovered DOMNode is " + target
            }
            return null

        }
        else{
            throw "Shouldn't get there - not constant predicates parameter passed to valid function "
        }
    }
    console.log("evaluated successfully.")
    return currentNode
}