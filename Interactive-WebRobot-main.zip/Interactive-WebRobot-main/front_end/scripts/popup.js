// --------------------------------------- Action_Output Panel ---------------------------------------
var index = 1;
let scrapeText = document.getElementById("actionScrapeText");
let scrapeURL = document.getElementById("actionScrapeURL");
let scrapeLink = document.getElementById("actionScrapeLink");
let download = document.getElementById("actionDownload");
let outputTable = document.getElementById("outputTable");
let normal = document.getElementById("actionNormal");
let manualBack = document.getElementById("backManualBtn");
// let showPred = document.getElementById("predictionShowBtn");

var colNum = 1;
var curCol = 0;

$(".actionButton").hover(
    function() {
      $( this ).find("span").first().css("display", "none");
      $( this ).find( "span" ).last().fadeIn();
    }, function() {
      $( this ).find( "span" ).first().fadeIn();
      $( this ).find("span").last().css("display", "none");
    }
);

$(document).ready(function () {
  if ($("[data-toggle=tooltip]").length) {
  $("[data-toggle=tooltip]").tooltip();
  }
});

function executeShowPred() {
    chrome.runtime.sendMessage({ "action": "manualShowPrediction" }, (response) => {
    });
}
// showPred.addEventListener("click", executeShowPred);
var selecting = false;

function waitForSelecting() {
    selecting = true;
    let buttons = document.getElementsByTagName("button");
    var i;
    for (i = 0; i < buttons.length; i++) {
    if (buttons[i].id !== "inputJsonTab"
        && buttons[i].id !== "actionNormal"
        && buttons[i].id !== "backManualBtn"
        && buttons[i].id !== "predictionShowBtn") {
      buttons[i].disabled = true;
      buttons[i].classList.add("disabled")
    }
    }
    let reminder = document.getElementById("actionReminder");
    reminder.style.visibility = "visible";
}

function finishSelecting() {
  selecting = false;
  let buttons = document.getElementsByTagName("button");
  var i;
  for (i = 0; i < buttons.length; i++) {
    buttons[i].disabled = false;
    buttons[i].classList.remove("disabled")

  }
  let reminder = document.getElementById("actionReminder");
  reminder.style.visibility = "hidden";
}

function addOutput(output) {
    let row = null;
    if (curCol == 0) {
        row = outputTable.insertRow(index);
        let c = row.insertCell(curCol);
        c.innerHTML = index;
        index += 1;
    }
    else {
        row = outputTable.rows[ outputTable.rows.length - 1 ]
    }

    let cell = row.insertCell(curCol+1);
    curCol++;
    if (curCol == colNum) {
        curCol = 0;
    }

    let outlength = 70;
    let outputTextDiv = document.createElement("div");
    if (output.length > outlength) {
        let prev = output.substring(0, outlength);
        let readMore = document.createElement("span");
        readMore.innerHTML = " Read more"
        readMore.style.display = "inline"
        readMore.classList.add("btn", "btn-link")
        let readLess = document.createElement("span");
        readLess.innerHTML = " Read less"
        readLess.style.display = "none"
        readLess.classList.add("btn", "btn-link")
        let nextDiv = document.createElement("span")
        nextDiv.innerHTML = output
        nextDiv.style.display = "none"
        let prevDiv = document.createElement("span")
        prevDiv.innerHTML = prev

        console.log(prevDiv.innerHTML);
        curLength = outlength + 100
        while (prevDiv.innerHTML === "") {
            prevDiv.innerHTML = output.substring(0, curLength);
            curLength += 100
        }

        if (output.substring(0, curLength) === output) {
            readMore.style.display = "none"
        }

        readMore.addEventListener("click", function() {
            readMore.style.display = "none"
            prevDiv.style.display = "none"
            nextDiv.style.display = "inline"
            readLess.style.display = "inline"
        })
        readLess.addEventListener("click", function() {
            readMore.style.display = "inline"
            prevDiv.style.display = "inline"
            nextDiv.style.display = "none"
            readLess.style.display = "none"
        })
        outputTextDiv.appendChild(prevDiv)
        outputTextDiv.appendChild(readMore)
        outputTextDiv.appendChild(nextDiv)
        outputTextDiv.appendChild(readLess)
        console.log(outputTextDiv);
    }
    else {
        outputTextDiv.innerHTML = output
    }
    cell.appendChild(outputTextDiv)
    // cell.innerHTML = output;
    // cell.setAttribute("class","overflow-auto")
    // row.scrollIntoView();
}

function setOutput() {
    let row = outputTable.insertRow(0);
    let cell = row.insertCell(0);
    cell.innerHTML = "#"
    cell.width = "10%";
    for(let i=0;i<colNum;i++) {
        cell = row.insertCell(i+1);
        cell.innerHTML = "column "+(i+1)
    }
}

function clickURL() {
  chrome.runtime.sendMessage({ "action": "scrapeUrlMode" }, (response) => {
    addOutput(response);
  });
}

function clickText() {
  scrapeText.classList.add("action");
  chrome.runtime.sendMessage({ "action": "scrapeTextMode" }, (response) => { });
  waitForSelecting();
}

function clickLink() {
  scrapeLink.classList.add("action");
  chrome.runtime.sendMessage({ "action": "scrapeLinkMode" }, (response) => { });
  waitForSelecting();
}

function clickDownload() {
  download.classList.add("action");
  chrome.runtime.sendMessage({ "action": "downloadMode" }, (response) => { });
  waitForSelecting();
}

function normalHandler() {
  chrome.runtime.sendMessage({ "action": "normalMode" }, (response) => { });
  scrapeText.classList.remove("action");
  scrapeLink.classList.remove("action");
  download.classList.remove("action");
  finishSelecting();
}

function manualBackHandler() {
  chrome.runtime.sendMessage({ "action": "manualBackMode" }, (response) => { });
  scrapeText.classList.remove("action");
  scrapeLink.classList.remove("action");
  download.classList.remove("action");
  finishSelecting();
}

scrapeURL.addEventListener("click", clickURL);
scrapeText.addEventListener("click", clickText);
scrapeLink.addEventListener("click", clickLink);
download.addEventListener("click", clickDownload);
normal.addEventListener("click", normalHandler);
manualBack.addEventListener("click", manualBackHandler);

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action == "output") {
    finishSelecting();
    if (request.output != null) {
      addOutput(request.output);
    }
    waitForSelecting();
  }
});

// --------------------------------------- Input Panel ---------------------------------------
var inputJsons = [];
var inputJsonsNames = [];
// Generate a leaf node
function generateJsonLeaf(inputFileName, key, text) {
    console.log(key+" "+text);
  let leaf = document.createElement("button");
  leaf.classList.add("btn", "btn-secondary", "jsonLeaf");
  leaf.setAttribute("key", key);
  leaf.value = text;
  leaf.textContent = text;
  leaf.draggable = true;
  // Adds data to drag start for input boxes to receive the data
  leaf.addEventListener("dragstart", (event) => {
    // console.log("drag starts");
    // console.log(leaf);
    let sendData = {inputfilename: inputFileName,key: key , value: leaf.value};
    console.log(sendData);
    event.dataTransfer.setData("text/plain", JSON.stringify(sendData));
  });
  return leaf;
}

// Recursively generate the tree in the form of a table
function generateJsonTable(inputFileName, jsonObj, prevKey, objIsArray) {
  let keys = Object.keys(jsonObj);
  let tbl = document.createElement("table");
  tbl.classList.add("table", "table-bordered", "align-middle", "mb-0");
  let tbody = document.createElement("tbody");
  tbody.classList.add("align-middle");
  // tbl.classList =
  keys.forEach((key) => {
    let row = document.createElement("tr");
    let keyCell = document.createElement("th");
    keyCell.classList.add("clickable");
    keyCell.value = key;
    keyCell.appendChild(document.createTextNode(parseInt(key)+1));
    row.appendChild(keyCell);
    // the td cell itself is clickable
    let valCell = document.createElement("td");
    valCell.classList.add("align-middle");
    console.log(key);
    console.log(Array.isArray(jsonObj[key]));
    let tempKey = key;
    if (prevKey !== "") {
        tempKey = prevKey+"."+key;
    }
    if (objIsArray) {
        tempKey = prevKey+"["+key+"]";
    }
    if (typeof jsonObj[key] == "object") {
      // recursively call function
      valCell.appendChild(generateJsonTable(inputFileName, jsonObj[key], tempKey, Array.isArray(jsonObj[key])));
    } else {
      valCell.classList.add("clickable");
      valCell.value = jsonObj[key];
      let leaf = generateJsonLeaf(inputFileName, tempKey, jsonObj[key]);
      valCell.appendChild(leaf);
    }
    row.appendChild(valCell);
    tbody.appendChild(row);
  });
  tbl.appendChild(tbody);
  return tbl;
}

// create the first level table
function createJsonTable(inputFileName, jsonRead) {
  const jsonTableDiv = document.createElement("div");
  jsonTableDiv.setAttribute("id", "inputJson");
  jsonTableDiv.classList.add("row", "d-flex", "justify-content-center", "mb-3");
  let k = Object.keys(jsonRead)[0];
  jsonTableDiv.appendChild(generateJsonTable(inputFileName, jsonRead[k], k, Array.isArray(jsonRead[k]) ));
  return jsonTableDiv;
}

function makeClickable() {
  // make the JSON clickable
  let elements = document.getElementsByClassName("clickable");
  for (let i = 0; i < elements.length; i++) {
    elements[i].addEventListener("click", (event) => {
      let value = event.target.value;
      // alert(value);
    });
  }
}

// To delete any existing JSON buttons
function deleteOldJsonTable() {
  const buttonsDiv = document.createElement("div");
  buttonsDiv.setAttribute("id", "jsonButtons");
}

const jsonSubmitButton = document.getElementById("inputJsonSubmitButton");
function markButtonSuccess() {
  jsonSubmitButton.classList.replace("btn-primary", "btn-success");
  jsonSubmitButton.classList.replace("btn-danger", "btn-success");
  jsonSubmitButton.value = "Success";
}

function markButtonFailure() {
  jsonSubmitButton.classList.replace("btn-primary", "btn-danger");
  // jsonSubmitButton.classList.replace("btn-success", "btn-danger");
  jsonSubmitButton.value = "Failure";
}

// Upon loading the window, add an event listener?
jsonSubmitButton.addEventListener("click", function () {
  let fr = new FileReader();
  var inputFileName = "";
  fr.onload = (readerEvt) => {
    try {
      let jsonRead = JSON.parse(String(fr.result));//// TODO:
      chrome.runtime.sendMessage({ "action": "setJson", "json": jsonRead })
      inputJsons.push(jsonRead);
      inputJsonsNames.push(inputFileName);
      let inputContainer = document.getElementById("inputContainer")
      inputContainer.style.maxHeight = "120px";
      // document.getElementById('input_submitStatus').textContent = 'Submitted!!!';

      // check if buttonsTest div already exists, if yes delete it
      // deleteOldJsonTable();

      // create new tab for json table
      let oldTable = document.getElementById("inputJson");
      if (oldTable) {
          // removeJsonInputActive();
          // showOuputActive();
          // let oldPanel = document.getElementById("inputOutput");
          // oldPanel.setAttribute("class", "active");
          let jsonTableDiv = createJsonTable(inputFileName, jsonRead);
          oldTable.parentNode.replaceChild(jsonTableDiv,oldTable);
      }
      else {
          let inputTableDivName = createNewTabwContent("JSON Output");
          // create buttons Div for json table
          let jsonTableDiv = createJsonTable(inputFileName, jsonRead);
          // let textOutput = document.getElementById('input_outputTitle');
          let parentDiv = document.getElementById(inputTableDivName);
          parentDiv.appendChild(jsonTableDiv);
          // display original file content as text
          // document.getElementById('input_output').textContent=String(fr.result);
      }


      // markButtonSuccess();
      makeClickable();
    } catch (e) {
      console.log(e);
      markButtonFailure();
      alert(e);
    }
  };

  let jsonFile = document.getElementById('inputJsonFile');
  if (typeof jsonFile.files[0] == "undefined") {
    alert("Empty!! Please choose a file!");
  } else {
    fr.readAsText(jsonFile.files[0]);
    inputFileName = jsonFile.files[0].name;
  }
});

// --------------------------------------- Prediction Panel ---------------------------------------
// let predictionGetter = document.getElementById("prediction_getter");
// let predictionAcceptBtn = document.getElementById("prediction_accept");
// let predictionRejectBtn = document.getElementById("prediction_reject");
let scrapedResult = null;

function highlightElement(ele) {
  ele.classList.add("suggestion");
}

function disableHighlight(ele) {
  ele.classList.remove("suggestion");
}

// to replace the "click for prediction" model
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "prediction") {
    //suggestionJSON = request.suggestionJSON;
    console.log("received suggestion/prediction")
    let predictionPrompt = document.getElementById("predictionPrompt");
    //suggestion = JSON.parse(suggestionJSON);
    suggestion = request.suggestion
    type = suggestion.type;
    console.log("prediction: " + suggestion.type);
    console.log("prediction url/text: " + suggestion.msg);
    switch (type) {
      case "Click":
        predictionPrompt.textContent =
          "Do you want to click the highlighted element?";
        break;
      case "SendKeys":
        predictionPrompt.textContent =
          "Do you want to enter these keystrokes in the highlighted element?";
        break;
      case "ScrapeText":
        predictionPrompt.textContent =
          "Do you want to scrape the highlighted text?";
        scrapedResult = suggestion.msg;
        document.getElementById("predictionPromptMsg").textContent =
          suggestion.msg;
        break;
      case "ScrapeURL":
        predictionPrompt.textContent =
          "Do you want to scrape the current URL?";
        scrapedResult = suggestion.msg;
        if (suggestion.msg.length > 50) {
          document.getElementById("predictionPromptMsg").textContent =
            suggestion.msg.substring(0, 50) + "...";
        } else {
          document.getElementById("predictionPromptMsg").textContent =
            suggestion.msg;
        }
        break;
      case "GoBack":
        predictionPrompt.textContent =
          "Do you want to go back to the previous page?";
        break;
      default:
        console.log("unsupported type of suggestion.");
        break;
    }
  }
  else if (request.action === "disableActions"){
    console.log("disabling actions")
    $(".glyphicon").css("display", "inline-block");
    $(".description").css("display", "none");
    scrapeText.classList.remove("action");
    scrapeLink.classList.remove("action");
    download.classList.remove("action");

    let buttons = document.getElementsByTagName("button");
    var i;

    console.log("num buttons = "+buttons.length)
    console.log(request.SendData, request.key);
    for (i = 0; i < buttons.length; i++) {
        console.log(buttons[i].getAttribute("key"), request.key, buttons[i].getAttribute("key") === request.key);
      if (buttons[i].id === "input-jsonSubmitButton" ||
        // buttons[i].id === "prediction_accept" ||
        // buttons[i].id === "prediction_reject" ||
        buttons[i].id === "backManualBtn" ||
        buttons[i].id === "predictionShowBtn") {
        console.log("pass "+buttons[i].id)
    } else {
        if (request.SendData && buttons[i].getAttribute("key") == request.key) {
            console.log("scrollIntoView");
            buttons[i].scrollIntoView({
              behavior: "auto",
              block: "center",
              inline: "center",
            });
            buttons[i].classList.add("suggestion");
        }
        else {
            buttons[i].classList.add("disabled");
            buttons[i].classList.remove("suggestion");
        }
        buttons[i].disabled = true;
      }
    }

    let manualBackBtn = document.getElementById("backManualBtn");
    manualBackBtn.classList.add("predictionMode");
    let predictionShowBtn = document.getElementById("predictionShowBtn");
    predictionShowBtn.classList.add("predictionMode");
  }
  else if (request.action === "enableActions"){
    // default to normal mode
    console.log("enabling actions")
    finishSelecting();
    let manualBackBtn = document.getElementById("backManualBtn");
    manualBackBtn.classList.remove("predictionMode");
    let predictionShowBtn = document.getElementById("predictionShowBtn");
    predictionShowBtn.classList.remove("predictionMode");
  }

});

// --------------------------------------- Recorder ---------------------------------------
var app = new Vue({
  el: '#app',
  data: {
    recordState: false,
    isSaving: false,
    traceName: "trace"
  },

  methods: {
    recordBtnClick: function () {
      console.log("recordBtnClick");
      chrome.runtime.sendMessage({ "action": "getRecordingState" }, (response) => {
        if (response) {
          console.log("response true");
          //if the current state is recording, then the user wants to download the trace file. Generate a zip and download
          chrome.runtime.sendMessage({ "action": "stopRecording" })
          this.downloadTrace()
        } else {
          console.log("response false");
          //here we start recording
          // this.traceName = prompt("Please enter the trace name:")
          // colNum = prompt("Please enter number of output columns:")
          this.traceName = "test";
          colNum = 1;
          if (colNum == 0 || colNum == undefined || colNum == null) {
              colNum = 1;
          }
          setOutput();
          chrome.runtime.sendMessage({ "action": "setTraceName", "traceName": this.traceName })
          chrome.runtime.sendMessage({ "action": "startRecording" })
        }
        this.recordState = !response
      })
    },

    downloadTrace: function () {
      console.log("download trace");
      // console.log(inputJsons);
      //export trace from storage
      let trace = {
        "actions": [],
        "doms": [],
        "numberActions": 0,
        "name": "trace"
      }
      console.log("getActionList getDomList");

      //note: due to the async programming, there is a callback hell. Better to optimize it later.
      chrome.runtime.sendMessage({ "action": "getActionList" }, (actionList) => {
        chrome.runtime.sendMessage({ "action": "getDomList" }, (domList) => {
          console.log(actionList);
          console.log(domList);
          let zip = new JSZip()
          let JsonOutputFolder = zip.folder("JSONs")
          for (let i=0;i<inputJsons.length;i++) {
              JsonOutputFolder.file(inputJsonsNames[i], JSON.stringify(inputJsons[i]))
          }
          let domOutputFolder = zip.folder("doms")
          let i = 0
          let j = 0
          //export actions and doms
          for (const action of actionList) {
            let actionAsString = action.actionName + " " + action.parameters.join(" ")
            trace.actions.push(actionAsString)
            trace.doms.push(i + ".html")
            domOutputFolder.file(i + ".html", domList[j])
            if (action.actionName !== "GoBack") {
              domOutputFolder.file(i + ".html", domList[j])
              j += 1
            }
            else {
              domOutputFolder.file(i + ".html", domList[j - 1])
            }

            i += 1
          }
          //export parameters
          trace.numberActions = actionList.length
          trace.name = this.traceName

          //export current dom
          function scrapeThePage() {
            return document.documentElement.innerHTML;
          }
          chrome.runtime.sendMessage({ "action": "clear" })
        })

      })


    }
  },

  created: function () {
    //initialize record state
    chrome.runtime.sendMessage({ "action": "getTraceName" }, (response) => {
      this.traceName = response
    })
  }


})