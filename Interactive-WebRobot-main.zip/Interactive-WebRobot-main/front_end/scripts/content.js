var isLoaded = true;
// var currMode = null;
var recordStarted = false;
var isUpdate = false;
var isInsert = false;
var visualizeElements = [];
var highlightElements = [];
var visualize_status = false;
var semi = false;
var scrapeSuggestion = null;
var scrapeElement = null;
var scrapeParameters = [];

function highlightElement(event) {
  if (event.target.classList.contains("omit")) {
    return;
  }
  event.target.classList.add("suggestion");
}

function disableHighlight(event) {
  event.target.classList.remove("suggestion");
}

function textHandler(event) {
  event.preventDefault();
  event.stopPropagation();
  console.log(event);
  disableHighlight(event);
}

function linkHandler(event) {
  event.preventDefault();
  event.stopPropagation();
  if (event.target.href == null) {
    alert("Link is undefined");
  } else {
  }
  disableHighlight(event);
}

function DownloadHandler(event) {
  event.preventDefault();
  event.stopPropagation();

  let target = event.target;
  if (target.tagName === "IMG") {
    if (target.src == null) {
      alert("Source is undefined");
    } else {
    }
  } else if (event.target.href == null) {
    alert("Cannot find the source");
  } else {
  }
  disableHighlight(event);
}

// --------------------------------------- Input Drag and Drop ---------------------------------------
// add necessary event listener to a input box
function addInputListeners(inputBox) {
  if (inputBox.readOnly) {
    return;
  }
  inputBox.addEventListener("drop", obtainDraggedInput);
  inputBox.addEventListener("dragenter", (e) => {
    console.log("dragenter highlight");
    e.preventDefault();
    e.target.classList.add("suggestion");
  });
  inputBox.addEventListener("dragover", (e) => {
    console.log("dragover highlight");
    e.target.classList.add("suggestion");
    e.preventDefault();
  });
  inputBox.addEventListener("dragleave", (e) => {
    e.preventDefault();
    e.target.classList.remove("suggestion");
  });
}

function obtainDraggedInput(event) {
  console.log("!Drop!");
  event.preventDefault();
  data = JSON.parse(event.dataTransfer.getData("text/plain"));
  event.target.value = data.value;
  event.target.focus();
  event.target.dispatchEvent(new Event("input"));
  event.target.classList.remove("suggestion");
  console.log(event.target);
  let actionName = "SendData";
  let parameters = [event.target, data.key];
  console.log(parameters);
  var date = new Date().getTime();
  console.log("Dropped Data IS: ", event.target.value);
  parameters[1] = event.target.value;
  sendRecordedAction(actionName, parameters, date);
  console.log("SEND DATA Parameters: ", parameters);
  console.log("finish sendRecorded Drop Action");
}

// Upon loading this page, add event listeners to the input boxes
document.querySelectorAll("input").forEach(addInputListeners);

// need to observe whether any new
const targetNode = document.body;

// Options for the observer (which mutations to observe)
const config = { attributes: false, childList: true, subtree: true };

// Callback function to execute when mutations are observed
const callback = function (mutationsList, observer) {
  for (const mutation of mutationsList) {
    if (mutation.type === "childList") {
      mutation.addedNodes.forEach((newNode) => {
        // fixme: getElementsByTagName is not a function"
        if (newNode instanceof HTMLElement) {
          Array.from(newNode.getElementsByTagName("input")).forEach(
            addInputListeners
          );
        }
      });
    }
  }
};

// Create an observer instance linked to the callback function
const observer = new MutationObserver(callback);

// Start observing the target node for configured mutations
observer.observe(targetNode, config);







// --------------------------------------- Prediction Execution ---------------------------------------
// currEle may change its xpath representation when we append buttons as its siblings
// so we need to return currEleXpath in this case to the server
var currEle = null;
var currEleXpath = null;
var currAction = null;
var prevPlaceholder = null;
var prevValue = null;
var updateEle = null;
var predictions = [];
var predictionIdx = 0;

function displayInput(ele, input) {
  prevPlaceholder = ele.placeholder;
  prevValue = ele.value;
  if (ele.value !== null) {
    ele.value = null;
  }
  ele.placeholder = input;
  ele.focus();
  ele.dispatchEvent(new Event("input"));
}

function automaticHighlightElement(suggestion) {
  currEleXpath = suggestion.ele;
  let type = suggestion.type;
  currAction = type;
  if (type === "GoBack") {
    let displayAction = document.createElement("div");
    let textContainer = document.createElement("div");
    displayAction.className = "predictionBanner";
    textContainer.className = "predictionBannerText";

    if (type === "ExtractURL") {
      textContainer.appendChild(
        document.createTextNode(type + " " + window.location.href)
      );
    } else {
      document.createTextNode("Go Back");
    }
    displayAction.appendChild(textContainer);
    document.getElementsByTagName("body")[0].appendChild(displayAction);
  } else {
    let ele = null;
    if (suggestion.ele !== null || suggestion.ele !== "") {
      console.log("GET element by Xpath line 185");
      ele = getElementByXpath(document, suggestion.ele);
    }
    if (ele === null) {
      console.log("ele not found on this page or not specified in suggestion");
      return;
    }
    console.log(
      "automatic will highlight: " + suggestion.type + " on " + suggestion.ele
    );
    currEle = ele;
    currEle.scrollIntoView({
      behavior: "auto",
      block: "center",
      inline: "center",
    });

    ele.classList.add("suggestion");

    let x = ele.getBoundingClientRect().x;
    let y = ele.getBoundingClientRect().y;
    y += ele.offsetHeight;
    if (type === "SendKeys" || type === "SendData") {
      displayInput(ele, suggestion.msg);
      let displayAction = document.createElement("div");
      displayAction.className = "sendDataSuggestion";
      displayAction.style.cssText = "top: " + y + "px; left: " + x + "px";
      displayAction.appendChild(document.createTextNode(type));
      let body = document.getElementsByTagName("body")[0];
      body.appendChild(displayAction);
    } else {
      // Click on Selected/option
      if (type === "Click") {
        if (ele.tagName === "OPTION") {
          ele.selected = true;
          ele.parentNode.classList.add("suggestion");
        }
        if (ele.tagName === "SELECT") {
          ele.value = "";
          ele.classList.add("suggestion");
        }
      }

      let displayAction = document.createElement("div");
      displayAction.className = "suggestedAction";
      displayAction.style.cssText = "top: " + y + "px; left: " + x + "px";
      if (type === "ScrapeText") {
        displayAction.appendChild(document.createTextNode("Scrape Text"));
      } else if (type === "SendData") {
        displayAction.appendChild(document.createTextNode("Send Data"));
      } else {
        displayAction.appendChild(document.createTextNode(type));
      }
      let body = document.getElementsByTagName("body")[0];
      body.appendChild(displayAction);
    }
  }
}

function automaticUndoHighlightElement(suggestion) {
  let type = suggestion.type;
  currAction = type;
  console.log("Automtic Undo Highlight: " + currAction);

  if (currEle !== null) {
    if (prevPlaceholder !== null) {
      prevPlaceholder = null;
    }
    if (prevValue !== null) {
      prevValue = null;
    }
    currEle.classList.remove("suggestion");
    currEle = null;
    currEleXpath = null;
  }
  currAction = null;
  if (type === "GoBack") {
    let removes = document.getElementsByClassName("predictionBanner");
    for (let i = 0; i < removes.length; i++) {
      removes[i].remove();
    }
  } else {
    console.log("GET element by Xpath line 267");
    let ele = getElementByXpath(document, suggestion.ele);
    if (ele === null) {
      console.log("ele not found on this page or not specified in suggestion");
      return;
    }
    ele.classList.remove("suggestion");
    ele.classList.remove("suggestionParent");
    if (type === "SendKeys" || type === "SendData") {
      undoHighlightAccept();
      let removes = document.getElementsByClassName("sendDataSuggestion");
      for (let i = 0; i < removes.length; i++) {
        removes[i].remove();
      }
    } else {
      if (ele.tagName === "OPTION") {
        ele.parentNode.classList.remove("suggestion");
      } else if (ele.tagName === "SELECT") {
        ele.classList.remove("suggest");
      }
      let removes = document.getElementsByClassName("suggestedAction");
      for (let i = 0; i < removes.length; i++) {
        removes[i].remove();
      }
    }
  }
}

function highlight(suggestion) {
  // remove previous highlights
  // var highlights = document.getElementsByClassName("suggestion");
  // for (var idx = 0; idx < highlights.length; idx++) {
  //   highlights[idx].classList.remove("suggestion")
  // }
  console.log("highlight", suggestion);
  let type = suggestion.type;
  var ele = null;
  currEleXpath = suggestion.ele;
  currAction = type;
  if (
    type !== "GoBack" &&
    suggestion.ele !== null &&
    suggestion.ele !== ""
  ) {
    console.log("GET element by Xpath line 311");
    console.log(suggestion.ele);
    
    // var clearedDom = document.cloneNode(true);
    // beforesentSuggested = clearedDom.getElementsByClassName("suggestion");
    // for (let i = 0; i < beforesentSuggested.length; i++) {
    //   beforesentSuggested[i].classList.remove("suggestion");
    // }
    // beforesentHighlighted = clearedDom.getElementsByClassName("highlight");
    // for (let i = 0; i < beforesentHighlighted.length; i++) {
    //   beforesentHighlighted[i].classList.remove("highlight");
    // }

    ele = getElementByXpath(document, suggestion.ele);
    console.log(ele);
    scrapeElement = ele;
  }
  if (ele === null && type !== "GoBack") {
    console.log("semi ele not found", suggestion);
    alert("suggestion not found, please manually demonstrate the next action") +
      document.readyState;
    chrome.runtime.sendMessage({ action: "manualBackMode" }, (response) => {});
    return "notFound";
  }

  console.log(
    "content.js will highlight: " +
      currAction +
      " on " +
      createXPathFromElement(ele)
  );

  switch (type) {
    case "Click":
      currEle = ele;
      // ele.classList.add("suggestion");
      // for select/option[i]
      if (currEle.tagName === "SELECT") {
        // deselect all options
        currEle.value = "";
      }
      if (currEle.tagName === "OPTION") {
        currEle.selected = true;
        // currEle.parentNode.classList.add("suggestion");
      }
      ele.scrollIntoView({
        behavior: "auto",
        block: "center",
        inline: "center",
      });
      addPredictionButtons(currAction, ele, suggestion.msg, null);
      console.log("ele.class: " + ele.className);
      return "click";
    case "SendKeys":
      currEle = ele;
      prevPlaceholder = ele.placeholder;
      prevValue = ele.value;
      if (ele.value !== null) {
        ele.value = null;
      }
      ele.scrollIntoView({
        behavior: "auto",
        block: "center",
        inline: "center",
      });
      addPredictionButtons(currAction, ele, suggestion.msg, null);
      // ele.className += " suggestion";
      ele.value = "";
      ele.placeholder = suggestion.msg;
      return "sendKeys";
    case "SendData":
      ele = getElementByXpath(document, suggestion.ele);
      currEle = ele;
      addPredictionButtons(currAction, ele, suggestion.msg, suggestion.jsonIdx);
      return "SendData";
    case "ScrapeLink":
      currEle = ele;
      // ele.className += " suggestion";
      ele.scrollIntoView({
        behavior: "auto",
        block: "center",
        inline: "center",
      });
      addPredictionButtons(currAction, ele, suggestion.msg, null);
      return currEle.href;
    case "ScrapeText":
      currEle = ele;
      let text = currEle.textContent;
      // ele.className += " suggestion";
      ele.scrollIntoView({
        behavior: "auto",
        block: "center",
        inline: "center",
      });
      addPredictionButtons(currAction, ele, suggestion.msg, null);
      return text;
    case "GoBack":
      // need an ele with fixed position
      addPredictionBanner("GoBack");
      console.log("content.js received action: " + currAction);
      return "goBack";
    case "Download":
      currEle = ele;
      // ele.className += " suggestion";
      ele.scrollIntoView({
        behavior: "auto",
        block: "center",
        inline: "center",
      });
      addPredictionButtons(currAction, ele, suggestion.msg, null);
      return "Download";
    default:
      console.log("unsupported type of suggestion: " + currAction);
      return "unsupported";
  }
}

// --------------- Send Back to Normal Mode (used when error occurs) -------------------//
function setNormalMode() {
  chrome.runtime.sendMessage({ action: "normal-mode" });
}

let prevBtnHandler = (event) => {
  event.preventDefault();
  event.stopPropagation();
  if (predictionIdx > 0) {
    let oldPredictionIdx = predictionIdx;
    predictionIdx--;
    while (
      getElementByXpath(document, predictions[predictionIdx].ele) === null
    ) {
      predictionIdx--;
      if (predictionIdx < 0) {
        predictionIdx = oldPredictionIdx;
        return;
      }
    }

    removePredictBtn(event);
    undoHighlightReject();
    highlight(predictions[predictionIdx]);
    scrapeSuggestion = predictions[predictionIdx];
  }
};

let nextBtnHandler = (event) => {
  let oldPredictionIdx = predictionIdx;
  predictionIdx++;
  while (getElementByXpath(document, predictions[predictionIdx].ele) === null) {
    predictionIdx++;
    if (predictionIdx >= predictions.length) {
      predictionIdx = oldPredictionIdx;
      return;
    }
  }

  removePredictBtn(event);
  undoHighlightReject();
  highlight(predictions[predictionIdx]);
  scrapeSuggestion = predictions[predictionIdx];
};

function addPredictionButtons(actionType, actionEle, actionMsg, actionJsonIdx) {
  console.log("addPredictionButtons " + actionType);
  let body = document.getElementsByTagName("body")[0];

  let divforall = document.createElement("div");


  let prevBtn = document.createElement("button");
  prevBtn.type = "button";
  prevBtn.innerHTML += "&#11013;";
  prevBtn.setAttribute("id", "prevButton");
  // container.appendChild(prevBtn);

  let nextBtn = document.createElement("button");
  nextBtn.type = "button";
  nextBtn.innerHTML += "&#10145;";
  nextBtn.setAttribute("id", "nextButton");
  // container.appendChild(nextBtn);
  console.log(
    "predictions.length predictionIdx",
    predictions.length,
    predictionIdx
  );
  prevBtn.addEventListener("click", prevBtnHandler);
  nextBtn.addEventListener("click", nextBtnHandler);
  divforall.appendChild(prevBtn);
  divforall.appendChild(nextBtn);

  if (predictionIdx == 0) {
    console.log("divforall.removeChild(prevBtn)");
    divforall.removeChild(prevBtn);
    console.log(
      "predictionIdx == predictions.length-1",
      predictionIdx == predictions.length - 1
    );
  }
  if (predictionIdx == predictions.length - 1) {
    divforall.removeChild(nextBtn);
  }

  // divforall.appendChild(predictionType);
  divforall.classList.add("predictionButtons");
  // actionEle.parentNode.appendChild(divforall);
  if (actionType === "SendData" || actionType === "SendKeys") {
    // actionEle.parentNode.appendChild(divforall);
    console.log(divforall);
    divforall.classList.add("semiSuggestion");
  } //else {
  let domRect = actionEle.getBoundingClientRect();
  if (actionEle.tagName === "OPTION") {
    let select = actionEle.parentNode;
    domRect = select.getBoundingClientRect();
  }
  let x = domRect.x;
  let y = domRect.y + actionEle.offsetHeight;
  divforall.classList.add("semiSuggestion");
  divforall.style.cssText = "top: " + y + "px; left: " + x + "px";
  // let body = document.getElementsByTagName("body")[0];
  // body.appendChild(divforall);
  console.log(
    "location",
    domRect.x,
    domRect.y,
    divforall.getBoundingClientRect().x,
    divforall.getBoundingClientRect().y
  );

  //}

  let parameters = [currEle];
  if (actionType === "SendData") {
    parameters.push(actionMsg);
  } else if (actionType === "SendKeys") {
    console.log(actionMsg);
    parameters.push(actionMsg);
  }
  scrapeParameters = parameters;

}

// This is for the banner on the left showing prediction
// when the prediction is GoBack or ExtractURL

function addPredictionBanner(actionType) {
  console.log("add prediction banner: " + actionType);

    let parameters = [];
    // acceptBtn.addEventListener("click", (event) => {
    //   console.log("banner accept");
    //   console.log(currAction);
    //   event.preventDefault();
    //   event.stopPropagation();
    //   console.log("prediction-accept-btn clicked");
    //   var date = new Date().getTime();
    //   // output this action in the popup
    //   if (actionType == "ExtractURL") {
    //     chrome.runtime.sendMessage({
    //       action: "outputText",
    //       output: window.location.href,
    //       timeStamp: date,
    //       url: window.location.href
    //     });
    //   }
    //   chrome.runtime.sendMessage({ action: "predictionAccepted" });
    //   // record this action & send to server
    //   // no need to call sendRecordedAction for GoBack action because execute Prediction will do this job (simulating a real go back)
    //   sendRecordedAction(actionType, parameters, date);
    //   // undo visualization
    //   console.log(currAction);
    //   removePredictBanner();
    //   executePrediction();
    //   undoHighlightAccept();
    // });

    // rejectBtn.addEventListener("click", (event) => {
    //   event.preventDefault();
    //   event.stopPropagation();
    //   console.log("predictionRejectBtn clicked");
    //   chrome.runtime.sendMessage(
    //     { action: "predictionRejectAction", parameter: parameters },
    //     (response) => {}
    //   );
    //   //removePredictBtn(event);
    //   undoHighlightReject();
    //   // hidePredictBanner();
    //   removePredictBanner();
    // });

}


function undoHighlightReject() {
  console.log("undo_suggestion_visualization starts");
  if (currEle !== null) {
    if (prevPlaceholder !== null) {
      currEle.placeholder = prevPlaceholder;
      prevPlaceholder = null;
    }
    if (prevValue !== null) {
      currEle.value = prevValue;
      prevValue = null;
    }

    // for select/option[i]
    if (currEle.tagName === "OPTION") {
      currEle.selected = false;
      currEle.parentNode.classList.remove("suggestion");
    }
    currEle.classList.remove("suggestion");
    currEle = null;
    currEleXpath = null;
  }
  currAction = null;
}

function undoHighlightAccept() {
  console.log("undo_suggestion_visualization starts");
  if (currEle !== null) {
    if (prevPlaceholder !== null) {
      prevPlaceholder = null;
    }
    if (prevValue !== null) {
      prevValue = null;
    }
    currEle.classList.remove("suggestion");
    // for select/option[i]
    if (currEle.tagName === "OPTION") {
      // can't turn the selected to false now!
      currEle.parentNode.classList.remove("suggestion");
    }
    currEle = null;
    currEleXpath = null;
  }
  currAction = null;
}



function executePrediction() {
  console.log("Executed click on " + createXPathFromElement(currEle));
  switch (currAction) {
    case "Click":
      currEle.selected = true;
      currEle.click();
      break;
    case "sendKeys":
      currEle.value = currEle.placeholder;
      break;
    case "SendKeys":
      currEle.value = currEle.placeholder;
      currEle.focus();
      currEle.dispatchEvent(new Event("input"));
      break;
    case "SendData":
      console.log("Send Data Execute Prediction: ", currEle);
      currEle.value = currEle.placeholder;
      currEle.focus();
      currEle.dispatchEvent(new Event("input"));
      break;
    case "ScrapeText":
      // TODO: store text somewhere?
      break;
    case "GoBack":
      window.history.go(-1);
      break;
    default:
      console.log("unsupported type of suggestion: " + currAction);
      break;
  }
}

function removePredictBtn(event) {
  let ele_type = document.getElementsByClassName("semiSuggestion");
  ele_type[0].remove();
}

function unhidePredictBanner() {
  let banners = document.getElementsByClassName("predictionBanner");
  banners[0].style.visibility = "visible";
}

function hidePredictBanner() {
  let banners = document.getElementsByClassName("predictionBanner");
  banners[0].style.visibility = "hidden";
}

function removePredictBanner() {
  let banners = document.getElementsByClassName("predictionBanner");
  banners[0].remove();
}

function removeInstructionBanner() {
  let banners = document.getElementsByClassName("instructionBanner");
  for (let i = 0; i < banners.length; i++) {
    banners[i].remove();
  }
}

// --------------------------------------- Recorder ---------------------------------------

/*
content.js will be injected into the page when the new page is opened.
This is used to register listeners.
Once the event is detected, it will be stored in the chrome storage for later use.
 */

var shouldPreventDefault = false;
var focusElement = null;
var focusKeys = [];

/*
append action to the chrome storage
@parameter
actionName[string]: the name of action
parameters[array]: parameters of the action
*/

function appendActionToStorage(actionName, parameters, timeStamp) {
  console.log("appendActionToStorage");
  if (parameters.length > 0) {
    let ele = parameters[0];
    let selectorMatrix = getSelectorMatrix(document, ele);
    parameters[0] = selectorMatrix;
  }

  chrome.runtime.sendMessage({
    action: "appendAction",
    actionName: actionName,
    parameters: parameters,
    url: window.location.href,
    timeStamp: timeStamp,
  });
  //tip(actionName + " " +parameters.join(" "))
}

/*
append current DOM to the chrome storage
*/
function appendDomToStorage(timeStamp) {
  console.log("appendDomToStorage");
  chrome.runtime.sendMessage({
    action: "appendDom",
    dom: document.documentElement.outerHTML,
    timeStamp: timeStamp,
  });
}

/*
send recording message if in a recording state
@parameter
actionName[string]: the name of action
parameters[array]: parameters of the action
*/
function sendRecordedAction(actionName, parameters, timeStamp) {
  // ignore any actions on http://localhost:3006/
  if (location.href == "http://localhost:3006/") {
    return;
  }
  console.log("sendRecordedAction, Parameters: ", parameters);
  if (recordStarted) {
    appendDomToStorage(timeStamp);
    if (actionName == "GoBack") {
      parameters = [];
    }
    appendActionToStorage(actionName, parameters, timeStamp);
    if (isUpdate === true) {
        // updateEle.classList.remove("suggestion");
        isUpdate = false;
    }
    if (isInsert === true) {
      // updateEle.classList.remove("suggestion");
      isInsert = false;
    }
  }
}

function cleanDom(document) {
  var DomTobesent = document.cloneNode(true);
  beforesentSuggested = DomTobesent.getElementsByClassName("suggestion");
  for (let i = 0; i < beforesentSuggested.length; i++) {
    beforesentSuggested[i].classList.remove("suggestion");
  }
  beforesentHighlighted = DomTobesent.getElementsByClassName("highlight");
  for (let i = 0; i < beforesentHighlighted.length; i++) {
    beforesentHighlighted[i].classList.remove("highlight");
  }
  return DomTobesent.documentElement.outerHTML;
}


function removePreviousDropDown()
{
  let node = document.getElementById("context-menu");
  if (node) {
    node.parentNode.removeChild(node);
  }
}

//callback function for click event
let clickHandler = (event) => {
  removePreviousDropDown();
  event.target.classList.remove("suggestion");
  console.log(
    "clickHandler currMode: " +
      currMode +
      " on " +
      createXPathFromElement(event.target)
  );
  let actionEle = event.target;
  // if the element has class 'omit', don't record it
  if (event.target.classList.contains("omit")) {
    return;
  }
  if (currMode !== "normal" && currMode !== "prediction" && currMode !== null) {
    // prevent ScrapeLink/text, etc of "test" <a><div>text</div></a>
    // from opening the link in <a>
    event.preventDefault();
    event.stopPropagation();
  }
  if (currMode === "normal") {
    let actionName = "Click";
    let parameters = [event.target];
    console.log("normal/click " + parameters[0]);
    var date = new Date().getTime();
    // output this action in the popup
    // chrome.runtime.sendMessage({ 'action': 'outputText', 'output': actionEle.textContent });
    //save it to the storage if the recording is started.
    // send the action to background which will send to server
    if (focusKeys.length != 0) {
      let actionName = "SendKeys";
      let parameters = [
        event.target,
        //JSON.stringify(focusKeys),
        focusElement.value,
      ];
      console.log("SendKeys " + parameters[0] + " " + parameters[1]);
      sendRecordedAction(actionName, parameters, date);
      focusKeys = [];
    }
    console.log("sendKey parameters: ", parameters);
    sendRecordedAction(actionName, parameters, date);
  } else if (currMode === "Download") {
    let actionName = "Download";
    let parameters = [event.target];
    console.log("Download " + parameters[0]);
    shouldPreventDefault = false;
    var date = new Date().getTime();
    // output this action in the popup
    if (event.target.tagName === "IMG") {
      if (event.target.src == null) {
        chrome.runtime.sendMessage({ action: "outputDownload", output: null, timeStamp: date, url: window.location.href});
      } else {
        chrome.runtime.sendMessage({
          action: "outputDownload",
          output: event.target.src,
          type: "IMG",
          timeStamp: date,
          url: window.location.href
        });
      }
    } else if (event.target.href == null) {
      chrome.runtime.sendMessage({ action: "outputDownload", output: null, timeStamp: date,
    url: window.location.href});
    } else {
      chrome.runtime.sendMessage({
        action: "outputDownload",
        output: event.target.href,
        timeStamp: date,
        url: window.location.href,
      });
    }
    //save it to the storage if the recording is started.
    // send the action to background which will send to server
    sendRecordedAction(actionName, parameters, date);
  } else if (currMode === "prediction") {
    // do nothing
    // we want to keep the dropdown menu open in semi-auto mode
    // and when the event.target === "SELECT"
    //if (event.target.tagName === "SELECT") {
    //    event.stopPropagation;
    //}
  }
};

// Append each keycode to the current list when a key is pressed and an element is focused
let keydownHandler = (event) => {
  if (focusElement != null) {
    focusKeys.push(event.keyCode);
  }
};

let hoverHandler = (event) => {
  // ignore any actions on http://localhost:3006/
  if (location.href == "http://localhost:3006/") {
    return;
  }

  if (event.target.classList.contains("omit")) {
    return;
  }
  chrome.runtime.sendMessage({ action: "getRecordingMode" }, (response) => {
    if (response === "ScrapText" || response === "ScrapLink") {
      if (document.getElementById("webrpaHoverPreview")) return;
      let element = document.createElement("div");
      if (
        response === "ScrapText" &&
        event.target.textContent != null &&
        event.target.textContent != undefined &&
        event.target.textContent != "" &&
        event.target.textContent.length < 100
      ) {
        element.innerHTML = event.target.textContent;
      } else if (
        response === "ScrapLink" &&
        event.target.hasAttribute("href") &&
        event.target.getAttribute("href") !== ""
      ) {
        element.innerHTML = event.target.getAttribute("href");
      } else if (
        response === "ScrapLink" &&
        event.target.parentElement &&
        event.target.parentElement.nodeName === "A" &&
        event.target.parentElement.hasAttribute("href")
      ) {
        element.innerHTML = event.target.parentElement.getAttribute("href");
      } else {
        return;
      }
      element.setAttribute("id", "webrpaHoverPreview");
      element.style.backgroundColor = "rgb(66, 197, 245)";
      element.style.color = "black";
      element.style.font = "normal 14px arial,serif";
      event.target.parentElement.appendChild(element);
    }
  });
};

let mousoutHandler = () => {
  let ele = document.getElementById("webrpaHoverPreview");
  if (ele) {
    ele.remove();
  }
};

// window.addEventListener("mouseover", hoverHandler, true);
window.addEventListener("mouseout", mousoutHandler, true);

window.addEventListener("click", clickHandler, true);

// Send the full sequence of keypresses once there is a change detected in the input field
window.addEventListener("change", (event) => {
  console.log("change + tagname = " + event.target.tagName);
  var date = new Date().getTime();
  // if the tagname is select/option, we want to see it as a click event
  // instead of SendKeys
  if (event.target.tagName === "SELECT") {
    let actionName = "Click";
    let parameters = [event.target];

    for (var i = 0; i < event.target.options.length; i++) {
      if (event.target.options[i].value === event.target.value) {
        console.log("Found the option: " + event.target.options[i].value);
        parameters[0] += "/option[" + (i + 1) + "]";
      }
    }
    sendRecordedAction(actionName, parameters, date);
  } else {
    if (event.target == focusElement && focusKeys.length != 0) {
      let actionName = "SendKeys";
      let parameters = [event.target, focusElement.value];
      console.log("SendKeys " + parameters[0] + " " + parameters[1]);
      sendRecordedAction(actionName, parameters, date);
      focusKeys = [];
    }
  }
});

// Set the current focus element when an input box is focused
window.addEventListener(
  "focus",
  (event) => {
    focusElement = event.target;
    // focusKeys = [];
  },
  true
);

window.addEventListener("keypress", keydownHandler, true);
window.addEventListener(
  "keydown",
  (event) => {
    if (
      event.keyCode == 8 &&
      event.target == focusElement &&
      focusElement != null
    ) {
      focusKeys.push(event.keyCode);
    }
  },
  true
);

function createXPathFromElement(element) {
  let result_xpath = [];
  // so namespace prefix is included (if any).
  for (
    ;
    element && element.nodeType === Node.ELEMENT_NODE;
    element = element.parentNode
  ) {
    // generate index for relative xpath position
    let index = 0;
    let hasFollowingSiblings = false;
    for (
      var sibling = element.previousSibling;
      sibling;
      sibling = sibling.previousSibling
    ) {
      // Ignore document type declaration.
      if (sibling.nodeType === Node.DOCUMENT_TYPE_NODE) continue;

      if (sibling.nodeName === element.nodeName) ++index;
    }

    //generate index for class index
    let class_index = 0;
    for (
      var class_sibling = element.previousSibling;
      class_sibling;
      class_sibling = class_sibling.previousSibling
    ) {
      // Ignore document type declaration.
      if (class_sibling.nodeType === Node.DOCUMENT_TYPE_NODE) continue;

      if (class_sibling.className === element.className) ++class_index;
    }

    //whether there's sibling with respect to relative xpath
    for (
      sibling = element.nextSibling;
      sibling && !hasFollowingSiblings;
      sibling = sibling.nextSibling
    ) {
      if (sibling.nodeName === element.nodeName) hasFollowingSiblings = true;
    }

    let tagName =
      (element.prefix ? element.prefix + ":" : "") + element.localName;
    let pathIndex =
      index || hasFollowingSiblings ? "[" + (index + 1) + "]" : "";
    let class_name =
      element.classList.length > 0
        ? "{" + element.className + "," + (class_index + 1) + "}"
        : "";

    // result_xpath.splice(0, 0, tagName + pathIndex + class_name)
    result_xpath.splice(0, 0, tagName + pathIndex);
  }

  return result_xpath.length ? "/" + result_xpath.join("/") : null;
}

function showInstruction(msg) {
  return;
  // if already an instruction banner
  let banners = document.getElementsByClassName("instructionBanner");
  if (banners.length > 0) {
    removeInstructionBanner();
  }
  let displayAction = document.createElement("div");
  let textContainer = document.createElement("div");
  displayAction.classList.add("instructionBanner");
  displayAction.classList.add("omit");
  textContainer.classList.add("instructionBannerText");
  textContainer.classList.add("omit");
  textContainer.appendChild(document.createTextNode(msg));
  let hideBtn = document.createElement("button");
  hideBtn.type = "button";
  hideBtn.classList.add("hideButton");
  hideBtn.classList.add("omit");
  hideBtn.innerHTML += "Hide";
  let body = document.getElementsByTagName("body")[0];
  displayAction.appendChild(textContainer);
  displayAction.appendChild(hideBtn);
  body.appendChild(displayAction);
  // Make the DIV element draggable:
  // dragElement(displayAction);
  hideBtn.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    console.log("hideBtn clicked");

    removeInstructionBanner();
  });
}

// 1) de-duplicate predictions where ele are the same with different selectors
// 2) delete predictions whose ele can't be found on the page
function filterPredictions(predictions) {
  const s = new Set();
  const uniquePredictions = [];
  console.log(
    "filterPredictions before predictions length: " + predictions.length
  );

  for (let i = 0; i < predictions.length; ++i) {
    let p = predictions[i];
    let type = p.type;
    if (type === "GoBack") {
      uniquePredictions.push(predictions[i]);
    } else {
      console.log("GET element by Xpath line 1111");
      let element = getElementByXpath(document, p.ele);
      let msg = p.msg;
      let obj = type + " " + createXPathFromElement(element);
      // having duplicated "GoBack" or "ScrapeURL" doesn't really happen
      //  console.log("filterPredictions ele: " + p.ele)
      //  console.log("filterPredictions ele converted: " + createXPathFromElement(element))

      if (s.has(obj)) {
        // duplicate
        continue;
      } else {
        if (type != "GoBack") {
          if (element !== null && element !== undefined) {
            // valid ele
            uniquePredictions.push(predictions[i]);
            s.add(obj);
          }
        } else {
          // invalid ele
          continue;
        }
      }
    }
  }
  console.log(
    "filterPredictions after predictions length: " + uniquePredictions.length
  );
  return uniquePredictions;
}

// --------------------------------------- Update ---------------------------------------
function updateAction(xpath) {
    isUpdate = true;
    console.log('udpate xpath: ', xpath)
    updateEle = getElementByXpath(document, xpath);
    updateEle.scrollIntoView({
      behavior: "auto",
      block: "center",
      inline: "center",
    });
    updateEle.classList.add("suggestion");
}

// --------------------------------------- Insert ---------------------------------------
function insertAction(xpath) {
  isInsert = true;
  //not finishied
}


// --------------------------------------- Visualization ---------------------------------------
function arraysEqual(a, b) {
  if (a === b) return true;
  if (a == null || b == null) return false;
  if (a.length !== b.length) return false;

  for (var i = 0; i < a.length; ++i) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

function visualizeAction(xpaths, visualize_enable) {
  if (visualize_enable == false) {
    // remove highlight from previous elements
    for (var i=0;i<highlightElements.length;i++) {
        disable_highlighgEle = highlightElements[i]
        disable_highlighgEle.classList.remove("highlight");
    }
    visualizeElements = [];
    highlightElements = [];
  }
  else {
    var visualize_status = true;
    if (arraysEqual(xpaths, visualizeElements)) {
        visualize_status = false;
        return;
    }
    // add highlight for current elements
    visualizeElements = xpaths;
    for (var i=0;i<xpaths.length;i++) {
        console.log("GET element by Xpath line 1195");
        highlightEle = getElementByXpath(document, xpaths[i]);
        highlightEle.classList.add("highlight");
        highlightElements.push(highlightEle);
    }

    // update current highlight elements
    visualize_status = false;
  }
}



// --------------------------------------- Context Menu ---------------------------------------
function rightClickHandler(event) {
  event.preventDefault();
  event.stopPropagation();
  removePreviousDropDown();
  // dropdown menu html
  var div = document.createElement("div");
  div.innerHTML =
    '<div class="omit" id="context-menu" >\
      <ul class="omit" > \
        <li class="omit" id="ScrapeTextId" style="color:black;">Scrape Text</li>\
        <li class="omit" id="ScrapeLinkId" style="color:black;">Scrape Link</li>\
      </ul>\
    </div>';
  div.cssText = div.style.display = "block";
  div.style.position = "absolute";
  div.style.left = event.pageX + "px";
  div.style.top = event.pageY + "px";
  document.body.appendChild(div);

  var menu = document.getElementById("context-menu");
  menu.classList.add("context-menu-class");

  var ScrapeBtn = document.getElementById("ScrapeTextId");
  ScrapeBtn.onclick = () => {
    scrapeTextAction(event);
  };

  ScrapeBtn = document.getElementById("ScrapeLinkId");
  ScrapeBtn.onclick = () => {
    scrapeLinkAction(event);
  };
}

function scrapeTextAction(event) {
  let actionEle = event.target;
  let actionName = "ScrapeText";
  console.log("ScrapeText " + actionEle);
  shouldPreventDefault = false;
  // output this action in the popup
  let scrapeTextOutputText = actionEle.textContent;
  if (actionEle.tagName == "INPUT") {
    scrapeTextOutputText = actionEle.value;
  } else {
    let hvMatchedChild = true;
    while (hvMatchedChild) {
      hvMatchedChild = false;
      for (let i = 0; i < actionEle.children.length; i++) {
        if (actionEle.children[i].textContent === actionEle.textContent) {
          console.log("ScrapeText Get Child");
          actionEle = actionEle.children[i];
          hvMatchedChild = true;
          break;
        }
      }
    }
    scrapeTextOutputText = actionEle.textContent;
  }
  console.log("ScrapeText: " + scrapeTextOutputText);
  var date = new Date().getTime();
  chrome.runtime.sendMessage({
    action: "outputText",
    output: scrapeTextOutputText,
    timeStamp: date,
    url: window.location.href,
  });
  let parameters = [actionEle];
  //save it to the storage if the recording is started.
  // send the action to background which will send to server
  sendRecordedAction(actionName, parameters, date);
}

function scrapeLinkAction(event) {
  let actionName = "ScrapeLink";
  let parameters = [event.target];
  // https://developer.mozilla.org/en-US/docs/Web/API/Element/closest
  // find the closest atag of the clicked event up the hierachical DOM tree
  var atag = event.target.closest("a");
  console.log("ScrapeLink " + parameters[0]);
  // output this action in the popup
  if (atag.href == null) {
    alert("Link is undefined");
  } else {
    let outputLink = atag.href;
    if (atag.href == null) {
      outputLink = atag.href;
    }
    var date = new Date().getTime();
    chrome.runtime.sendMessage({
      action: "outputLink",
      output: outputLink,
      timeStamp: date,
      url: window.location.href,
    });
    // send the action to background which will send to server
    sendRecordedAction(actionName, parameters, date);
  }
  shouldPreventDefault = false;
  //save it to the storage if the recording is started.
}

// --------------------------------------- Integration ---------------------------------------
async function fullyLoadPage() {
  return new Promise((resolve) =>
    window.addEventListener("load", function () {
      resolve();
    })
  );
}


window.onload = function () {
  chrome.runtime.sendMessage({ action: "getMode" });
  //load highlight
  // chrome.runtime.sendMessage({ "action": "load_highlight" });
  isLoaded = true;
  console.log("onload finish");
};

function notExistHref(element) {
  let node = element;
  // keep iterating unless null
  while (node != null) {
    if (node.getAttribute("href") === null) {
      node = node.parentNode;
    } else {
      return false;
    }
  }
  return true;
}




function scrapeNext(scrapeAction, scrapeElement, scrapeMsg, scrapeSuggestion) {

  // remove previous highlight
  var highlights = document.getElementsByClassName("suggestion");
  for (var idx = 0; idx < highlights.length; idx++) {
    highlights[idx].classList.remove("suggestion")
  }

  console.log("scrapeNextBtn clicked, item: ", scrapeElement, scrapeAction);
  var date = new Date().getTime();
  if (scrapeAction === "ScrapeText") {
    let text = scrapeElement.textContent;
    if (scrapeElement.tagName == "INPUT") {
      text = scrapeElement.value;
    }
    chrome.runtime.sendMessage({
      action: "outputText",
      output: text,
      timeStamp: date,
      url: window.location.href
    });
    chrome.runtime.sendMessage({ action: "predictionAccepted" });
  }  else if (scrapeAction === "ScrapeLink") {
    let outputLink = scrapeElement.href;
    scrapeElement.classList.remove("suggestion");
    console.log("scrape next ele: ", scrapeElement);
    console.log("scrape next link: ", outputLink);
    console.log("parent node: ", scrapeElement.parentNode);
    if (scrapeElement.href == null) {
      console.log("scrape element href is null");
      outputLink = scrapeElement.parentNode.href;
      if (outputLink == null) {
      outputLink = scrapeElement.parentNode.parentNode.href;
      }
    }
    chrome.runtime.sendMessage({
      action: "outputLink",
      output: outputLink,
      timeStamp: date,
      url: window.location.href
    });
    chrome.runtime.sendMessage({ action: "predictionAccepted" });
  } else if (scrapeAction === "SendKeys") {
    chrome.runtime.sendMessage({
      action: "outputText",
      output: "Entering: " + scrapeMsg,
      timeStamp: date,
      url: window.location.href
    });
    chrome.runtime.sendMessage({ action: "predictionAccepted" });
  } else if (scrapeAction === "SendData") {
    ele = getElementByXpath(document, scrapeSuggestion.ele);
    prevPlaceholder = ele.placeholder;
    prevValue = ele.value;
    if (ele.value !== null) {
      ele.value = null;
    }
    // ele.className += " suggestion";
    ele.placeholder = scrapeSuggestion.msg;
    ele.scrollIntoView({
      behavior: "auto",
      block: "center",
      inline: "center",
    });
  } else if (scrapeAction === "Download") {
    var date = new Date().getTime();
    if (scrapeElement.tagName === "IMG") {
      if (scrapeElement.src === null) {
        chrome.runtime.sendMessage({
          action: "outputDownload",
          output: null,
          timeStamp: date,
          url: window.location.href
        });
      } else {
        chrome.runtime.sendMessage({
          action: "outputDownload",
          output: scrapeElement.src,
          type: "IMG",
          timeStamp: date,
          url: window.location.href
        });
      }
    } else if (scrapeElement.href === null) {
      chrome.runtime.sendMessage({ action: "outputDownload", output: null, timeStamp: date, url: window.location.href});
    } else {
      chrome.runtime.sendMessage({
        action: "outputDownload",
        output: scrapeElement.href,
        timeStamp: date,
        url: window.location.href
      });
    }
    chrome.runtime.sendMessage({ action: "predictionAccepted" });
  } else if (scrapeAction === "Click") {
    chrome.runtime.sendMessage({ action: "predictionAccepted" });
  } else if (scrapeAction === "GoBack") {
    chrome.runtime.sendMessage({ action: "predictionAccepted" });
  } else {
    chrome.runtime.sendMessage({ action: "predictionAccepted" });
  }
  // undo visualization
  executePrediction();
  // removePredictBtn(event);
  // undoHighlightAccept();
  // record this action & send to server
  sendRecordedAction(scrapeAction, scrapeParameters, date);
  console.log("scrape next parameters: ", scrapeParameters);
  if (scrapeAction != "GoBack") {
    scrapeElement.classList.add("suggestion"); 
    setTimeout(function() {
      scrapeElement.classList.remove("suggestion"); 
    }, 1000);
  }
}



var previousDict = {};

function checkTextQuery(xpaths) {
  var textQueryDict = {};
  for (var i=0; i<xpaths.length; i++) {
    console.log("GET element by Xpath line 1457");
    var checkedEle = getElementByXpath(document, xpaths[i]);
    let hvMatchedChild = true;
    while (hvMatchedChild) {
      hvMatchedChild = false;
      for (let i = 0; i < checkedEle.children.length; i++) {
        if (checkedEle.children[i].textContent === checkedEle.textContent) {
          console.log("Check Text Get Child");
          checkedEle = checkedEle.children[i];
          hvMatchedChild = true;
          break;
        }
      }
    }
    textQueryDict[xpaths[i]] = checkedEle.textContent; 
  }
  if (textQueryDict != previousDict) {
    chrome.runtime.sendMessage({
      action: "sendTextQuery",
      output: textQueryDict
    });
    previousDict = textQueryDict;
  }
}




chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action != "checkTextQuery" && message.action != "visualize") {
    console.log("debug", message.action);
  }
  // ignore any actions on http://localhost:3006/
  if (location.href == "http://localhost:3006/") {
    return;
  }

  if (message.action === "changeMode") {
    currMode = message.mode;
    recordStarted = message.recordStarted;
    if (message.mode === "ScrapeText") {
      document.addEventListener("mouseover", highlightElement);
      document.addEventListener("mouseout", disableHighlight);
      // document.removeEventListener("click", linkHandler, true);
      // document.removeEventListener("click", DownloadHandler, true);
      // document.addEventListener("click", textHandler);
      document.addEventListener("contextmenu", rightClickHandler);
    } else if (message.mode === "ScrapeLink") {
      document.addEventListener("mouseover", highlightElement);
      document.addEventListener("mouseout", disableHighlight);
      // document.removeEventListener("click", textHandler);
      // document.removeEventListener("click", DownloadHandler, true);
      // document.addEventListener("click", linkHandler, true);
    } else if (message.mode === "Download") {
      document.addEventListener("mouseover", highlightElement);
      document.addEventListener("mouseout", disableHighlight);
      // document.removeEventListener("click", textHandler);
      // document.removeEventListener("click", linkHandler, true);
      // document.addEventListener("click", DownloadHandler, true);
    } else if (message.mode === "normal" || message.mode === "prediction") {
      document.addEventListener("mouseover", highlightElement);
      document.addEventListener("mouseout", disableHighlight);
      // document.removeEventListener("click", textHandler);
      // document.removeEventListener("click", linkHandler, true);
      // document.removeEventListener("click", DownloadHandler, true);
      document.addEventListener("contextmenu", rightClickHandler);
    } else if (message.mode === "prediction") {
      // document.removeEventListener("mouseover", highlightElement);
      // document.removeEventListener("mouseout", disableHighlight);
      // document.removeEventListener("click", textHandler);
      // document.removeEventListener("click", linkHandler, true);
      // document.removeEventListener("click", DownloadHandler, true);
      // remove current highlightings
      let e = document.getElementsByClassName("suggestion")[0];
      if (e !== undefined) {
        if (e.hasOwnProperty("classList")) {
          e.classList.remove("suggestion");
        }
      }
    }
    console.log("mode is now: " + currMode);
  } else if (message.action === "semimode") {
    predictions = message.predictions;
    predictionIdx = 0;
    console.log("highlight", message);
    console.log(predictions);
    while (
      predictionIdx < predictions.length &&
      predictions[predictionIdx].type != "GoBack" &&
      getElementByXpath(document, predictions[predictionIdx].ele) === null
    ) {
      predictionIdx++;
    }

    showInstruction(
      "In semi-automation mode, please wait for predictions to be visualized"
    );
    if (predictionIdx >= predictions.length) {
      console.log("semiMode alert not found");
      sendResponse(false);
    } else {
      highlight(predictions[predictionIdx]);     //  don't highlight suggestion at once
      scrapeSuggestion = predictions[predictionIdx];
      console.log("Scrape suggestion: ", scrapeSuggestion);
      sendResponse(true);
    }
  } else if (message.action === "predictionAccept") {
    undoHighlightAccept();
    removeInstructionBanner();
    executePrediction();
  } else if (message.action === "predictionReject") {
    undoHighlightReject();
    removeInstructionBanner();
  } else if (message.action === "update") {
    updateAction(message.ele);
  }  else if (message.action === "insert") {
    insertAction(message.ele);
  } else if (message.action === "checkTextQuery") {
    checkTextQuery(message.ele);
  } else if (message.action === "scrapeNext") {
    scrapeElement.classList.remove("suggestion");
    console.log("scrape next parameters: ", currAction, scrapeElement, scrapeSuggestion.msg, scrapeSuggestion);
    scrapeNext(currAction, scrapeElement, scrapeSuggestion.msg, scrapeSuggestion);
    scrapeSuggestion = null;
  } else if (message.action === "visualize") {
    visualizeAction(message.ele, message.visualize_enable);
  } 
  else if (message.action === "changeToBulk") {
    console.log("change to bulk");
    scrapeNext(currAction, scrapeElement, scrapeSuggestion.msg, scrapeSuggestion);
  }else if (message.action === "debug") {
    console.log("debug msg:" + message.msg);
  } else if (message.action === "checkEle") {
    console.log("debugcheckEle", message.predictions, message.predMode);
    let checkEle = -1;
    predictions = message.predictions;
    if (message.predMode == "semi") {
      console.log("check ele semi");
      for (let i = 0; i < predictions.length && checkEle == -1; i++) {
        let suggestion = predictions[i];
        if (suggestion.type != "GoBack") {
          
          console.log("GET element by Xpath line 1598");
          let element = getElementByXpath(document, suggestion.ele);
          console.log(element);
          if (element !== null && element !== undefined) {
            checkEle = i;
            break;
          }
        } else {
          checkEle = i;
          break;
        }
      }
    } else if (message.predMode == "fully") {
      console.log("check ele fully");
      let suggestion = predictions[0];
      if (suggestion.type != "GoBack") {
        
        console.log("GET element by Xpath line 1615");
        let element = getElementByXpath(document, suggestion.ele);
        console.log("debugcheckEle fully", element);
        if (element !== null && element !== undefined) {
          checkEle = 0;
        }
      } else {
        checkEle = 0;
      }
    }
    console.log(checkEle);
    sendResponse(checkEle);
  } else if (message.action === "automaticAccept") {

    if (isLoaded) {
      // alert("elemeent: " + getElementByXpath(document,message.ele));
      console.log(message);
      currMode = "prediction";
      let element = undefined;
      if (message.type !== "GoBack") {
        
        console.log("GET element by Xpath line 1635");
        element = getElementByXpath(document, message.ele);
      }

      if (
        (element === null || element === undefined) &&
        message.type !== "GoBack"
      ) {
        console.log("Suggestion Element does not exits");
        sendResponse(false);
      }

      if (message.type === "ScrapeText") {
        // alert("ScrapeText automated")
        let ele = message.ele;
        let parameters = [ele];
        // output this action in the popup
        let outputText = element.textContent;
        if (element.tagName == "INPUT") {
          outputText = element.value;
        }
        var date = new Date().getTime();
        chrome.runtime.sendMessage({
          action: "outputText",
          output: outputText,
          timeStamp: date,
          url: window.location.href
        });
        sendRecordedAction("ScrapeText", parameters, date);
      } else if (message.type === "ScrapeLink") {
        let ele = message.ele;
        let parameters = [ele];
        
        console.log("GET element by Xpath line 1668");
        let outputLink = getElementByXpath(document, ele).href;
        if (outputLink == null) {
          outputLink = getElementByXpath(document, ele).parentNode.href;
        }
        var date = new Date().getTime();
        chrome.runtime.sendMessage({
          action: "outputLink",
          output: outputLink,
          timeStamp: date,
          url: window.location.href
        });
        sendRecordedAction("ScrapeLink", parameters, date);
      } else if (message.type === "GoBack") {
        var date = new Date().getTime();
        sendRecordedAction("GoBack", [], date);
        window.history.go(-1);
      } else if (message.type === "Click") {
        element.selected = true;
        console.log("auto_accept click caller: " + message.caller);
        let ele = message.ele;
        let parameters = [ele];
        var date = new Date().getTime();
        element.click();
        sendRecordedAction("Click", parameters, date);
      } else if (message.type === "SendData") {
        let ele = message.ele;
        // let jsonIdx = message.jsonIdx;
        let parameters = [ele, message.msg];
        element.value = message.msg;
        element.focus();
        element.dispatchEvent(new Event("input"));
        var date = new Date().getTime();
        sendRecordedAction("SendData", parameters, date);
      } else if (message.type === "SendKeys") {
        let ele = message.ele;
        let parameters = [ele, message.msg];
        element.value = element.placeholder;
        var date = new Date().getTime();
        sendRecordedAction("SendKeys", parameters, date);
      } else if (message.type === "Download") {
        let parameters = [element];
        var date = new Date().getTime();
        // output this action in the popup
        if (element.tagName === "IMG") {
          if (element.src === null) {
            chrome.runtime.sendMessage({
              action: "outputDownload",
              output: null,
              timeStamp: date,
              url: window.location.href
            });
          } else {
            chrome.runtime.sendMessage({
              action: "outputDownload",
              output: element.src,
              type: "IMG",
              timeStamp: date,
              url: window.location.href
            });
          }
        } else if (element.href === null) {
          chrome.runtime.sendMessage({
            action: "outputDownload",
            output: null,
            timeStamp: date,
            url: window.location.href
          });
        } else {
          chrome.runtime.sendMessage({
            action: "outputDownload",
            output: element.href,
            timeStamp: date,
            url: window.location.href
          });
        }

        sendRecordedAction("Download", parameters, date);
      }
      sendResponse(true);
    }
  } else if (message.action === "automaticHighlight") {
    // if the ele isn't found on the page (except when type is ExtractURL or GoBack)
    if (isLoaded) {
      console.log(message.type != "GoBack");
      if (message.type !== "GoBack") {
          
        console.log("GET element by Xpath line 1756");
        let element = getElementByXpath(document, message.ele);
        if (element === null || element === undefined) {
          var startTime = Date.now();
          while (Date.now() - startTime < 6000) {
            console.log("GET element by Xpath line 1761");
            element = getElementByXpath(document, message.ele);
          }
          if (element === null || element === undefined) {
            if (document.readyState !== "complete") {
              alert(
                "element not visible, but is loading: " + document.readyState
              );
            } else {
              // alert(
              //     "automaticHighlight\n"+message.type+" "+messgae.ele+"\n"+"Predicted element not available on screen. Please manually indicate which action you would like to do next."+document.readyState
              // );
              console.log(
                "Predicted element not available on screen. Please manually indicate which action you would like to do next."
              );
              chrome.runtime.sendMessage(
                { action: "manualBackMode" },
                (response) => {}
              );
            }
          }
        }
      }
      automaticHighlightElement(message);
    }
  } else if (message.action === "automaticHighlightUndo") {
    automaticUndoHighlightElement(message);
  } else if (message.action === "alertNotFound") {
    console.log("debug2 alert not found");
    // alert("suggestion not found, please manually demonstrate the next action");
    chrome.runtime.sendMessage({ action: "manualBackMode" }, (response) => {});
  } else if (message.action === "getDom") {
    sendResponse(cleanDom(document));
  } else if (message.action === "getElement") {
    console.log("GET element by Xpath line 1796");
    sendResponse(getElementByXpath(document, message.xpath));
  } else if (message.action === "showInstruction") {
    // showInstruction(message.msg);
  } else if (message.action === "filterPredictions") {
    let predictions = message.predictions;
    let filtered = [];
    filtered = filterPredictions(predictions);
    sendResponse({ filtered: filtered });
  } else if (message.action === "removeInstructions") {
    removeInstructionBanner();
  } else {
    console.log("unsupported action type");
  }
  //meaningless response. send response to avoid errors.
  sendResponse("selecting");
});
