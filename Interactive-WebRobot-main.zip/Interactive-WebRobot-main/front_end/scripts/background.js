// --------------------------------------- Action_Output Panel / ui "popup" panel---------------------------------------
var scrapeWindowId;
var dom = null;
var outputs = [];
var popupWindow = undefined;
var currMode = null;
var prevMode = null;
var numDemonstrations;
var numAcceptances = 0;
var predMode = "normal";
var intoSemiNum = 0;
var intoFullyNum = 500;
var currUrl = null;
var highlightDelayTime = 10;
var currAction = undefined;
var actionList = [];
var domList = [];
var traceName = "";
var recordStarted = false;
var recordingActionMode = "normal";
var currSuggestion = null;
var currActionName = null;
var currParameters = null;
var numFullyExeute = 0;
var speedupNum = 10;
var sentSuggestion = false;
var startHighlight = false;
var delaySent = false;
var jsonObj = null;
var predictions = [];
var predictionIdx = 0;
var tryNum = 15;
var updateStatus = false;
var insertStatus = false;
var isBulk = false;
var bulkPredictions = null;
var bulkIdx = 0;
var bulkList = [];
var endBulk = false;
chrome.browserAction.onClicked.addListener(function (tab) {
  scrapeWindowId = tab.windowId;
  let instruction = "In manual mode, please 1) choose the action type in the panel, 2) hover your mouse over an element, 3) click the highlighted element";
  showInstruction(instruction);
  // check if panel is already open
  if (typeof popupWindow == "undefined") {
    // refresh all tabs in all windows to sync the extension, another option is to open the current tab in a new window like Helena did
    chrome.windows.getAll({ populate: true }, function (windows) {
      windows.forEach(function (window) {
        window.tabs.forEach(function (tab) {
          // don't refresh for the react front-end url
          if (tab.url !== "http://localhost:3006/") {
            chrome.tabs.update(tab.id, { url: tab.url });
          }
        });
      });
    });

    chrome.windows.create(
      {
        url: chrome.runtime.getURL("../pages/popup.html"),
        type: "popup",
        focused: true,
        height: 100,
        width: 600,
      },
      function (win) {
        // win represents the Window object from windows API
        // Do something after opening
        popupWindow = win;
        numDemonstrations = 0;
        numAcceptances = 0;
        numFullyExeute = 0;
      }
    );
  } else {
    chrome.windows.update(popupWindow.id, { focused: true });
  }
});

// when active tab is changed, sync mode
chrome.tabs.onActivated.addListener(function (info) {
  if (isBulk == true) {
    currMode = prediction;
  }
  console.log("line 91 change mode: ",currMode);
  chrome.tabs.sendMessage(
    info.tabId,
    { action: "changeMode", mode: currMode, recordStarted: recordStarted },
    (response) => {}
  );
  if (recordStarted){
    if (predMode == "normal") {
      let instruction = "In manual mode, please 1) choose the action type in the panel, 2) hover your mouse over an element, 3) click the highlighted element";
      showInstruction(instruction);
    } else if (predMode == "semi") {
      let instruction = "In semi-automation mode, please wait for predictions to be visualized then accept, reject, or iterate through the list of predictions";
      showInstruction(instruction);
    } else if (predMode == "fully") {
      let instruction = "In fully-automation mode, please wait for the program to execute automatically or " +
                          "click 'Back to Manual' in the panel if you see any unwanted action";
      showInstruction(instruction);
    }
  }
});

// when focusing a different window, synch mode
chrome.windows.onFocusChanged.addListener(function (winId) {
  
  console.log("line 105 change mode: ", currMode);
  chrome.tabs.query(
    { active: true, windowId: scrapeWindowId },
    function ([tab]) {
      chrome.tabs.sendMessage(
        tab.id,
        { action: "changeMode", mode: currMode, recordStarted: recordStarted },
        (response) => {}
      );
    }
  );
  if (winId != popupWindow.id) {
    // scrapeWindowId = winId;
  }
  if (recordStarted && winId != popupWindow.id) {
    if (predMode == "normal") {
      let instruction = "In manual mode, please 1) choose the action type in the panel, 2) hover your mouse over an element, 3) click the highlighted element";
      showInstruction(instruction);
    } else if (predMode == "semi") {
      let instruction = "In semi-automation mode, please wait for predictions to be visualized then accept, reject, or iterate through the list of predictions";
      showInstruction(instruction);
    } else if (predMode == "fully") {
      let instruction = "In fully-automation mode, please wait for the program to execute automatically or " +
                          "click 'Back to Manual' in the panel if you see any unwanted action";
      showInstruction(instruction);
    }
  }
});

// when the popup page is closed
chrome.windows.onRemoved.addListener(function (winId) {
  if (typeof popupWindow == "object" && popupWindow.id == winId) {
    popupWindow = undefined;
    recordStarted = false;
    // change mode to null
    chrome.tabs.query(
      { active: true, windowId: scrapeWindowId },
      function ([tab]) {
        chrome.tabs.sendMessage(
          tab.id,
          { action: "changeMode", mode: null, recordStarted: recordStarted },
          (response) => {}
        );
      }
    );
  }
});
// --------------------------------------- Prediction Panel ---------------------------------------

// --------------------------------------- Recorder ---------------------------------------
//important: for now, goback action doesn't have corresponding DOM. It doesn't need that and it's not well defined.
//some global variables

function clearStorage() {
  actionList = [];
  domList = [];
}

function automaticMode(suggestion, caller) {
    console.log("automaticMode",suggestion, caller);
  // Send suggestion to be automatically accepted to content.js
  numFullyExeute++;
  return new Promise((resolve) => {
    chrome.tabs.query(
      { active: true, windowId: scrapeWindowId },
      function ([tab]) {
        chrome.tabs.sendMessage(
          tab.id,
          {
            action: "automaticAccept",
            type: suggestion.type,
            ele: suggestion.ele,
            msg: suggestion.msg,
            jsonIdx: suggestion.jsonIdx,
            caller: caller,
          },
          (response) => {
            //meaningless response. send response to avoid errors.
            resolve(response);
          }
        );
      }
    );
  });
}

// send suggestion to content.js to be highlighted in fully-auto mode
function automaticModeHighlight(suggestion) {
  chrome.tabs.query(
    { active: true, windowId: scrapeWindowId },
    function ([tab]) {
      chrome.tabs.sendMessage(
        tab.id,
        {
          action: "automaticHighlight",
          type: suggestion.type,
          ele: suggestion.ele,
          msg: suggestion.msg,
        },
        (response) => {
          //meaningless response. send response to avoid errors.
          sendResponse(response);
        }
      );
    }
  );
}

function automaticModeHighlightUndo(suggestion) {
  chrome.tabs.query(
    { active: true, windowId: scrapeWindowId },
    function ([tab]) {
      chrome.tabs.sendMessage(
        tab.id,
        {
          action: "automaticHighlightUndo",
          type: suggestion.type,
          ele: suggestion.ele,
          msg: suggestion.msg,
        },
        (response) => {
          //meaningless response. send response to avoid errors.
          sendResponse(response);
        }
      );
    }
  );
}

// tell content.js to highlight the suggestion
function semiMode() {
  console.log("semi mode predictions: ", predictions);
  return new Promise((resolve) => {
    // if (!startHighlight) {
      sentSuggestion = true;
      let sent = false;
      chrome.tabs.query(
        { active: true, windowId: scrapeWindowId },
        function (tabs) {
          if (sent == true) {
          } else {
            console.log("sent prediction: ", predictions);
            chrome.tabs.sendMessage(
              tabs[0].id,
              { action: "semimode", predictions: predictions },
              (response) => {
                console.log(tabs[0].id);
                resolve(response);
              }
            );
            sent = true;
          }
        }
      );
    // }
  });
}


function bulkHandler() {
    currMode = "prediction"
    predMode = "fully"
    predictions = [bulkPredictions[bulkIdx]];
    bulkIdx++;
    console.log("Bulk Handler Predictions: ", predictions);
    suggestionHandler("bulk");
    currMode = "normal"
    predMode = "normal"
}

function appendAction(actionName, parameters, url, timeStamp) {
  
  let time = 0;

  console.log(actionName);
  numDemonstrations++;

  console.log("current bulk mode: ", isBulk);
  if (!isBulk && bulkList.length != 0) {
    sendBulkToServer();
    bulkList = [];
    bulkIdx = 0;
  }

  if (isBulk && !updateStatus && !insertStatus) {
      bulkList.push({
        action: actionName,
        parameter: parameters,
        url: url,
        timeStamp: timeStamp
        });
        if (bulkPredictions !== null) {
          if (bulkIdx === bulkPredictions.length) { // scrape in bulk finished

              endBulk = true;
              console.log("scrape bulk finished");

              
              if (bulkList.length == 1 && (bulkList[0].action == "Click" || bulkList[0].action == "GoBack")) {
                console.log("wait click and go back in bulk");
                time = 4000;
              }
              sendBulkToServer();
              bulkList = [];
              bulkIdx = 0;
              isBulk = false;
              
              // resets mode among manual/semi-auto/auto
              predMode = "normal";
              numAcceptances = 0;
              numDemonstrations = 0;
              numFullyExeute = 0;

              // change mode to normal
              currMode = "normal";
              
              console.log("line 304 change mode");
              chrome.tabs.query(
                { active: true, windowId: scrapeWindowId },
                function ([tab]) {
                  chrome.tabs.sendMessage(
                    tab.id,
                    { action: "changeMode", mode: currMode, recordStarted: recordStarted },
                    (response) => {
                      //meaningless response. send response to avoid errors.
                      sendResponse(response);
                    }
                  );
                }
              );
          }
          else { // scrape in bulk NOT finished
              bulkHandler();
          }
      }
      console.log("Bulk index: ", bulkIdx);
      console.log("Bulk prediction length: ", bulkPredictions.length);
      console.log("Previous mode: ", previous_mode)
      if (endBulk == true && previous_mode == true) {
        console.log("continue on scraping");
        endBulk = false;
        isBulk = true;
      }
      else {
        console.log("Is Bulk returned!");
        return;
      }

  }


  console.log("next stage");
  console.log("action name: ", actionName)
  actionList.push({ actionName: actionName, parameters: parameters });
  // wait for the page to fully load
  if (actionName === "Click" || actionName === "GoBack") {
    console.log("GO BACK! wait for page to fully load;")
    startHighlight = true;
    time = 4000;
    if (numAcceptances >= intoFullyNum) {
      // generally useful when doing manual paginations
      startHighlight = false;
    }
  } 
  else {
    startHighlight = false;
  }


  setTimeout(() => {
      chrome.tabs.query(
        { active: true, windowId: scrapeWindowId },
        function ([tab]) {
            let curDom = null;
          chrome.tabs.sendMessage(
            tab.id,
            { action: "getDom" },
            function (response) {
                if (response) {
                    dom = response;
                }
                curDom = response;

              // send actions and doms
              if (isBulk != true) {
                console.log("NOT BULK MODE: ADD ACTION AND DOM TO SERVER");
                sendActionDomToServer({
                  action: actionName,
                  parameter: parameters,
                  url: url,
                  dom: dom,
                  timeStamp: timeStamp,
                  isUpdate: updateStatus,
                  isInsert: insertStatus
                });
              }

              // get prediction
              currSuggestion = null;
              console.log("debug1", actionName, startHighlight);

              // get prediction results from backend
              getNextPredictions({ dom: dom }).then((result) => {
              predictions = suggestionFormatter(result.suggestion);
              console.log("Next Predictions: ", predictions);
              console.log("result from backend is bulk: ", result.isBulk);
              // when scrape in bulk
              if (result.isBulk) {
                  // when there is valid bulk predictions
                  if (predictions.length > 0) {
                    console.log("Bulk predictions: ", predictions);
                    isBulk = true;
                    bulkPredictions = predictions;
                    bulkIdx = 0;
                    bulkHandler();
                  }
                  // when no prediction
                  else {
                    isBulk = false;
                  }
              }
              else {
                  // when scrape not in bulk

                // for a single array of predictions sent back from synthesizer
                console.log("before filter length: " + predictions.length);
                console.log("unfiltered predictions: ", predictions);
                // filter the predictions array to remove any duplicates or invalid ones
                chrome.tabs.query({ active: true, windowId: scrapeWindowId }, function ([tab]) {
                    chrome.tabs.sendMessage(
                      tab.id,
                      { action: "filterPredictions", predictions : predictions },
                      (response) => {
                        if (response.filtered === undefined || response.filtered.length === 0) {
                          // when no valid prediction after filtering
                          currMode = "normal";
                          prevMode = null;
                          predMode = "normal"

                          let instruction = "No valid prediction generated, back to the manual mode, please 1) choose the action type in the panel, 2) hover your mouse over an element, 3) click the highlighted element";
                          showInstruction(instruction);
                          
                          console.log("line 414 change mode");
                          chrome.tabs.query(
                            { active: true, windowId: scrapeWindowId },
                            function ([tab]) {
                              chrome.tabs.sendMessage(
                                tab.id,
                                { action: "changeMode", mode: currMode, recordStarted: recordStarted },
                                (response) => {
                                  sendResponse(response);
                                }
                              );
                            }
                          );
                          return;
                        }

                        // when we have at least 1 valid predictions after filtering
                        predictions = response.filtered;
                        console.log("filter done with length: " + predictions.length);
                        predictionIdx = 0;

                        if (numDemonstrations >= intoSemiNum) {
                          prevMode = currMode;
                          currMode = "prediction";
                          if (numAcceptances < intoFullyNum) {
                            // in semi-auto mode
                            predMode = "semi";

                            let instruction = "In semi-automation mode, please wait for predictions to be visualized then accept, reject, or iterate through the list of predictions";
                            showInstruction(instruction);

                          } else {
                            // in fully-auto mode
                            predMode = "fully";
                          }
                        }
                        
                        console.log("line 451 change mode");
                        chrome.tabs.query(
                          { active: true, windowId: scrapeWindowId },
                          function ([tab]) {
                            chrome.tabs.sendMessage(
                              tab.id,
                              { action: "changeMode", mode: currMode, recordStarted: recordStarted },
                              (response) => {
                                //meaningless response. send response to avoid errors.
                                  
                                (response);
                              }
                            );
                          }
                        );
                        sentSuggestion = false;
                        suggestionHandler("sendActionDomToServer");
                        }
                        );
                      }
                    );
                }

              });
            }
          );
        }
      );
  }, time);

  // if (startHighlight) {
  //     tryNum = 15;
  //     if (!delaySent && startHighlight) {
  //         getElementExist("onUpdated");
  //     }
  // }
  // get current dom
}


/*
{
  “action”: {
                   “actionName”:“Click”,
                   “targetElement”:[ …. ](this is generated by selector generator.js),
                   "data": data1 (optional)
           },
  “dom”: “<html>…</html>”
}
*/
// turn xpath into dom element
function suggestionFormatter(suggestions) {
  console.log(suggestions);
  for (let i = 0; i < suggestions.length; i++) {
    suggestions[i].ele = suggestions[i].targetElementXpath;
    delete suggestions[i].targetElementXpath;
    suggestions[i].type = suggestions[i].actionType;
    delete suggestions[i].actionType;
    suggestions[i] = suggestionHandleInput(suggestions[i]);
  }
  return suggestions;
}


// filter
function filterPredictions(predictions) {
  console.log("before filter length: " + predictions.length)
  let filtered = [];
  chrome.tabs.query(
    { active: true, windowId: scrapeWindowId },
    function ([tab]) {
      chrome.tabs.sendMessage(
        tab.id,
        { action: "filterPredictions", predictions : predictions },
        (response) => {
          console.log("after filter length: " + response.filtered.length)
          predictions = response.filtered;
          filtered = response.filtered;
          return response.filtered;
        }
      );
    }
  );
}

// send scraped data
async function sendDataTimestamp(data, timeStamp) {
  const baseUrlPost = "http://localhost:3000/add_scraped_data";

  const urlParams = {
      data: data,
      timeStamp: timeStamp,
      isUpdate: updateStatus,
      isInsert: insertStatus
  };

  const response = await fetch(baseUrlPost, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(urlParams),
  });
}

// send actions
async function sendActionDomToServer(data) {
  console.log('append-action-and-dom data: ', data);
  const baseUrlPost = "http://localhost:3000/append-action-and-dom";
  let targetMatrix = data.parameter[0];
  let targetContent = targetMatrix;

  const urlParams = {
    action: {
      actionName: data.action,
      targetElement: targetContent
    },
      url: data.url,
    dom: data.dom,
    timeStamp: data.timeStamp,
    isUpdate: updateStatus,
    isInsert: insertStatus
  };
  // when using data from uploaded json
  if (data.action === "SendKeys" || data.action === "SendData") {
    urlParams.action.data = data.parameter[1];
  }

  const response = await fetch(baseUrlPost, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(urlParams),
  });

  // update isUpdate when the new action is sent back to backend
  // so we can start checking with backend every 500ms again
  updateStatus = false;
  insertStatus = false;
}

// send executed predictions in bulk mode
async function sendBulkToServer() {
  console.log("sendBulkToServer", bulkList);
  const baseUrlPost = "http://localhost:3000/append-bulk";

  var bulkSendList = []
  for (var i=0;i<bulkList.length;i++) {
      data = bulkList[i];
      let targetMatrix = data.parameter[0];
      let targetContent = targetMatrix;
      const urlParams = {
        action: {
          actionName: data.action,
          targetElement: targetContent,
        },
          url: data.url,
        timeStamp: data.timeStamp
      };
      if (data.action === "SendKeys" || data.action === "SendData") {
        urlParams.action.data = data.parameter[1];
      }
      bulkSendList.push(urlParams);
  }

  const response = await fetch(baseUrlPost, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(bulkSendList),
  });

  // update isUpdate when the new action is sent back to backend
  // so we can start checking with backend every 500ms again
  updateStatus = false;
  insertStatus = false;
}

// used to create overlaying banner with instructions on the page
function showInstruction(instruction) {
  chrome.tabs.query(
    { active: true, windowId: scrapeWindowId },
    function ([tab]) {
      chrome.tabs.sendMessage(
        tab.id,
        { action: "showInstruction", msg: instruction },
        (response) => {
          //meaningless response. send response to avoid errors.
          // sendResponse(response);
        }
      );
    }
  );
}

// get next prediction from the synthesizer
async function getNextPredictions(data) {
  console.log(data);
  const baseUrlPost = "http://localhost:3000/get-predictions";

  const urlParams = {
    currentDOM: data.dom,
  };
  chrome.tabs.query(
    { active: true, windowId: scrapeWindowId },
    function ([tab]) {
      chrome.tabs.sendMessage(
        tab.id,
        {
          action: "debug",
          msg: "sent post request to server to get next predictions",
        },
        (response) => {
          //meaningless response. send response to avoid errors.
          // sendResponse(response);
        }
      );
    }
  );

  let response = await fetch(baseUrlPost, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(urlParams),
  });

  let result = await response.json();
  return result;
}

// reformat json input in case of sendData
function suggestionHandleInput(suggestion) {
  console.log("suggestionHandleInput");
  // if (suggestion.type === "SendData") {
  //   console.log("suggestion.action === SendData");
  //   suggestion.jsonIdx = suggestion.dataParameter;
  //   delete suggestion.dataParameter;
  //   // let match = suggestion.jsonIdx.match(/(.*)\[([0-9]*)\]/);
  //   let match = suggestion.jsonIdx;
  //   match = match.replaceAll("[", " ");
  //   match = match.replaceAll("]", "");
  //   match = match.replaceAll(".", " ");
  //   let jsonlist = match.split(" ");

  //   let jsonTemp = jsonObj;
  //   for (let i = 0; i < jsonlist.length; i++) {
  //     jsonTemp = jsonTemp[jsonlist[i]];
  //   }

  //   suggestion.msg = jsonTemp;
  // }
  suggestion.msg = suggestion.dataParameter;
  console.log("suggestion: ", suggestion);
  return suggestion;
}

// turn xpath into DOM element
function getElementByXpath(xpath_expression) {
  return document.evaluate(
    xpath_expression,
    document,
    null,
    XPathResult.FIRST_ORDERED_NODE_TYPE,
    null
  ).singleNodeValue;
}

// visualize and handle predictions
function suggestionHandler(caller) {
  console.log("sent suggestion: ", sentSuggestion);
  if (predictions.length === 0) {
    return;
  }
  suggestion = predictions[predictionIdx];
  console.log("received suggestion " + suggestion.type + " " + suggestion.ele);
  console.log(suggestion);
  console.log("currMode: " + currMode);
  console.log("predMode: " + predMode);
  if (
    suggestion !== null &&
    currMode === "prediction" &&
    predMode === "fully"
  ) {
    console.log("debug fully: about to send automatic highlight");
    // if there're more than 1 predictions in fully-auto mode, switch back to semi mode so user can choose
    if (predictions.length > 1) {
      currMode == "prediction";
      predMode == "semi";
      let instruction = "More than 1 predictions generated in fully-auto mode, please iterate through the list of predictions and select the one of your choice";
      showInstruction(instruction);
      semiMode();
      return;
    }
    //before executing the suggestion, highlight the element
    // if (!startHighlight) {
      sentSuggestion = true;
      console.log("automatic mode highlight");
      automaticModeHighlight(suggestion);
      setTimeout(() => {
        //undo highlight
        automaticModeHighlightUndo(suggestion);
        console.log("debug2 automaticMode", "", startHighlight, suggestion);
        automaticMode(suggestion, "main");
      }, highlightDelayTime);
    // }
  } else if (
    suggestion !== null &&
    currMode === "prediction" &&
    predMode === "semi"
  ) {
    semiMode();
  } else {
    predMode = "normal";
    sentSuggestion = true;
    let instruction = "No valid prediction generated, Back to the manual mode, please 1) choose the action type in the panel, 2) hover your mouse over an element, 3) click the highlighted element";
    showInstruction(instruction);
    chrome.tabs.query(
      { active: true, windowId: scrapeWindowId },
      function ([tab]) {
        chrome.tabs.sendMessage(
          tab.id,
          { action: "debug", msg: "suggestion is null" },
          (response) => {
            //meaningless response. send response to avoid errors.
            sendResponse(response);
          }
        );
      }
    );
    // enable action buttons in popup
    chrome.runtime.sendMessage({
      action: "enableActions",
    });
  }
}

// function appendDoms(dom) {
//   domList.push(dom);
// }

// handles goBack
var onCommittedHandler = (event) => {
  console.log(
    "event detected for OnCommitted. " +
      event.transitionQualifiers +
      " " +
      event.transitionType
  );
  if (
    event.transitionQualifiers.includes("forward_back") &&
    (predMode == "normal" || predMode == "semi")
  ) {
    console.log(event);
    //save it to the storage if the recording is started
    let actionName = "GoBack";
    let parameters = [];
    if (recordStarted) {
        if (!isBulk) {
          console.log("manually append go back action");
          var timeStamp = new Date().getTime();
          appendAction(actionName, parameters, null, timeStamp);
        }
    }
  }
};

// handles goBack
var historyUpdateHandler = (event) => {
  console.log(
    "event detected for HistoryStateUpdated. " +
      event.transitionQualifiers +
      " " +
      event.transitionType
  );
  if (
    event.transitionQualifiers.includes("forward_back") &&
    (predMode == "normal" || predMode == "semi")
  ) {
    console.log(event);
    //save it to the storage if the recording is started
    let actionName = "GoBack";
    let parameters = [];
    if (recordStarted) {
        var timeStamp = new Date().getTime();
        appendAction(actionName, parameters, null, timeStamp);
    }
  }
};
chrome.webNavigation.onHistoryStateUpdated.addListener(historyUpdateHandler);
chrome.webNavigation.onCommitted.addListener(onCommittedHandler);

// check if an element exists on the active tab
async function getElementExist(caller) {
  delaySent = true;
  let elementExist = -1;
  console.log("getElementExist: ", elementExist, tryNum);
  // check {tryNum} many times before declaring not exist
  while (elementExist == -1 && tryNum > 0) {
    elementExist = await checkElementExist();
    tryNum--;
    console.log("getElementExist", elementExist, tryNum);
    if (elementExist != -1) {
      predictionIdx = elementExist;
      currSuggestion = predictions[predictionIdx];
      startHighlight = false;
      suggestionHandler(caller);
      delaySent = false;
      sentSuggestion = true;
      return;
    }
  }
  delaySent = false;
  // set alert when ele not found
  // doesn't matter in normal mode (user just clicking around not scraping)
  if (predMode != "normal") {
      chrome.tabs.query(
        { active: true, windowId: scrapeWindowId },
        function ([tab]) {
          chrome.tabs.sendMessage(
            tab.id,
            { action: "alertNotFound" },
            (response) => {
              //meaningless response. send response to avoid errors.
              sendResponse(response);
            }
          );
        }
      );
  }
}

// helper function that asks content.js to check if ele exists on current page
function checkElementExist() {
  let time = 1500;
  console.log("debug1 checkElementExist", predictions.length, predMode);
  if (predictions.length) {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log("debug1 checkElementExist 3");
        chrome.tabs.query(
          { active: true, windowId: scrapeWindowId },
          function ([tab]) {
            chrome.tabs.sendMessage(
              tab.id,
              { action: "checkEle", predictions: predictions, predMode: predMode },
              (response) => {
                console.log("debug1 checkElementExist", response);
                resolve(response);
              }
            );
          }
        );
      }, time);
    });
  } else {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(-1);
      }, time);
    });
  }
}

// check update status
// if the user wants to edit earlier actions
async function checkUpdate() {
  const baseUrlPost = "http://localhost:3000/check-update-status";

  const inputJson = {
    action: "check-update-status"
  };

  const response = await fetch(baseUrlPost, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(inputJson),
  });
  let result = await response.json();
  return result;
}

setInterval(function(){
  // only check update status when not currently updating
  // to avoid duplicated updates
  if (updateStatus == true) return;
  checkUpdate().then((response) => {
    if (response.status == true) {
      console.log("isUpdate is true");
      updateStatus = true;
      // notify content.js
      chrome.tabs.query(
        { active: true, windowId: scrapeWindowId }, function (tabs) {
          chrome.tabs.sendMessage(
            tabs[0].id,
            { action: "update", ele: response.ele },
            (response) => {
              console.log(tabs[0].id);
              // resolve(response);
            }
          );
        }
      );
    }
  });
}, 500);


async function checkInsert() {
  const baseUrlPost = "http://localhost:3000/check-insert-status";

  const inputJson = {
    action: "check-insert-status"
  };

  const response = await fetch(baseUrlPost, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(inputJson),
  });
  let result = await response.json();
  return result;
}

setInterval(function(){
  // only check update status when not currently updating
  // to avoid duplicated updates
  if (insertStatus == true) return;
  checkInsert().then((response) => {
    if (response.status == true) {
      console.log("isInsert is true");
      insertStatus = true;
      // notify content.js
      chrome.tabs.query(
        { active: true, windowId: scrapeWindowId }, function (tabs) {
          chrome.tabs.sendMessage(
            tabs[0].id,
            { action: "insert", ele: response.ele },
            (response) => {
              console.log(tabs[0].id);
              // resolve(response);
            }
          );
        }
      );
    }
  });
}, 500);



// check if the user wants to highlight a col/row
async function checkHighlight() {
  const baseUrlPost = "http://localhost:3000/check-highlight";

  const inputJson = {
    action: "check-highlight"
  };

  const response = await fetch(baseUrlPost, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(inputJson),
  });
  let result = await response.json();
  return result;
}

setInterval(function(){
  checkHighlight().then((response) => {
      chrome.tabs.query(
        { active: true, windowId: scrapeWindowId }, function (tabs) {
          chrome.tabs.sendMessage(
            tabs[0].id,
            { action: "visualize", ele: response.xpaths, visualize_enable: response.enable},
            (response) => {
              // console.log(tabs[0].id);
              // resolve(response);
            }
          );
        }
      );
  });
}, 500);


async function checkBulk() {
  const baseUrlPost = "http://localhost:3000/check-bulk";

  const inputJson = {
    action: "check-bulk"
  };

  const response = await fetch(baseUrlPost, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(inputJson),
  });
  let result = await response.json();
  // console.log("previous mode: ", previous_mode);
  // console.log("result status: ", result.status);
  return result; 
}

previous_mode = false;

setInterval(function(){
  checkBulk().then((response) => {
    if (response.status == true && response.status != previous_mode) {
      console.log("!!!!!!!!Set to Bulk Mode!!!!!!!!!!");
      previous_mode = true;
      chrome.tabs.query(
        { active: true, windowId: scrapeWindowId }, function (tabs) {
          chrome.tabs.sendMessage(
            tabs[0].id,
            { action: "changeToBulk"},
            (response) => {
              // console.log(tabs[0].id);
              // resolve(response);
            }
          );
        }
      );
    }
    if (response.status == false && response.status != previous_mode) {
      console.log("Exit Bulk Mode");
      previous_mode = false;
      isBulk = false;
    }
    });
}, 500);


async function checkScrapeNext() {
  const baseUrlPost = "http://localhost:3000/check-scrape-next";

  const inputJson = {
    action: "check-scrape-next"
  };

  const response = await fetch(baseUrlPost, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(inputJson),
  });
  let result = await response.json();
  return result;
}


setInterval(function(){
  checkScrapeNext().then((response) => {
    if (response.status == true) {
      console.log("scrape next is", response.status);
      chrome.tabs.query(
        { active: true, windowId: scrapeWindowId }, function (tabs) {
          chrome.tabs.sendMessage(
            tabs[0].id,
            { action: "scrapeNext", stats: response.status},
            (response) => {
              // console.log(tabs[0].id);
              // resolve(response);
            }
          );
        }
      );
    }
  });
}, 500);



// check if backend wants to check text of an element according to xpath.
async function checkTextQuery() {
  const baseUrlPost = "http://localhost:3000/check-text-query";

  const inputJson = {
    action: "check-text-query"
  };

  const response = await fetch(baseUrlPost, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(inputJson),
  });
  let result = await response.json();
  return result;
}


setInterval(function(){
  checkTextQuery().then((response) => {
      chrome.tabs.query(
        { active: true, windowId: scrapeWindowId }, function (tabs) {
          chrome.tabs.sendMessage(
            tabs[0].id,
            { action: "checkTextQuery", ele: response.xpaths},
            (response) => {
              // console.log(tabs[0].id);
              // resolve(response);
            }
          );
        }
      );
  });
}, 500);


async function sendTextQuery(data) {
  const baseUrlPost = "http://localhost:3000/send-text-query";

  const urlParams = {
      data: data
  };

  const response = await fetch(baseUrlPost, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(urlParams),
  });
}



// --------------------------------------- Integration ---------------------------------------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // console.log(sender.id);
  // console.log(message.action);
  // --------------------------------------- Action_Output Panel ---------------------------------------
  if (message.action === "downloadMode") {
    if (currMode === message.action) {
      return;
    }
    currMode = "Download";
    chrome.tabs.query(
      { active: true, windowId: scrapeWindowId },
      function ([tab]) {
        chrome.tabs.sendMessage(
          tab.id,
          { action: "changeMode", mode: currMode, recordStarted: recordStarted },
          (response) => {
            //meaningless response. send response to avoid errors.
            sendResponse(response);
          }
        );
      }
    );
  }

  else if (message.action === "getMode") {
    
  console.log("line 1239 change mode");
    chrome.tabs.query(
      { active: true, windowId: scrapeWindowId },
      function ([tab]) {
        chrome.tabs.sendMessage(
          tab.id,
          { action: "changeMode", mode: currMode, recordStarted: recordStarted },
          (response) => {
            //meaningless response. send response to avoid errors.
            sendResponse(response);
          }
        );
      }
    );
  } else if (message.action === "clickNonlink") {
    // clickNonlink = true;
  } else if (message.action === "manualShowPrediction") {
    startHighlight = false;
    suggestionHandler("manualShowPrediction");
  }

  // --------------------------------------- Prediction Panel ---------------------------------------
  else if (message.action === "predictionRejectAction") {
    // resets mode among manual/semi-auto/auto
    predMode = "normal";
    numAcceptances = 0;
    numDemonstrations = 0;
    numFullyExeute = 0;

    // change mode to normal
    currMode = "normal";
    
  console.log("line 1271 change mode");
    chrome.tabs.query(
      { active: true, windowId: scrapeWindowId },
      function ([tab]) {
        chrome.tabs.sendMessage(
          tab.id,
          { action: "changeMode", mode: currMode, recordStarted: recordStarted },
          (response) => {
            //meaningless response. send response to avoid errors.
            sendResponse(response);
          }
        );
      }
    );
    let instruction = "In manual mode, please 1) choose the action type in the panel, 2) hover your mouse over an element, 3) click the highlighted element";
    showInstruction(instruction);
    // enable action buttons in popup
    chrome.runtime.sendMessage({
      action: "enableActions",
    });
  } else if (message.action === "appendAction") {
    // receive action that the user performs (or mimic user's action)
    // forward it to the synthesizer
    currActionName = message.actionName;
    currParameters = message.parameters;
    console.log("appendAction");
    console.log(message);
    appendAction(message.actionName, message.parameters, message.url, message.timeStamp);
  } else if (message.action === "appendDom") {
    // appendDoms(message.dom);
    domList.push(message.dom);
  } else if (message.action === "getActionList") {
    sendResponse(actionList);
  } else if (message.action === "getDomList") {
    sendResponse(domList);
  } else if (message.action === "startRecording") {
    recordStarted = true;
    currMode = "normal";
    
    console.log("line 1310 change mode");
    chrome.tabs.query(
      { active: true, windowId: scrapeWindowId },
      function ([tab]) {
        currUrl = tab.url;
        console.log(currUrl);
        chrome.tabs.sendMessage(
          tab.id,
          { action: "changeMode", mode: currMode, recordStarted: recordStarted },
          (response) => {
            //meaningless response. send response to avoid errors.
            sendResponse(response);
          }
        );
      }
    );
  } else if (message.action === "setTraceName") {
    traceName = message.traceName;
  } else if (message.action === "getTraceName") {
    sendResponse(traceName);
  } else if (message.action === "stopRecording") {
    recordStarted = false;
    currMode = null;
    chrome.tabs.query(
      { active: true, windowId: scrapeWindowId },
      function ([tab]) {
        chrome.tabs.sendMessage(
          tab.id,
          { action: "changeMode", mode: currMode, recordStarted: recordStarted },
          (response) => {
            //meaningless response. send response to avoid errors.
            sendResponse(response);
          }
        );
        chrome.tabs.sendMessage(
          tab.id,
          { action: "removeInstructions", mode: currMode, recordStarted: recordStarted },
          (response) => {
            //meaningless response. send response to avoid errors.
            sendResponse(response);
          }
        );
      }
    );
  } else if (message.action === "getRecordingState") {
    sendResponse(recordStarted);
  } else if (message.action === "clear") {
    clearStorage();
  } else if (message.action === "changeMode") {
    recordingActionMode = message.mode;
  } else if (message.action === "getRecordingMode") {
    sendResponse(recordingActionMode);
  } else if (message.action === "predictionAccepted") {
    numAcceptances++;
    console.log("debug fully: " + numAcceptances);
    if (numAcceptances >= intoFullyNum || isBulk == true) {
      console.log("debug fully: into fully!");
      currMode = "prediction";
      predMode = "fully";
    }
  } else if (message.action === "outputText") {
    chrome.tabs.query(
      { active: true, windowId: scrapeWindowId },
      function ([tab]) {
        chrome.tabs.sendMessage(
          tab.id,
          { action: "debug", msg: "show output" + message.output },
          (response) => {
            //meaningless response. send response to avoid errors.
            sendResponse(response);
          }
        );
      }
    );
    chrome.runtime.sendMessage({ action: "output", output: message.output });
    outputs.push(message.output);
    sendDataTimestamp(message.output, message.timeStamp);
  } else if (message.action === "outputLink") {
    if (message.output == null) {
      chrome.runtime.sendMessage({ action: "output", output: null });
    } else {
      chrome.runtime.sendMessage({ action: "output", output: message.output });
      outputs.push(message.output);
    }
    sendDataTimestamp(message.output, message.timeStamp);
  } else if (message.action === "outputDownload") {
    if (message.output == null) {
      chrome.runtime.sendMessage({ action: "output", output: null });
    } else {
      chrome.downloads.download({ url: message.output });
      chrome.runtime.sendMessage({
        action: "output",
        output: 'Download from "' + message.output,
      });
      outputs.push(message.output);
    }
  } else if (message.action === "sendTextQuery") {
    sendTextQuery(message.output);
  }
  else {
    console.log("undefined message!");
  }
  sendResponse("from background");
  return true;
});
