# WebRobot frontend Chrome plugin

## Install

Download this folder as a zip and unzip to a folder. Then, import that folder as a chrome plugin following steps below:

* 1. Open a Chrome browser, goto Chrome Settings using three dots on the top right corner.
* 2. Goto **Extensions** panel.
* 3. Enable developer mode on the top right.
* 4. Load unpacked WebRobot plugin.

## Use

Before using this plugin, please be sure that there's a new backend server running in the backend. This plugin requires communications with the backend. Also, after completing each task, a restart of backend is required. It can't automatically restart now.
