#!/bin/sh
# install required libraries
npm install
# start web server
npm start
