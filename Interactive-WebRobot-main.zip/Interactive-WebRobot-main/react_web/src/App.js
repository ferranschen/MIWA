import * as React from "react";
import Header from "./components/Header";
import Steppers from "./components/Steppers";
import TaskCreate from "./components/task/TaskCreate";
import TaskDemo from "./components/task/TaskDemo";
import TaskDone from "./components/task/TaskDone";
import Box from '@mui/material/Box';


function App() {
  const [stepNum, setStepNum] = React.useState(0);
  const [colNum, setColNum] = React.useState(1);
  const [isNameFieldFilled, setIsNameFieldFilled] = React.useState(false);

  const [inputFileName, setInputFileName] = React.useState("");
  const [inputData, setInputData] = React.useState(null);
  const [inputDataColName, setInputDataColName] = React.useState("");
  const [taskName, setTaskName] = React.useState(null);
  const [openCreateTextSection, setOpenCreateTextSection] =
    React.useState(false);
  const [rows, setRows] = React.useState([]);

  const [colNames, setColNames] = React.useState([]);
  const [colNamesField, setColNamesField] = React.useState([]);
  React.useEffect(() => {
    if(stepNum === 0){
    setColNum(1);
    setColNames([]);
    setIsNameFieldFilled(false);
    }
  }, [stepNum]);

  return (
    <Box sx={{m:1}}>
      <Header></Header>

      <Steppers
        taskName={taskName}
        colNum={colNum}
        inputData={inputData}
        onSetStep={setStepNum}
        isNameFieldFilled={isNameFieldFilled}
        rows={rows}
      />
      {stepNum === 0 ? (
        <React.Fragment>
          <TaskCreate
            onSetColNum={setColNum}
            colNum={colNum}
            colNames={colNames}
            inputFileName={inputFileName}
            inputData={inputData}
            taskName={taskName}
            inputDataColName={inputDataColName}
            openCreateTextSection={openCreateTextSection}
            setInputFileName={setInputFileName}
            setInputData={setInputData}
            setInputDataColName={setInputDataColName}
            setTaskName={setTaskName}
            setOpenCreateTextSection={setOpenCreateTextSection}
            setColNames={setColNames}
            setIsNameFieldFilled={setIsNameFieldFilled}
            colNamesField={colNamesField}
            setColNamesField={setColNamesField}
          />
        </React.Fragment>
      ) : stepNum === 1 ? (
        <React.Fragment>
          <TaskDemo
            colNum={colNum}
            colNames={colNames}
            inputData={inputData}
            inputFileName={inputFileName}
            inputDataColName={inputDataColName}
            setRows={setRows}
            setStepNum={setStepNum}
          />
        </React.Fragment>
      ) : stepNum === 2 ? (
        <React.Fragment>
          <TaskDone 
            finalRows={rows}
            colNames={colNames}
          />
        </React.Fragment>
      ) : (
                <React.Fragment></React.Fragment>
              )}
    </Box>
  );
}

export default App;
