import * as React from "react";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { styled } from "@mui/material/styles";
import Typography from "@mui/material/Typography";
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

export default function DenseTable({ inputFileName, colName, rows }) {
  const handleDrag = (event) => {
    let sendData = {
      inputfilename: inputFileName,
      key: "text",
      value: event.target.outerText,
    };
    event.dataTransfer.setData("text/plain", JSON.stringify(sendData));
  };
  if (!inputFileName) {
    return <Table disabled={true}></Table>
  }
  return (
    <Box>
      <Typography variant="h6" gutterBottom component="div">
        Input Data: {inputFileName}
      </Typography>
      <TableContainer component={Paper} sx={{ maxHeight: 400, mt: 1 }}>
        <Table
          stickyHeader
          sx={{ minWidth: 300 }}
          aria-labelledby="tableTitle"
          aria-label="sticky customized table"
        >
          <TableHead>
            <TableRow>
              <StyledTableCell sx={{p:1}}>{colName}</StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => (
              <StyledTableRow
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell
                sx={{p:1}}
                  draggable
                  onDragStart={handleDrag}
                  component="th"
                  scope="row"
                >
                  {row}
                </TableCell>
              </StyledTableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}
