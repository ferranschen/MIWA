import * as React from "react";
import Fade from "@mui/material/Fade";
import Tables from "./Tables";

export default function InputOutput(props) {
  const [scratchedData, setScratchedData] = React.useState([]);

  React.useEffect(() => {
    if (props.updatedRowData.length === 0) {
      setScratchedData([]);
    }
    if (props.updatedRowData && props.updatedRowData.length > 0) {
      const scratched = [];
      for (let i = 0; i < props.updatedRowData.length; i += props.colNum) {
        const tmp = [];
        for (let j = 0; j < props.colNum; j += 1) {
          if (i + j < props.updatedRowData.length) {
            tmp.push(props.updatedRowData[i + j]);
          } else {
            tmp.push({ data: "", timeStamp: 0 });
          }
        }
        scratched.push(tmp);
      }
      setScratchedData(scratched);
    }
  }, [props.colNum, props.updatedRowData]);

  return (
    <Fade in={true}>
      <div>
        <Tables colNames={props.colNames} colNum={props.colNum} rows={scratchedData} />
      </div>
    </Fade>
  );
}
