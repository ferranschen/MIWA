import * as React from "react";

import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import Fade from "@mui/material/Fade";
import Tables from "./Tables";
import InputDataTable from "./InputDataTable";
import Backend from "./apis/Backend";

export default function InputOutput(props) {
  const [scratchedData, setScratchedData] = React.useState([]);
  const [inputData, setInputData] = React.useState([]);
  const [isInputSet, setIsInputSet] = React.useState(false);
  React.useEffect(() => {
    if (props.inputData && inputData !== props.inputData && !isInputSet) {
      setInputData(props.inputData);
      var Data = {};
      Data[props.inputDataColName] = props.inputData;
      let DataWithPath = {};
      DataWithPath["data"] = props.inputData;
      DataWithPath["dataPath"] = {};
      for (let i = 0; i < props.inputData.length; i++) {
        DataWithPath["dataPath"][i] = props.inputDataColName + "[" + i + "]";
      }
      console.log(DataWithPath);
      console.log(Data);
      let params = { input: Data, inputWithPath: DataWithPath, colNum: props.colNum };
      Backend.post("/set-input-data", {
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
        params
      }).then(function (response) {
        console.log(response);
        return response.data;
      });
    } else if (!isInputSet) {
      let params = { input: null, inputWithPath: null, colNum: props.colNum };
      Backend.post("/set-input-data", {
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
        params
      }).then(function (response) {
        console.log(response);
        return response.data;
      });
    }
    setIsInputSet(true);
    if (props.updatedRowData.length === 0) {
      setScratchedData([]);
    }
    if (props.updatedRowData && props.updatedRowData.length > 0) {
      const scratched = [];
      for (let i = 0; i < props.updatedRowData.length; i += props.colNum) {
        const tmp = [];
        for (let j = 0; j < props.colNum; j += 1) {
          if (i + j < props.updatedRowData.length) {
            tmp.push(props.updatedRowData[i + j]);
          } else {
            tmp.push({ data: "", timeStamp: 0 });
          }
        }
        scratched.push(tmp);
      }
      setScratchedData(scratched);
    }
    return () => {
      setIsInputSet(false);
    };
  }, [props.colNum, props.updatedRowData]);
  if (!props.inputData) {
    return (
      <div>
        <Fade in={true}>
          <Grid container rowSpacing={2} columnSpacing={2} sx={{ height: '10%' }}>
            <Grid item xs={12} sx={{ height: '10%' }}>
              <Typography variant="h6" gutterBottom component="div">
                Scraped Items
              </Typography>
              <Tables h={230} colNames={props.colNames} colNum={props.colNum} rows={scratchedData} />
            </Grid>
          </Grid>
        </Fade>
      </div>
    );
  }
  return (
    <div>
      <Fade in={true}>
        <Grid container rowSpacing={2} columnSpacing={2}>
          <Grid
            disalbed={true}
            item xs={6}>
            <InputDataTable
              inputFileName={props.inputFileName}
              colName={props.inputDataColName}
              rows={props.inputData}
            ></InputDataTable>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="h6" gutterBottom component="div">
              Scraped Items
            </Typography>
            <Tables h={400} colNames={props.colNames} colNum={props.colNum} rows={scratchedData} />
          </Grid>
        </Grid>
      </Fade>
    </div>
  );
}
