import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import AddIcon from "@mui/icons-material/Add";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Backend from "./apis/Backend";
import Popup from "./popup/Popup";
import { Box } from "@mui/system";



const columns = [
  { id: "timeStamp", label: "Timestamp", minWidth: 100 },
  { id: "action", label: "Activity", minWidth: 100 },
  { id: "operation", label: "", minWidth: 100 },
];


export default function NewActivity({ setButtonState, updatedActionList }) {
  const [openPopup, setOpenPopup] = React.useState(false);
  const [dialogMode, setDialogMode] = React.useState(null);
  const [dataToDelete, setDataToDelete] = React.useState(null);
  const [dataToUpdate, setDataToUpdate] = React.useState(null);
  const [rownum, setRownum] = React.useState(0);

  const ActivityEndRef = React.useRef(null);


  const scrollToBottom = () => {
    ActivityEndRef.current.scrollIntoView({ behavior: 'smooth' });
  };

  const handleDeleteDialog = (data) => {
    setOpenPopup(true);
    setDialogMode("delete");
    setDataToDelete(data);
  };

  const handleEditDialog = (data) => {
    setOpenPopup(true);
    setDialogMode("edit");
    setDataToUpdate(data);
  };

  const handleInsertDialog = (data) => {
    setOpenPopup(true);
    setDialogMode("insert");
    setDataToUpdate(data);
  };

  const handleClearData = () => {
    console.log("clear data");
    Backend.post("/clear_data", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: {},
    }).then(function (response) {
      return response.data;
    });
  };

  React.useEffect(() => {
    if (updatedActionList.length > rownum) {
      setTimeout(() => { scrollToBottom() }, 200);
      setRownum(updatedActionList.length);
    }
  }, [updatedActionList, rownum]);

  return (
    <div>
      <Typography
        variant="h6"
        gutterBottom
        component="div"
        sx={{ mt: 1, mb: 1 }}
      >
        Activity
      </Typography>
      <Button
        sx={{ mr: 1, mb: 2 }}
        onClick={() => {
          handleClearData();
          setButtonState("initial");
        }}
        variant="contained"
        color="error"
      >
        CLEAR
      </Button>
      <Paper sx={{ width: "100%", bgcolor: "f5f7fa" }} elevation={8}>
        <TableContainer sx={{ minHeight: 440, maxHeight: 440 }}>
          <Table aria-label="sticky table">
            <TableHead>
              <TableRow>
                {columns.map((column) => (
                  <TableCell
                    sx={{ p: 1, }}
                    key={column.id}
                    align={column.align}
                    style={{ top: 57, minWidth: column.minWidth }}
                  >
                    {column.label}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {updatedActionList.map((row) => {
                return (
                  <TableRow
                    hover
                    role="checkbox"
                    tabIndex={-1}
                    key={row["timeStamp"]}
                  >
                    {columns.map((column) => {
                      if (column.id === "timeStamp") {
                        let newDate = new Date();
                        newDate.setTime(row["timeStamp"]);
                        return (
                          <TableCell sx={{ m: 0, p: 1, pt: 0, pb: 0 }} key={row["timeStamp"] + "_timeStamp"} align={column.align}>
                            {newDate.toLocaleTimeString()}
                          </TableCell>
                        );
                      }
                      else if (column.id === "operation") {
                        return (
                          <TableCell sx={{ m: 0, p: 0 }} key={row["timeStamp"] + "_operation"} align={column.align}>
                            <Tooltip title="Edit">
                              <IconButton
                                onClick={() =>
                                  handleEditDialog(row["timeStamp"])
                                }
                                sx={{ ml: 0, mr: 0, pr: 0, pl: 0 }}
                              >
                                <EditIcon />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Delete">
                              <IconButton
                                onClick={() =>
                                  handleDeleteDialog(row["timeStamp"])
                                }
                                sx={{ ml: 0, mr: 0, pr: 0, pl: 0 }}
                              >
                                <DeleteIcon />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Insert">
                              <IconButton
                                onClick={() =>
                                  handleInsertDialog(row["timeStamp"])
                                }
                                sx={{ ml: 0, mr: 0, pr: 0, pl: 0 }}
                              >
                                <AddIcon />
                              </IconButton>
                            </Tooltip>
                          </TableCell>
                        );
                      }
                      else {
                        let action = "";
                        switch (row["name"]) {
                          case "ScrapeText":
                            action = "Scrape text of";
                            break;
                          case "ScrapeLink":
                            action = "Scrape link of";
                            break;
                          case "SendKeys":
                            action = "Send keys";
                            break;
                          case "SendData":
                            action = "Send data";
                            break;
                          case "Click":
                            action = "Click";
                            break;
                          case "GoBack":
                            action = "Go back to the previous page";
                          default:
                            break;
                        }
                        if (row["data"] !== undefined && row["data"].length > 0) {
                          action += " " + "\"" + row["data"] + "\"";
                        }

                        return (
                          <TableCell sx={{ m: 0, p: 1, pt: 0, pb: 0 }} key={row["timeStamp"] + "_action"} align={column.align}>
                            <Tooltip title={action}>
                              <Box>
                                {action.length > 20 ? action.substring(0, 20) + "..." : action}
                              </Box>
                            </Tooltip>
                          </TableCell>
                        );
                      }
                    })}
                  </TableRow>
                );
              })}
              <div ref={ActivityEndRef} />
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
      <Popup
        mode={dialogMode}
        openPopup={openPopup}
        setOpenPopup={setOpenPopup}
        dataToDelete={dataToDelete}
        dataToUpdate={dataToUpdate}
      ></Popup>
    </div>
  );
}
