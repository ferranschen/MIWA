import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from "@mui/material";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Backend from "../apis/Backend";

export default function Popup({
  mode,
  openPopup,
  setOpenPopup,
  setStepNum,
  dataToDelete,
  dataToUpdate,
}) {
  // TODO:  remove by timestamp
  const closePopup = () => {
    setOpenPopup(false);
  };
  const handleDeleteData = (data) => {
    Backend.post("/delete_data", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: { timeStamp: data },
    }).then(function (response) {
      return response.data;
    });
    closePopup();
  };
  const handleEditData = (data) => {
    Backend.post("/update_data", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: { timeStamp: data },
    }).then(function (response) {
      return response.data;
    });
    closePopup();
  };
  const handleInsertData = (data) => {
    Backend.post("/insert_data", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: { timeStamp: data },
    }).then(function (response) {
      return response.data;
    });
    closePopup();
  };
  return mode === "non-exist" ? (
    <Dialog onClose={closePopup} open={openPopup} maxWidth="sm">
      <DialogTitle>
        <div>
          <Typography variant="h6">Warning</Typography>
        </div>
      </DialogTitle>
      <DialogContent><DialogContentText>
        Next data is not found (e.g. you have reached the end of webpage). Do you want to stop here? If not, please continue demonstrating.</DialogContentText></DialogContent>
      <DialogActions>
        <Button variant="contained" color="error" onClick={() => { setStepNum(2); }}>Stop Scraping</Button>

        <Button

          onClick={closePopup}
          variant="contained"
          color="success"
        >
          Continue
        </Button>
      </DialogActions>
    </Dialog>
  ) : mode === "delete" ? (
    <Dialog onClose={closePopup} open={openPopup} maxWidth="sm">
      <DialogTitle>
        <div>
          <Typography variant="h6">Delete the selected item?</Typography>
        </div>
      </DialogTitle>
      <DialogContent></DialogContent>
      <DialogActions>
        <Button onClick={closePopup}>Cancel</Button>

        <Button
          onClick={() => handleDeleteData(dataToDelete)}
          variant="contained"
          color="error"
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  ) : mode === "edit" ? (
    <Dialog onClose={closePopup} open={openPopup} maxWidth="sm">
      <DialogTitle>
        <div>
          <Typography variant="h6">Edit element</Typography>
        </div>
      </DialogTitle>
      <DialogContent>
        <DialogContentText>
          Click Edit and go back to the website to select element again.
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={closePopup}>Cancel</Button>
        <Button
          onClick={() => handleEditData(dataToUpdate)}
          variant="contained"
          color="success"
        >
          Edit
        </Button>
      </DialogActions>
    </Dialog>
  ) : (
    <Dialog onClose={closePopup} open={openPopup} maxWidth="sm">
      <DialogTitle>
        <div>
          <Typography variant="h6">Insert element</Typography>
        </div>
      </DialogTitle>
      <DialogContent>
        <DialogContentText>
          Click insert and go back to the website to select an element.
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={closePopup}>Cancel</Button>
        <Button
          onClick={() => handleInsertData(dataToUpdate)}
          variant="contained"
          color="success"
        >
          Insert
        </Button>
      </DialogActions>
    </Dialog>
  );
}
