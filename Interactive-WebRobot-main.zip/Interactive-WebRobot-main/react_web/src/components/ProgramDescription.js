import * as React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import NLGenerate from "./helper/NLGenerate.js";
import { Typography } from "@mui/material";
import Grid from "@mui/material/Grid";
import KeyboardDoubleArrowRightIcon from "@mui/icons-material/KeyboardDoubleArrowRight";

export default function ProgramDescription({
  buttonState,
  setButtonState,
  deactivateProgram,
  setIsProgramGenerated,
  colNames,
  programCounter,
  setProgramCounter,
  isClickedScrapeNext,
  setIsClickedScrapeNext,
}) {
  const [NLstatus, setNLstatus] = React.useState("generating");
  const [tP, setTp] = React.useState([]);
  const [marginTop, setMarginTop] = React.useState(0);
  const [programStruct, setProgramStruct] = React.useState([]);
  React.useEffect(() => {
    let statement_count = programStruct.length;
    console.log("programCounter: ", programCounter);

    if (programCounter === 0) {
      setProgramCounter(1);
    }
    if (programCounter >= statement_count) {
      console.log("programCounter >= statement_count");
      setProgramCounter(1);
      setMarginTop(9.9);
    } else if (programStruct[programCounter] === "loop") {
      console.log("loop");
      setMarginTop(9.9);
    } else if (programStruct[programCounter] === "statement") {
      console.log("statement");
      console.log("programCounter: ", programCounter);
      if (programCounter === 1) {
        console.log("statement");
        setMarginTop(9.9);
      } else {
        console.log("statement");
        setMarginTop(marginTop + 3.3);
      }
    }
    console.log(marginTop);

    console.log("-----------------dddd");
    console.log("programStruct: ");
    console.log(programStruct);
    console.log("-----------------dddd");
  }, [isClickedScrapeNext, programCounter]);
  React.useEffect(() => {
    if (NLstatus !== "generating" && tP.length !== 0) {
      setIsProgramGenerated(true);
    } else {
      setIsProgramGenerated(false);
      if (buttonState === "running") {
        deactivateProgram();
        setButtonState("initial");
      }
    }
  }, [tP, NLstatus]);
  return (
    <Card sx={{ mt: 1, minHeight: 440, maxHeight: 440 }} elevation={8}>
      <CardContent>
        <Grid container>
          {isClickedScrapeNext === true ? (
            <Grid item xs={1}>
              <KeyboardDoubleArrowRightIcon
                sx={{ ml: 0, mt: marginTop }}
                color="primary"
              />
            </Grid>
          ) : null}
          <Grid item xs={11}>
            <NLGenerate
              setTp={setTp}
              setNLstatus={setNLstatus}
              colNames={colNames}
              programCounter={programCounter}
              setProgramStruct={setProgramStruct}
            ></NLGenerate>
            {NLstatus === "generating" ? (
              <Typography>
                Please demonstrate more steps to generate a program or edit your
                actions history to regenerate the program.
              </Typography>
            ) : (
              tP
            )}
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
}
