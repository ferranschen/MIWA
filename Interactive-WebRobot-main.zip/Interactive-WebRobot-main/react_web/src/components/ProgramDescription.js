import * as React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import NLGenerate from "./helper/NLGenerate.js";
import { Typography } from "@mui/material";

export default function ProgramDescription({ buttonState, setButtonState, deactivateProgram, setIsProgramGenerated, colNames }) {
  const [NLstatus, setNLstatus] = React.useState("generating");
  const [tP, setTp] = React.useState([]);
  React.useEffect(() => {
    if (NLstatus !== "generating" && tP.length !== 0) {
      setIsProgramGenerated(true);
    } else {
      setIsProgramGenerated(false);
      if (buttonState === "running") {
        deactivateProgram();
        setButtonState("initial");
      }
    }
  }, [tP, NLstatus]);
  return (
    <Card sx={{ mt: 1, minHeight: 440, maxHeight: 440 }} elevation={8}>
      <CardContent>

        <NLGenerate setTp={setTp} setNLstatus={setNLstatus} colNames={colNames}></NLGenerate>
        {NLstatus === "generating" ? (<Typography>Please demonstrate more steps to generate a program or edit your actions history to regenerate the program.</Typography>) : tP}

      </CardContent>
    </Card>
  );
}
