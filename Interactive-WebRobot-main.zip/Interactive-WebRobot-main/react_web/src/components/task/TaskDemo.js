import * as React from "react";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import InputOutput from "../InputOutput";
import NewActivity from "../NewActivity";
import Backend from "../apis/Backend";
import ProgramDescription from "../ProgramDescription";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import Popup from "../popup/Popup";
import Warnings from "../warnings/Warnings";



export default function TaskDemo(props) {
  const [buttonState, setButtonState] = React.useState("initial");
  const [rows, setRows] = React.useState([]);
  const [actionList, setActionList] = React.useState([]);
  const [isProgramGenerated, setIsProgramGenerated] = React.useState(false);
  const [openPopup, setOpenPopup] = React.useState(false);
  const [warningStatus, setWarningStatus] = React.useState("");
  const [showWarning, setShowWarning] = React.useState(false);
  const activateProgram = async () => {
    console.log("activateProgram");
    await Backend.post("/active-scrape-in-bulk-mode", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: {},
    }).then(function (response) {
      return response.data;
    });
  };
  const deactivateProgram = async () => {
    console.log("deactivate");
    await Backend.post("/deactive-scrape-in-bulk-mode", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: {},
    }).then(function (response) {
      return response.data;
    });
  };
  const handlePause = () => {
    console.log("pause");
    Backend.post("/pause", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: {},
    }).then(function (response) {
      return response.data;
    });
  };
  const handleResume = () => {
    console.log("resume");
    Backend.post("/restart_program", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: {},
    }).then(function (response) {
      return response.data;
    });
  };
  const handleScrapeNext = () => {
    console.log("scrape next");
    Backend.post("/request_scrape_next", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: {},
    }).then(function (response) {
      return response.data;
    });
  };
  const checkIsEntryValid = () => {
    Backend.post("/is_entry_valid", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: {},
    }).then(function (response) {
      // console.log(response.data.status);
      switch (response.data.status) {
        case 1:
          setOpenPopup(true);
          setWarningStatus("nonexistent");
          break;
        case 2:
          setShowWarning(true);
          setWarningStatus("empty-string");
          break;
        case 3:
          setShowWarning(true);
          setWarningStatus("wrong-format");
          break;
        case 4:
          setShowWarning(true);
          setWarningStatus("duplications");
          break;
        default:
          break;
      }
      return response.data.status;
    });
  }
  React.useEffect(() => {
    const timer = setInterval(() => {
      getScratchedData();
      checkIsEntryValid();
    }, 800);
    return () => {
      clearInterval(timer);
    };
  }, []);
  const getScratchedData = async () => {
    const scratchedData = await Backend.post("/get_scraped_data", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: {},
    }).then(function (response) {
      return response.data;
    });
    const actionLists = await Backend.post(
      "/get_scraped_data_with_description",
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
        params: {},
      }
    ).then(function (response) {
      return response.data;
    });
    setActionList(actionLists);
    setRows(scratchedData);
    props.setRows(scratchedData);
  };
  return (
    <Box sx={{ mt: 0, flexGrow: 1 }}>
      <Stack spacing={0}>
        <InputOutput
          inputData={props.inputData}
          inputFileName={props.inputFileName}
          inputDataColName={props.inputDataColName}
          colNum={props.colNum}
          colNames={props.colNames}
          updatedRowData={rows}
        ></InputOutput>
        {showWarning ? <Warnings showWarning={showWarning} setShowWarning={setShowWarning} alertType={warningStatus}></Warnings> : null}
        {openPopup ?
          <Popup
            mode="non-exist"
            openPopup={openPopup}
            setOpenPopup={setOpenPopup}
            setStepNum={props.setStepNum}
          ></Popup> : null}
        <Grid container rowSpacing={1} columnSpacing={1}>
          <Grid item xs={6}>
            <NewActivity setButtonState={setButtonState} updatedActionList={actionList} updatedRowData={rows} />
          </Grid>
          <Grid item xs={6}>
            <Typography sx={{ mt: 1, mb: 1 }} variant="h6">
              Program Description
            </Typography>
            {isProgramGenerated ? <Box> <Button
              variant="contained"
              color="success"
              sx={{ mr: 1, mb: 1 }}
              onClick={() => {
                handleScrapeNext();
              }}
            >
              Scrape Next
            </Button>
              {buttonState === "initial" ? (
                <Button
                  sx={{ mr: 1, mb: 1 }}
                  variant="contained"
                  onClick={() => {
                    setButtonState("running");
                    activateProgram();
                  }}
                >
                  Auto-Scrape
                </Button>
              ) : buttonState === "running" ? (
                null
              ) : (
                null
              )}
              {buttonState === "running" ? (
                <Button
                  sx={{ mr: 1, mb: 1 }}
                  variant="contained"
                  color="error"
                  onClick={() => {
                    setButtonState("initial");
                    deactivateProgram();
                  }}
                >
                  Stop Scraping
                </Button>) : null}
            </Box> : <Box> <Button
              disabled
              variant="contained"
              color="success"
              sx={{ mr: 1, mb: 1 }}
              onClick={() => {
                handleScrapeNext();
              }}
            >
              Scrape Next
            </Button>
              {buttonState === "initial" ? (
                <Button
                  disabled
                  sx={{ mr: 1, mb: 1 }}
                  variant="contained"
                  onClick={() => {
                    setButtonState("running");
                    activateProgram();
                  }}
                >
                  Auto-Scrape
                </Button>
              ) : buttonState === "running" ? (
                null
              ) : (
                null
              )}
              {buttonState === "running" ? (
                <Button
                  sx={{ mr: 1, mb: 1 }}
                  variant="contained"
                  color="error"
                  onClick={() => {
                    setButtonState("initial");
                    deactivateProgram();
                  }}
                >
                  Stop Scraping
                </Button>) : null}
            </Box>}

            <ProgramDescription buttonState={buttonState} setButtonState={setButtonState} deactivateProgram={deactivateProgram} setIsProgramGenerated={setIsProgramGenerated} colNames={props.colNames}></ProgramDescription>
          </Grid>
        </Grid>
      </Stack>
    </Box >
  );
}
