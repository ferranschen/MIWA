import * as React from 'react';
import { DataGrid, GridToolbarContainer, GridToolbarExport } from '@mui/x-data-grid';
import { Box } from '@mui/system';

function CustomToolbar() {
    return (
        <GridToolbarContainer>
            <GridToolbarExport />
        </GridToolbarContainer>
    );
}
let coln = [];
let rows = [];
export default function TaskDone({ finalRows, colNames }) {
    const [is_table_ready, set_table_ready] = React.useState(false);
    React.useEffect(() => {
        set_table_ready(false);
        console.log(finalRows);
        console.log(colNames);
        if (finalRows.length > 0 && colNames.length > 0) {
            coln = [];
            rows = [];
            colNames.forEach((colName, index) => {
                coln.push({ field: colName, headerName: colName, width: 150, editable: true });
            });
            console.log(coln);
            finalRows.forEach((row, index) => {
                let row_id = Math.floor(index / colNames.length);
                if (rows[row_id] === undefined) {
                    rows[row_id] = {};
                }
                rows[row_id]['id'] = row_id + 1;
                console.log(rows[row_id]);
                rows[row_id][colNames[index % colNames.length]] = finalRows[index].data;
            });
            set_table_ready(true);
        }


    }, [finalRows, colNames]);
    return (
        is_table_ready ? (
            <Box sx={{ height: 400, width: '100%', mt: 1 }}>

                <DataGrid rows={rows} columns={coln} components={{
                    Toolbar: CustomToolbar,
                }} />

            </Box>) : (<div></div>)
    );
}
