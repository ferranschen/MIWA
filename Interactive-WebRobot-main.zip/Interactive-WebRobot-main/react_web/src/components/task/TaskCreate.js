import * as React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import Fade from "@mui/material/Fade";
import InputDataTable from "../InputDataTable";

export default function TaskCreate({
  colNum,
  colNames,
  inputFileName,
  inputData,
  taskName,
  inputDataColName,
  openCreateTextSection,
  onSetColNum,
  setInputFileName,
  setInputData,
  setInputDataColName,
  setTaskName,
  setOpenCreateTextSection,
  setColNames,
  setIsNameFieldFilled,
  colNamesField,
  setColNamesField,
}) {
  const showFile = async (e) => {
    e.preventDefault();
    const reader = new FileReader();
    const fileName = e.target.files[0].name;
    setInputFileName(fileName);

    reader.onload = async (e) => {
      const text = e.target.result;
      const jsonText = JSON.parse(text);
      setInputData(jsonText[Object.keys(jsonText)[0]]);
      setInputDataColName(Object.keys(jsonText)[0]);
      setOpenCreateTextSection(true);
    };
    reader.readAsText(e.target.files[0]);
  };
  React.useEffect(() => {
    setIsNameFieldFilled(false);
  },[]);
  React.useEffect(() => {
    setColNamesField([]);
    if (colNum > 10 || colNum < 1) {
      alert("Number of columns should be between 1 and 10");
    } else {
      var tempNameField = [];
      for (let i = 0; i < colNum; i++) {
        tempNameField.push(
          <TextField
            required
            key={i}
            id={`colName${i}`}
            label={`Column Name ${i + 1}`}
            variant="outlined"
            margin="dense"
            fullWidth
            onChange={(e) => {
              let names = [...colNames];
              console.log(e.target.value);
              if (e.target.value === "") {
                setIsNameFieldFilled(false);
              } else if (names.includes(e.target.value)) {
                alert("Column names should be unique");
                e.target.value = "";
              } else {
                names[i] = e.target.value;
                console.log(names);
                setColNames(names);
                console.log(colNames);
                names = names.filter((name) => name);
                console.log(names);
                if (names.length === colNum) {
                  console.log(names);
                  setIsNameFieldFilled(true);
                }
                names.forEach((name) => {
                  if (name == "" || name.length === 0) {
                    setIsNameFieldFilled(false);
                  }
                });
              }
            }}
          />
        );
      }
      setColNamesField(tempNameField);
    }
  }, [colNum, colNames, setColNames]);
  return (
    <Fade in={true}>
      <Box
        component="form"
        sx={{
          mt: 4,
          "& .MuiTextField-root": { m: 1, width: "25ch" },
        }}
        noValidate
        autoComplete="off"
      >
        <Typography variant="h6">Create a Task</Typography>
        <div>
          <TextField
            required
            id="outlined-required"
            label="Task Name"
            onChange={(e) => setTaskName(e.target.value)}
            InputLabelProps={{
              shrink: true,
            }}
            value={taskName}
          />
          <TextField
            required
            id="outlined-number"
            label="Number of Columns"
            type="number"
            inputProps={{ min: 1, max: 10 }}
            onChange={(e) => {
              setColNamesField([]);
              setColNames([]);
              setIsNameFieldFilled(false);
              onSetColNum(parseInt(e.target.value));
            }}
            InputLabelProps={{
              shrink: true,
            }}
            value={colNum <= 0 ? undefined : colNum}
          />
          {colNamesField}
          <TextField
            id="outlined-number"
            label="Input Data"
            type="file"
            InputLabelProps={{
              shrink: true,
            }}
            onChange={(e) => {
              showFile(e);
            }}
          />
          {openCreateTextSection === true ? (
            <Fade in={true}>
              <Box sx={{ maxWidth: 708 }}>
                <InputDataTable
                  inputFileName={inputFileName}
                  colName={inputDataColName}
                  rows={inputData}
                ></InputDataTable>
              </Box>
            </Fade>
          ) : (
            <div></div>
          )}
        </div>
      </Box>
    </Fade>
  );
}
