import * as React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import Grid from "@mui/material/Grid";

export default function ActionAreaCard({
  stepNum,
  gifFilename,
  cardDecription,
}) {
  return (
    <Card sx={{ mb: 1 }}>
      <CardActionArea>
        <CardContent>
          <Grid container spacing={2}>
            <Grid item xs={6} md={6}>
              <Typography gutterBottom variant="h6" component="div">
                Step {stepNum}
              </Typography>
              <Typography sx={{ mb: 2 }} variant="body2" color="text.primary">
                {cardDecription}
              </Typography>
            </Grid>

            <Grid item xs={6} md={6}>
              <CardMedia
                component="img"
                height="300"
                image={gifFilename}
                alt={gifFilename}
              />
            </Grid>
          </Grid>
        </CardContent>
      </CardActionArea>
    </Card>
  );
}
