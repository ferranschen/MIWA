import React from 'react'
import Alert from '@mui/material/Alert';
import AlertTitle from '@mui/material/AlertTitle';
import { Box } from '@mui/system';
export default function Warnings({ alertType, showWarning, setShowWarning }) {
    const [timoutId, setTimeoutId] = React.useState(null);

    React.useEffect(() => {
        console.log(alertType);
        if (timoutId) {
            clearTimeout(timoutId);
            setTimeoutId(null);
        }
        const timeId = setTimeout(() => {
            setShowWarning(false);
        }, 5000);
        setTimeoutId(timeId);

        return () => {
            clearTimeout(timeId);
        };
    }, [alertType]);
    if (!showWarning) {
        return null;
    }
    return (
        <Box sx={{ width: '100%' }}>
            {alertType === "empty-string" ? (
                <Alert onClose={() => { setShowWarning(false) }} severity="warning">
                    <AlertTitle>Warning</AlertTitle>
                    Found an empty scraped data.
                </Alert>
            ) : alertType === "wrong-format" ? (
                <Alert onClose={() => { setShowWarning(false) }} severity="warning">
                    <AlertTitle>Warning</AlertTitle>
                    Found a scraped data with wrong format.
                </Alert>
            ) : alertType === "duplications" ? (
                <Alert onClose={() => { setShowWarning(false) }} severity="warning">
                    <AlertTitle>Warning</AlertTitle>
                    Found duplicate of last scraped data. This data will be ignored.
                </Alert>
            ) : null}
        </Box>
    )
}
