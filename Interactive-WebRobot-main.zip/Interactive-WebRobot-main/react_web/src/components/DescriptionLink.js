import React from "react";
import Link from "@mui/material/Link";

export default function DescriptionLink({ text }) {
  return (
    <Link
      sx={{color: "main.primary" }}
      href="#"
      underline="always"
    >
      {text}
    </Link>
  );
}
