import Backend from "../apis/Backend";
import Typography from "@mui/material/Typography";
import React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";

var StatementType;
(function (StatementType) {
  StatementType[(StatementType["CLICK"] = 0)] = "CLICK";
  StatementType[(StatementType["SCRAPETEXT"] = 1)] = "SCRAPETEXT";
  StatementType[(StatementType["SCRAPELINK"] = 2)] = "SCRAPELINK";
  StatementType[(StatementType["DOWNLOAD"] = 3)] = "DOWNLOAD";
  StatementType[(StatementType["GOBACK"] = 4)] = "GOBACK";
  StatementType[(StatementType["EXTRACTURL"] = 5)] = "EXTRACTURL";
  StatementType[(StatementType["SENDKEYS"] = 6)] = "SENDKEYS";
  StatementType[(StatementType["SENDDATA"] = 7)] = "SENDDATA";
  StatementType[(StatementType["FOREACH"] = 8)] = "FOREACH";
  StatementType[(StatementType["FOREACHINPUT"] = 9)] = "FOREACHINPUT";
  StatementType[(StatementType["WHILE"] = 10)] = "WHILE";
  StatementType[(StatementType["UNDEFINED"] = 11)] = "UNDEFINED";
})(StatementType || (StatementType = {}));
let columns = ["shop", "address", "phone"];
let alphabet = " abcdefghijklmnopqrstuvwxyz";
let translatedProgram = "";
let tProgram = [];
let originalProgram = "";
let prevProgram = "";
// special case for while loop
let hasWhile = false;
let ForEachQueue = [];
let columnID = 0;
let columnNames = [];
let columnNum = 0;
let ForEachInfo = "";
let ForEachJSX;
let ForEachLine = 0;
let ForEachInputInfo = "";
let ForEachInputJSX;
let textByIndexStrings = [];

function parseProgram(program, startline, endline) {
  const lines = program.split("\n");
  const body = [];
  let currentLine = startline;
  while (
    currentLine < endline &&
    lines[currentLine] !== undefined &&
    lines[currentLine].length > 0
  ) {
    const line = lines[currentLine];
    if (isForLoop(line)) {
      const endline = getForLoopEndLine(lines, currentLine);
      // console.log("===========================");
      // console.log(`Found for loop from line ${currentLine} to ${endline}`);
      const statement = parseStatement(line, currentLine, program);
      statement.body = parseProgram(program, currentLine + 1, endline);
      // console.log(`parsed program: ${JSON.stringify(statement.body)}`);
      // console.log("===========================");
      body.push(statement);
      currentLine = endline + 1;
    } else {
      const statement = parseStatement(line, currentLine, program);
      body.push(statement);
      currentLine = statement.line + 1;
    }
  }
  return body;
}

function getForLoopEndLine(lines, startLine) {
  let currentLine = startLine + 1;
  let counter = 1;
  while (counter > 0) {
    const line = lines[currentLine];
    if (line.includes("{")) {
      counter++;
    } else if (line.includes("}")) {
      counter--;
    }
    currentLine++;
  }
  return currentLine - 1;
}
function isForLoop(line) {
  return line.includes("ForEach") || line.includes("While");
}
function parseStatement(line, lineNumber, program) {
  const match = line.match(
    /^\s*(Click|ScrapeText|ScrapeLink|Download|GoBack|ExtractURL|SendKeys|SendData|ForEach|While)\s*(.*)$/
  );
  if (match) {
    switch (match[1]) {
      case "Click":
        return {
          text: match[0],
          type: statementTypeFromString(match[1]),
          xPathInput: match[2],
          xPathOutput: "",
          body: [],
          condition: "",
          line: lineNumber,
        };
      case "ScrapeText":
        return {
          text: match[0],
          type: statementTypeFromString(match[1]),
          xPathInput: match[2],
          xPathOutput: "",
          body: [],
          condition: "",
          line: lineNumber,
        };
      case "ScrapeLink":
        return {
          text: match[0],
          type: statementTypeFromString(match[1]),
          xPathInput: match[2],
          xPathOutput: "",
          body: [],
          condition: "",
          line: lineNumber,
        };
      case "Download":
        return {
          text: match[0],
          type: statementTypeFromString(match[1]),
          xPathInput: match[2],
          xPathOutput: "",
          body: [],
          condition: "",
          line: lineNumber,
        };
      case "GoBack":
        return {
          text: match[0],
          type: statementTypeFromString(match[1]),
          xPathInput: "",
          xPathOutput: "",
          body: [],
          condition: "",
          line: lineNumber,
        };
      case "ExtractURL":
        return {
          text: match[0],
          type: statementTypeFromString(match[1]),
          xPathInput: "",
          xPathOutput: "",
          body: [],
          condition: "",
          line: lineNumber,
        };
      case "SendKeys":
        return {
          text: match[0],
          type: statementTypeFromString(match[1]),
          xPathInput: getXpathInput(match[0]),
          xPathOutput: getXpathOutput(match[0]),
          body: [],
          condition: "",
          line: lineNumber,
        };
      case "SendData":
        return {
          text: match[0],
          type: statementTypeFromString(match[1]),
          xPathInput: getXpathInput(match[0]),
          xPathOutput: getXpathOutput(match[0]),
          body: [],
          condition: "",
          line: lineNumber,
        };
      case "ForEach":
        if (match[0].includes("ForEachInput")) {
          return {
            text: match[0],
            type: statementTypeFromString("ForEachInput"),
            xPathInput: "",
            xPathOutput: "",
            body: [],
            condition: "",
            line: lineNumber,
          };
        } else {
          return {
            text: match[0],
            type: statementTypeFromString(match[1]),
            xPathInput: "",
            xPathOutput: "",
            body: [],
            condition: "",
            line: lineNumber,
          };
        }
      case "While":
        return {
          text: match[0],
          type: statementTypeFromString(match[1]),
          xPathInput: "",
          xPathOutput: "",
          body: [],
          condition: "",
          line: lineNumber,
        };
      default:
        return {
          text: match[0],
          type: statementTypeFromString(match[1]),
          xPathInput: "",
          xPathOutput: "",
          body: [],
          condition: "",
          line: lineNumber,
        };
    }
  }
  return {
    text: "",
    type: StatementType.UNDEFINED,
    xPathInput: "",
    xPathOutput: "",
    body: [],
    condition: "",
    line: lineNumber,
  };
}
function getXpathInput(xPath) {
  // Example:
  // const xpath = `//div[@id='searchControl']/input[@id='map_query'] iphone 12`;
  // const xpathInput = `iphone 12`;
  // const xpathOutput = `//div[@id='searchControl']/input[@id='map_query']`;

  let pattern =
    /^SendKeys\s(?:|<v\d+>)(?:\/{1,2}[a-z]+(?:|\[\d+]|\[\S+'.+']))*\s(.+)$/;
  let keys = xPath.replace(pattern, "$1");

  return keys;
}
function getXpathOutput(xPath) {
  // Example:
  // const xpath = `//div[@id='searchControl']/input[@id='map_query'] iphone 12`;
  // const xpathInput = `iphone 12`;
  // const xpathOutput = `//div[@id='searchControl']/input[@id='map_query']`;
  const output = xPath.slice(0, xPath.indexOf(" "));
  return output;
}
function statementTypeFromString(type) {
  switch (type) {
    case "Click":
      return StatementType.CLICK;
    case "ScrapeText":
      return StatementType.SCRAPETEXT;
    case "ScrapeLink":
      return StatementType.SCRAPELINK;
    case "Download":
      return StatementType.DOWNLOAD;
    case "GoBack":
      return StatementType.GOBACK;
    case "ExtractURL":
      return StatementType.EXTRACTURL;
    case "SendKeys":
      return StatementType.SENDKEYS;
    case "SendData":
      return StatementType.SENDDATA;
    case "ForEach":
      return StatementType.FOREACH;
    case "ForEachInput":
      return StatementType.FOREACHINPUT;
    case "While":
      return StatementType.WHILE;
    default:
      return StatementType.UNDEFINED;
  }
}

function translate(program, stepNum, isIndent, isWithAlphabet, programCounter) {
  // debug program (Array of Statement)

  program.map((statement) => {
    switch (statement.type) {
      case StatementType.CLICK:
        console.log(
          `${isIndent ? "\t" : ""}${
            isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
          }. Click ${getTextHelper(statement.xPathInput, 0)}`
        );
        translatedProgram += `${isIndent ? "\t" : ""}${
          isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
        }. Click ${getTextHelper(statement.xPathInput, 0)}\n`;
        let clickJSX = (
          <Typography sx={isIndent ? { ml: 4 } : {}}>
            {isWithAlphabet ? (
              <Box sx={{ display: "inline" }}>{alphabet[stepNum]}.</Box>
            ) : (
              <Box sx={{ display: "inline" }}>{"Step " + stepNum}.</Box>
            )}
            <Box sx={{ ml: 1, display: "inline" }}>
              Click{" "}
              <Button
                sx={{ textDecorationLine: "underline", m: 0, p: 0 }}
                onMouseEnter={() => {
                  let params = { index: statement.line + 1, enable: true };
                  Backend.post("/highlight_by_index", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
                onMouseLeave={() => {
                  let params = { index: statement.line + 1, enable: false };
                  console.log("Off");
                  Backend.post("/highlight_by_index", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
              >
                {textByIndexStrings[statement.line]
                  ? textByIndexStrings[statement.line].length > 0
                    ? textByIndexStrings[statement.line]
                    : "Next Page"
                  : "Next Page"}
              </Button>
            </Box>
          </Typography>
        );
        if (isWithAlphabet) {
          ForEachQueue.push(clickJSX);
        }
        tProgram.push(clickJSX);

        stepNum++;
        break;
      case StatementType.SCRAPETEXT:
        console.log(
          `${isIndent ? "\t" : ""}${
            isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
          }. Get the text of ${columns[getColumnNumberHelper(statement.line)]}`
        );
        translatedProgram += `${isIndent ? "\t" : ""}${
          isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
        }. Get the text of ${columns[getColumnNumberHelper(statement.line)]}\n`;
        let tempColumnID1 = columnID;
        let tempColumn1 = columnNum;
        console.log(columnNum);
        console.log(columnNames[tempColumn1]);

        let scrapeTextJSX = (
          <Typography
            sx={
              isIndent
                ? { display: "flex", alignItems: "center", ml: 4 }
                : { display: "flex", alignItems: "center" }
            }
          >
            {isWithAlphabet ? (
              <Box sx={{ display: "inline" }}>{alphabet[stepNum]}.</Box>
            ) : (
              <Box sx={{ display: "inline" }}>{"Step " + stepNum}.</Box>
            )}
            <Box sx={{ ml: 1, display: "inline" }}>
              Get the text of{" "}
              <Button
                sx={{ textDecorationLine: "underline", m: 0, p: 0 }}
                onMouseEnter={() => {
                  let params = { columnID: tempColumnID1, enable: true };
                  Backend.post("/highlight_by_column", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
                onMouseLeave={() => {
                  let params = { columnID: tempColumnID1, enable: false };
                  console.log("Off");
                  Backend.post("/highlight_by_column", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
              >
                {columnNames[tempColumn1]}
              </Button>
            </Box>
          </Typography>
        );
        if (isWithAlphabet) {
          ForEachQueue.push(scrapeTextJSX);
        }
        tProgram.push(scrapeTextJSX);
        columnID++;
        stepNum++;
        columnNum++;
        break;
      case StatementType.SCRAPELINK:
        console.log(
          `${isIndent ? "\t" : ""}${
            isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
          }. Get the link of ${columns[getColumnNumberHelper(1)]}`
        );
        translatedProgram += `${isIndent ? "\t" : ""}${
          isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
        }. Get the link of ${columns[getColumnNumberHelper(1)]}\n`;
        let tempColumnID2 = columnID;
        let tempColumn2 = columnNum;
        console.log(columnNum);
        console.log(columnNames[columnNum]);
        let scrapeLinkJSX = (
          <Typography sx={isIndent ? { ml: 4 } : {}}>
            {isWithAlphabet ? (
              <Box sx={{ display: "inline" }}>{alphabet[stepNum]}.</Box>
            ) : (
              <Box sx={{ display: "inline" }}>{"Step " + stepNum}.</Box>
            )}
            <Box sx={{ ml: 1, display: "inline" }}>
              Get the link of{" "}
              <Button
                sx={{ textDecorationLine: "underline", m: 0, p: 0 }}
                onMouseEnter={() => {
                  let params = { columnID: tempColumnID2, enable: true };
                  Backend.post("/highlight_by_column", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
                onMouseLeave={() => {
                  let params = { columnID: tempColumnID2, enable: false };
                  console.log("Off");
                  Backend.post("/highlight_by_column", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
              >
                {columnNames[tempColumn2]}
              </Button>
            </Box>
          </Typography>
        );
        if (isWithAlphabet) {
          ForEachQueue.push(scrapeLinkJSX);
        }
        tProgram.push(scrapeLinkJSX);
        columnID++;
        stepNum++;
        columnNum++;
        break;
      case StatementType.DOWNLOAD:
        console.log(
          `${isIndent ? "\t" : ""}${
            isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
          }. Download ${getTextHelper(statement.xPathInput, 3)}`
        );
        translatedProgram += `${isIndent ? "\t" : ""}${
          isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
        }. Download ${getTextHelper(statement.xPathInput, 3)}\n`;

        tProgram.push(
          <Typography sx={isIndent ? { ml: 4 } : {}}>
            {isWithAlphabet ? (
              <Box sx={{ display: "inline" }}>{alphabet[stepNum]}.</Box>
            ) : (
              <Box sx={{ display: "inline" }}>{"Step " + stepNum}.</Box>
            )}
            <Box sx={{ ml: 1, display: "inline" }}>
              Download{" "}
              <Button
                sx={{ textDecorationLine: "underline", m: -1 }}
                onMouseEnter={() => {
                  let params = { index: statement.line + 1, enable: true };
                  Backend.post("/highlight_by_loop", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
                onMouseLeave={() => {
                  let params = { index: statement.line + 1, enable: false };
                  console.log("Off");
                  Backend.post("/highlight_by_loop", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
              >
                {getTextHelper(statement.xPathInput, 3)}
              </Button>
            </Box>
          </Typography>
        );

        stepNum++;
        break;
      case StatementType.GOBACK:
        console.log(
          `${isIndent ? "\t" : ""}${
            isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
          }. Return to the previous page`
        );
        translatedProgram += `${isIndent ? "\t" : ""}${
          isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
        }. Return to the previous page\n`;

        tProgram.push(
          <Typography sx={isIndent ? { ml: 4 } : {}}>
            {isWithAlphabet ? (
              <Box sx={{ display: "inline" }}>{alphabet[stepNum]}.</Box>
            ) : (
              <Box sx={{ display: "inline" }}>{"Step " + stepNum}.</Box>
            )}
            <Box sx={{ ml: 1, display: "inline" }}>
              Return to the previous page
            </Box>
          </Typography>
        );

        stepNum++;
        break;
      case StatementType.SENDKEYS:
        console.log(
          `${isIndent ? "\t" : ""}${
            isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
          }. Enter ${statement.xPathInput} to ${statement.xPathOutput}`
        );
        translatedProgram += `${isIndent ? "\t" : ""}${
          isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
        }. Enter ${statement.xPathInput} to ${statement.xPathOutput}\n`;

        let sendKeyJSX = (
          <Typography sx={isIndent ? { ml: 4 } : {}}>
            {isWithAlphabet ? (
              <Box sx={{ display: "inline" }}>{alphabet[stepNum]}.</Box>
            ) : (
              <Box sx={{ display: "inline" }}>{"Step " + stepNum}.</Box>
            )}
            <Box sx={{ ml: 1, display: "inline" }}>
              Enter {statement.xPathInput} to{" "}
              <Button
                sx={{ textDecorationLine: "underline", m: 0, p: 0 }}
                onMouseEnter={() => {
                  let params = { index: statement.line + 1, enable: true };
                  Backend.post("/highlight_by_index", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
                onMouseLeave={() => {
                  let params = { index: statement.line + 1, enable: false };
                  console.log("Off");
                  Backend.post("/highlight_by_index", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
              >
                {textByIndexStrings[statement.line]
                  ? textByIndexStrings[statement.line].length > 0
                    ? textByIndexStrings[statement.line]
                    : "Search Box"
                  : "Search Box"}
              </Button>
            </Box>
          </Typography>
        );
        tProgram.push(sendKeyJSX);

        if (isWithAlphabet) {
          ForEachQueue.push(sendKeyJSX);
        }
        stepNum++;
        break;
      case StatementType.SENDDATA:
        console.log(
          `${isIndent ? "\t" : ""}${
            isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
          }. Enter ${statement.xPathInput} to ${statement.xPathOutput}`
        );
        translatedProgram += `${isIndent ? "\t" : ""}${
          isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
        }. Enter ${statement.xPathInput} to ${statement.xPathOutput}\n`;
        let sendDataJSX = (
          <Typography sx={isIndent ? { ml: 4 } : {}}>
            {isWithAlphabet ? (
              <Box sx={{ display: "inline" }}>{alphabet[stepNum]}.</Box>
            ) : (
              <Box sx={{ display: "inline" }}>{"Step " + stepNum}.</Box>
            )}
            <Box sx={{ ml: 1, display: "inline" }}>
              Send an input to{" "}
              <Button
                sx={{ textDecorationLine: "underline", m: 0, p: 0 }}
                onMouseEnter={() => {
                  let params = { index: statement.line + 1, enable: true };
                  Backend.post("/highlight_by_index", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
                onMouseLeave={() => {
                  let params = { index: statement.line + 1, enable: false };
                  console.log("Off");
                  Backend.post("/highlight_by_index", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
              >
                {textByIndexStrings[statement.line]
                  ? textByIndexStrings[statement.line].length > 0
                    ? textByIndexStrings[statement.line]
                    : "Search Box"
                  : "Search Box"}
              </Button>
            </Box>
          </Typography>
        );
        tProgram.push(sendDataJSX);

        if (isWithAlphabet) {
          ForEachQueue.push(sendDataJSX);
        }

        stepNum++;
        break;
      case StatementType.FOREACH:
        console.log(
          `${isIndent ? "\t" : ""}${
            isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
          }. Find a list of matched elements (hover to see the matched elements in the target webpage). For each element,`
        );
        translatedProgram += `${isIndent ? "\t" : ""}${
          isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
        }. Find a list of matched elements (hover to see the matched elements in the target webpage). For each element,\n`;
        if (ForEachInfo === statement.text) {
          tProgram.push(
            <Typography sx={isIndent ? { ml: 4 } : {}}>
              {isWithAlphabet ? (
                <Box sx={{ display: "inline" }}>{alphabet[stepNum]}.</Box>
              ) : (
                <Box sx={{ display: "inline" }}>{"Step " + stepNum}.</Box>
              )}
              <Box sx={{ ml: 1, display: "inline" }}>
                Find a list of{" "}
                <Button
                  sx={{ textDecorationLine: "underline", m: 0, p: 0 }}
                  onMouseEnter={() => {
                    let params = { index: ForEachLine + 1, enable: true };
                    Backend.post("/highlight_by_loop", {
                      headers: {
                        "Access-Control-Allow-Origin": "*",
                      },
                      params,
                    }).then(function (response) {
                      console.log(response);
                      return response.data;
                    });
                  }}
                  onMouseLeave={() => {
                    let params = { index: ForEachLine + 1, enable: false };
                    console.log("Off");
                    Backend.post("/highlight_by_loop", {
                      headers: {
                        "Access-Control-Allow-Origin": "*",
                      },
                      params,
                    }).then(function (response) {
                      console.log(response);
                      return response.data;
                    });
                  }}
                >
                  matched elements
                </Button>{" "}
                (hover to see the matched elements in the target webpage). For
                each element,
              </Box>
            </Typography>
          );
          ForEachJSX = null;
          ForEachInfo = "";
          let num = ForEachQueue.length;
          for (let i = 0; i < num; i++) {
            tProgram.push(ForEachQueue[i]);
          }
          stepNum++;
          break;
        }
        ForEachInfo = statement.text;
        ForEachLine = statement.line;
        ForEachJSX = (
          <Typography sx={isIndent ? { ml: 4 } : {}}>
            {isWithAlphabet ? (
              <Box sx={{ display: "inline" }}>{alphabet[stepNum]}.</Box>
            ) : (
              <Box sx={{ display: "inline" }}>{"Step " + stepNum}.</Box>
            )}
            <Box sx={{ ml: 1, display: "inline" }}>
              Find a list of{" "}
              <Button
                sx={{ textDecorationLine: "underline", m: 0, p: 0 }}
                onMouseEnter={() => {
                  let params = { index: statement.line + 1, enable: true };
                  Backend.post("/highlight_by_loop", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
                onMouseLeave={() => {
                  let params = { index: statement.line + 1, enable: false };
                  console.log("Off");
                  Backend.post("/highlight_by_loop", {
                    headers: {
                      "Access-Control-Allow-Origin": "*",
                    },
                    params,
                  }).then(function (response) {
                    console.log(response);
                    return response.data;
                  });
                }}
              >
                matched elements
              </Button>{" "}
              (hover to see the matched elements in the target webpage). For
              each element,
            </Box>
          </Typography>
        );
        tProgram.push(ForEachJSX);

        translate(statement.body, 1, true, true, programCounter);
        stepNum++;
        break;
      case StatementType.FOREACHINPUT:
        console.log(
          `${isIndent ? "\t" : ""}${
            isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
          }. Find a list of inputs from the input file. For each input data,`
        );
        translatedProgram += `${isIndent ? "\t" : ""}${
          isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
        }. Find a list of inputs from the input file. For each input data,\n`;
        if (ForEachInputInfo === statement.text) {
          tProgram.push(
            <Typography sx={isIndent ? { ml: 4 } : {}}>
              {isWithAlphabet ? (
                <Box sx={{ display: "inline" }}>{alphabet[stepNum]}.</Box>
              ) : (
                <Box sx={{ display: "inline" }}>{"Step " + stepNum}.</Box>
              )}
              <Box sx={{ ml: 1, display: "inline" }}>
                Find a list of inputs from the input file. For each input data,
              </Box>
            </Typography>
          );
          ForEachInputJSX = null;
          ForEachInputInfo = "";
          let num = ForEachQueue.length;
          for (let i = 0; i < num; i++) {
            tProgram.push(ForEachQueue[i]);
          }
          stepNum++;
          break;
        }
        ForEachInputInfo = statement.text;
        ForEachInputJSX = (
          <Typography sx={isIndent ? { ml: 4 } : {}}>
            {isWithAlphabet ? (
              <Box sx={{ display: "inline" }}>{alphabet[stepNum]}.</Box>
            ) : (
              <Box sx={{ display: "inline" }}>{"Step " + stepNum}.</Box>
            )}
            <Box sx={{ ml: 1, display: "inline" }}>
              Find a list of inputs from the input file. For each input data,
            </Box>
          </Typography>
        );
        tProgram.push(ForEachInputJSX);

        translate(statement.body, 1, true, true, programCounter);
        stepNum++;
        break;
      case StatementType.WHILE:
        console.log(
          `${isIndent ? "\t" : ""}${
            isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
          }. Repeat the previous step(s)\n`
        ); // TODO
        translatedProgram += `${isIndent ? "\t" : ""}${
          isWithAlphabet ? alphabet[stepNum] : "Step " + stepNum
        }. Repeat the previous step(s)\n`; // TODO
        hasWhile = true;
        translate(statement.body, 1, false, false, programCounter);

        stepNum++;
        break;
      default:
        break;
    }
  });
}
function getTextHelper(xPath, select) {
  switch (select) {
    case 0:
      return `Search`;
    case 1:
      return `Rating`;
    case 2:
      return `Price`;
    case 3:
      return `Picture 1`;
  }
  return `Undefined`;
}
function getColumnNumberHelper(line) {
  return line % 3;
}

function resetParameters() {
  translatedProgram = "";
  tProgram = [];
  originalProgram = "";
  prevProgram = "";
  hasWhile = false;
  ForEachQueue = [];
  columnID = 0;
  columnNames = [];
  columnNum = 0;
  ForEachInfo = "";
  ForEachJSX = null;
  ForEachInputInfo = "";
  ForEachInputJSX = null;
  textByIndexStrings = [];
}
function TranslateProgram(props) {
  columnNames = [];
  columnNum = 0;
  columnID = 0;
  columnNames = props.colNames;
  translatedProgram = "";
  tProgram = [];
  textByIndexStrings = [];
  props.setTp([]);
  props.setNLstatus("generating");

  let ProgramLen = originalProgram.split("\n").length;
  for (let i = 0; i < ProgramLen; i++) {
    Backend.post("/get_text_by_index", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: { index: i + 1 },
    }).then(function (response) {
      // console.log("text by index: " + (i +1 ) + " data: " + response.data.text);
      textByIndexStrings[i] = response.data.text;
      return response.data.text;
    });
  }
  const transFunction = async () => {
    const lines = originalProgram.split("\n");
    console.log("lines:", lines);
    translate(
      parseProgram(originalProgram, 0, lines.length),
      1,
      false,
      false,
      props.programCounter
    );
    if (hasWhile) {
      console.log("has while:", translatedProgram);
      const lines = translatedProgram.split("\n");
      const stepCount = lines.filter((line) => line.includes("Step")).length;
      console.log("step count:", stepCount);
      tProgram.push(
        <Typography>
          <Box sx={{ display: "inline" }}>
            Step {stepCount}. Repeat the previous step(s)
          </Box>
        </Typography>
      );
    }
    props.setTp(tProgram);
    props.setNLstatus("NL Generated");
  };
  setTimeout(transFunction, 1500);
}

function parseProgramStruct(program, props) {
  let lines = program.split("\n");
  let programStruct = [];
  let programLen = lines.length;
  // for each line
  for (let i = 0; i < programLen; i++) {
    // if line contains "ForEach" or "While"
    if (lines[i].includes("ForEach") || lines[i].includes("While")) {
      programStruct.push("loop");
    } else if (
      lines[i].includes("ScrapeText") ||
      lines[i].includes("ScrapeLink") ||
      lines[i].includes("GoBack") ||
      lines[i].includes("Click") ||
      lines[i].includes("GoTo") ||
      lines[i].includes("ScrapeImage") ||
      lines[i].includes("ScrapeRating")
    ) {
      programStruct.push("statement");
    }
  }
  console.log("-----------------asdasd");
  console.log("program struct:", programStruct);
  console.log("-----------------asdasd");
  props.setProgramStruct([]);
  props.setProgramStruct(programStruct);
  return programStruct;
}

export default function NLGenerate(props) {
  const getColumnNumber = async () => {
    const programInfo = await Backend.post("/get-program-info", {
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      params: {},
    }).then(function (response) {
      return response.data;
    });
    originalProgram = programInfo.program;
    if (originalProgram === undefined || originalProgram.programType === -1) {
      resetParameters();
      props.setTp([]);
      props.setNLstatus("generating");
    }
    if (originalProgram !== undefined && originalProgram !== prevProgram) {
      parseProgramStruct(originalProgram, props);
      TranslateProgram(props);
    }

    prevProgram = originalProgram;
  };

  React.useEffect(() => {
    const timer = setInterval(() => {
      getColumnNumber();
    }, 800);
    return () => {
      clearInterval(timer);
    };
  }, []);
  return <Box sx={{ m: 3 }}></Box>;
}
