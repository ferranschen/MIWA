# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `chmod a+rx build.sh`

Change build.sh to executable in your own environment

### `./build.sh`

Build the whole project and run. Open localhost:3006 in your brower.