import express from "express";
import {
  Action,
  actionFactory,
  ActionWithTarget,
  Click,
  DOMNode,
  DOMState,
  Download,
  ExtractURL,
  ForEachDOMNodes,
  GoBack,
  InputJSON,
  Program,
  ScrapeLink,
  ScrapeText,
  SendData,
  SendKeys,
  StatementDisplayName,
  StatementFunctionType,
} from "./lib/DSL";
import {BackendSynthesizer} from "./lib/backendSynthesizer";

//server response and interaction logic
const app = express();
const port = 3000;
const showFullInfo = false;

var bodyParser = require("body-parser");
app.use(bodyParser.json({limit: "50mb"}));
app.use(
    bodyParser.urlencoded({
      limit: "50mb",
      extended: true,
      parameterLimit: 50000,
    })
);
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');

  // authorized headers for preflight requests
  // https://developer.mozilla.org/en-US/docs/Glossary/preflight_request
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();

  app.options('*', (req, res) => {
    // allowed XHR methods
    res.header('Access-Control-Allow-Methods', 'GET, PATCH, PUT, POST, DELETE, OPTIONS');
    res.send();
  });
});
app.use(express.json());

interface Prediction {
  actionType: string;
  targetElementXpath?: string;
  dataParameter?: string;
}

interface ScrapedData {
  data: string;
  timeStamp: number;
}

enum BackendMode {
  RUN,
  PAUSE,
  PENDING_UPDATE,
  PENDING_INSERT
}

app.get("/", (req, res) => {
  console.log("get a get request");
  res.send("Hello World!");
});

var cachedDOM: DOMState[] = []
var scrapedData: ScrapedData[] = []
var savedPrograms: Program[]
var lastAction: Action | null = null
var savedData = scrapedData
var pending_update_timestamp = 0
var pending_update_xpath: string | null = null
var pending_insert_timestamp = 0

// Append an action and a dom to backend synthesizer. This function is called when user manually performs actions.
// req.body should have req.body.action and req.body.dom keys,where req.body.dom is
// the dom on which the action triggered, and action should be an object as following:
// action example:
// {
//     "actionName" : "Click",
//     "targetElement" : (element matrix)
// }
//
// {
//     "actionName" : "SendKeys",
//     "targetElement" : (element matrix),
//     "data": "123"
// }
// {
//     "actionName" : "SendData",
//     "targetElement" : (element matrix),
//     "data": "names[0].firstName" (0 based) or "names[0]"
// }
//
// {
//     "actionName" : "GoBack"
// }
app.post("/append-action-and-dom", function (req, res) {
  if (backendMode === BackendMode.PAUSE) {
    console.log("invalid mode, append-action-and-dom request rejected")
    res.send("");
    return
  }
  console.log("got a post request to append action trace:");
  console.log(req.body.timeStamp + ' ' + req.body.url);
  if (showFullInfo) {
    console.log(JSON.stringify(req.body));
  } else {
    console.log(JSON.stringify(req.body).substring(0, 100));
  }
  let actionInput: { [index: string]: any } = req.body.action;
  let domInput: string = req.body.dom;
  let timestamp: number = req.body.timeStamp
  let url:string = req.body.url
  if (req.body.isUpdate && req.body.isInsert) {
    console.log("ambiguous append-action-and-dom request: isUpdate and isInsert are both true, data unchanged");
    backendMode = BackendMode.RUN;
  } else if (req.body.isUpdate || req.body.isInsert) {
    let action: Action = actionFactory(actionInput, timestamp, url, data_dictionary);
    if (req.body.isUpdate) {
      console.log("trying to update action in backend")
      let isLastActionUpdated = backendSynthesizer.updateAction(pending_update_timestamp, action, new DOMState(domInput));
      if (isLastActionUpdated) {
        lastAction = action;
      }
    } else {
      console.log("trying to insert action in backend")
      backendSynthesizer.insertAction(pending_insert_timestamp, action, new DOMState(domInput));
    }
    backendMode = BackendMode.RUN;
  } else {
    let action: Action = actionFactory(actionInput, timestamp, url, data_dictionary);
    if (lastAction === null || lastAction === undefined || action.toString() !== lastAction.toString()) {
      lastAction = action;
      if (cachedDOM.length === 0) {
        backendSynthesizer.appendActionAndDOM(action, new DOMState(domInput));
      }
      else {
        backendSynthesizer.appendActionAndDOM(action, cachedDOM[cachedDOM.length - 1]);
      }
    } else {
      console.log("duplicate action detected, discarding trace content");
      anomaly_status = AnomalyStatus.INVALID_DUPLICATE;
      scrapedData = scrapedData.filter(function (record) {
        return record.timeStamp !== timestamp;
      });
    }
  }
  res.send("");
});

// //append a DOM to backend synthesizer
// app.post("/append-dom", function (req, res) {
//   let domInput: string = req.body;
//   backendSynthesizer.appendDOM(new DOMState(domInput));
// });
//
// //append an action to backend synthesizer
// app.post("/append-action", function (req, res) {
//   console.log("got a post request", JSON.stringify(req.body));
//   let actionInput: { [index: string]: any } = req.body.action;
//   backendSynthesizer.appendAction(actionFactory(actionInput));
// });
var column_number: number = 0;
var input_data: { [index: string]: any } = {};
var data_dictionary: { [data: string]: string } = {};
var datapath_dictionary: { [datapath: string]: string } = {};

app.post("/set-input-data", function (req, res) {
  console.log("got a post request to set input data");
  input_data = req.body.params.input ? req.body.params.input : {};
  backendSynthesizer.setInputData(new InputJSON(input_data));
  column_number = parseInt(req.body.params.colNum);
  column_pattern = [];
  for (let i = 0; i < column_number; i++) {
    column_pattern.push(PatternType.EMPTY);
  }
  data_dictionary = {};
  datapath_dictionary = {};
  if (req.body.params.inputWithPath) {
    let inputDatapath = req.body.params.inputWithPath;
    for (let i = 0; i < inputDatapath["data"].length; i++) {
      data_dictionary[inputDatapath["data"][i]] = inputDatapath["dataPath"][i];
      datapath_dictionary[inputDatapath["dataPath"][i]] = inputDatapath["data"][i];
    }
  }
  res.send("");
});

//get predictions from synthesizer
//req.body.currentDOM is the DOM where the prediction should be made
var is_program_unavailable: boolean = true
var is_last_prediction_click: boolean = false
var is_dom_changed_after_click: boolean = false

app.post("/get-predictions", function (req, res) {
  if(backendMode !== BackendMode.RUN){
    console.log("invalid mode, get-predictions request rejected")
    res.send("");
    return
  }
  console.log("got a post request to get new predictions");
  if (showFullInfo) {
    console.log(JSON.stringify(req.body));
  } else {
    console.log(JSON.stringify(req.body).substring(0, 100));
  }
  console.log();
  let currentDOM: string = req.body.currentDOM;
  // cachedDOM is only ever changed here
  cachedDOM.push(new DOMState(currentDOM))
  if (is_last_prediction_click && cachedDOM.length > 1) {
    is_dom_changed_after_click =
        cachedDOM[cachedDOM.length - 1].dataDOM.toString() !== cachedDOM[cachedDOM.length - 2].dataDOM.toString();
  }
  if (inScrapeInBulkMode) {
    let currentDOM = cachedDOM[cachedDOM.length - 1]
    let [programs, predictedActions, anomalyStatus] = backendSynthesizer.getNextPredictionInBulk(currentDOM, datapath_dictionary, 50);
    is_program_unavailable = programs.length === 0;
    anomaly_status = anomalyStatus;
    let trace: Action[] = backendSynthesizer.getActionTrace()
    if (trace.length > 0) {
      console.log("current trace:")
      for (let action of trace) {
        console.log(action.toString(2))
      }
    } else {
      console.log("current trace is empty")
    }
    if (programs.length > 0) {
      console.log("first ranked program out of " + programs.length.toString() + ':')
      console.log(programs[0].toString(2))
      savedPrograms = programs
      index_dictionary = backendSynthesizer.getIndexDictionary(0);
      backendSynthesizer.mergeQueryXpath(0, query_xpath);
    } else {
      console.log("no synthesized programs")
    }
    if (predictedActions.length > 0) {
      console.log("all " + predictedActions.length.toString() + " predicted action(s) in bulk:")
      console.log('\t' + (() => {
        let bulkAbstract: string = "";
        for (let predicted of predictedActions) {
          bulkAbstract += predicted.getNameAndTimestamp().name + ' ';
        }
        return bulkAbstract;
      })())
    } else {
      console.log("no valid predicted actions in bulk");
    }
    let predictions: Prediction[] = [];
    if (!is_last_prediction_click || is_dom_changed_after_click) {
      for (let action of predictedActions) {
        let prediction: Prediction = { actionType: "" };
        if (action instanceof Click) {
          prediction.actionType = StatementDisplayName.Click;
          prediction.targetElementXpath = action.target.toString();
        } else if (action instanceof ScrapeText) {
          prediction.actionType = StatementDisplayName.ScrapeText;
          prediction.targetElementXpath = action.target.toString();
        } else if (action instanceof ScrapeLink) {
          prediction.actionType = StatementDisplayName.ScrapeLink;
          prediction.targetElementXpath = action.target.toString();
        } else if (action instanceof Download) {
          prediction.actionType = StatementDisplayName.Download;
          prediction.targetElementXpath = action.target.toString();
        } else if (action instanceof GoBack) {
          prediction.actionType = StatementDisplayName.GoBack;
        } else if (action instanceof ExtractURL) {
          prediction.actionType = StatementDisplayName.ExtractURL;
        } else if (action instanceof SendKeys) {
          prediction.actionType = StatementDisplayName.SendKeys;
          prediction.dataParameter = action.keysText;
        } else if (action instanceof SendData) {
          prediction.actionType = StatementDisplayName.SendData;
          prediction.targetElementXpath = action.target.toString();
          prediction.dataParameter = action.dataPath.toString();
        }
        predictions.push(prediction);
      }
    } else {
      console.log("useless click detected, discarding prediction content")
    }
    is_last_prediction_click = predictedActions.length > 0 ?
        predictedActions[predictedActions.length - 1] instanceof Click : false;
    res.send(JSON.stringify({isBulk:true, suggestion:predictions}));
  } else {
    let currentDOM = cachedDOM[cachedDOM.length - 1]
    let [programs, rawPredictedActions] = backendSynthesizer.getNextPrediction(currentDOM);
    backendSynthesizer.updateIsc();
    is_program_unavailable = programs.length === 0;
    console.log(rawPredictedActions.length.toString() + " raw predicted actions fetched from synthesizer")
    let predictedActions = []
    for (let thisAction of rawPredictedActions) {
      if (!(thisAction instanceof ActionWithTarget) || currentDOM.__valid(<DOMNode>thisAction.target)) {
        if (thisAction instanceof SendData) {
          if (thisAction.index < Object.keys(datapath_dictionary).length) {
            predictedActions.push(thisAction.revertDataPath(datapath_dictionary));
          }
        } else {
          predictedActions.push(thisAction);
        }
      }
    }
    let trace: Action[] = backendSynthesizer.getActionTrace()
    if (trace.length > 0) {
      console.log("current trace:")
      for (let action of trace) {
        console.log(action.toString(2))
      }
    } else {
      console.log("current trace is empty")
    }
    if (programs.length > 0) {
      console.log("first ranked program out of " + programs.length.toString() + ':')
      console.log(programs[0].toString(2))
      savedPrograms = programs
      index_dictionary = backendSynthesizer.getIndexDictionary(0);
      backendSynthesizer.mergeQueryXpath(0, query_xpath);
    } else {
      console.log("no synthesized programs")
    }
    if (predictedActions.length > 0) {
      console.log("first valid predicted action out of " + predictedActions.length.toString() + ':');
      console.log(predictedActions[0].toString(2));
    } else {
      console.log("no valid predicted actions");
      if (!is_program_unavailable) {
        anomaly_status = AnomalyStatus.INVALID_NOT_EXIST;
      }
    }
    let predictions: Prediction[] = [];
    if (!is_last_prediction_click || is_dom_changed_after_click) {
      for (let action of predictedActions) {
        let prediction: Prediction = { actionType: "" };
        if (action instanceof Click) {
          prediction.actionType = StatementDisplayName.Click;
          prediction.targetElementXpath = action.target.toString();
        } else if (action instanceof ScrapeText) {
          prediction.actionType = StatementDisplayName.ScrapeText;
          prediction.targetElementXpath = action.target.toString();
        } else if (action instanceof ScrapeLink) {
          prediction.actionType = StatementDisplayName.ScrapeLink;
          prediction.targetElementXpath = action.target.toString();
        } else if (action instanceof Download) {
          prediction.actionType = StatementDisplayName.Download;
          prediction.targetElementXpath = action.target.toString();
        } else if (action instanceof GoBack) {
          prediction.actionType = StatementDisplayName.GoBack;
        } else if (action instanceof ExtractURL) {
          prediction.actionType = StatementDisplayName.ExtractURL;
        } else if (action instanceof SendKeys) {
          prediction.actionType = StatementDisplayName.SendKeys;
          prediction.dataParameter = action.keysText;
        } else if (action instanceof SendData) {
          prediction.actionType = StatementDisplayName.SendData;
          prediction.targetElementXpath = action.target.toString();
          prediction.dataParameter = action.dataPath.toString();
        }
        predictions.push(prediction);
      }
    } else {
      console.log("useless click detected, discarding prediction content")
    }
    is_last_prediction_click = predictedActions.length > 0 ? predictedActions[0] instanceof Click : false;
    res.send(JSON.stringify({isBulk: false, suggestion: predictions}));
  }
  // // for testing pause/resume functionalities
  // count = count + 1;
  // if (count != 12) {
  //   res.send(JSON.stringify(predictions));
  // } else {
  //   console.log("paused!");
  //   setTimeout(()=>{console.log("resumed"); res.send(JSON.stringify(predictions));}, 5000);
  // }
});

// Element highlighting support
var pending_highlight_xpath: string[] = []
var is_enable_highlight: boolean = false

app.post("/check-highlight", function (req, res) {
  res.send(JSON.stringify({"xpaths": pending_highlight_xpath, "enable": is_enable_highlight}));
})

app.post("/highlight_by_column", function (req, res) {
  console.log("got a post request to highlight column " + req.body.params.columnID.toString() + " OnOff: " + req.body.params.enable.toString());
  let columnID = parseInt(req.body.params.columnID.toString());
  let currentDOM = cachedDOM[cachedDOM.length - 1];
  pending_highlight_xpath = [];
  if (savedPrograms !== undefined && savedPrograms.length > 0) {
    let programID = 0;
    let index = backendSynthesizer.queryIndexByColumnID(programID, columnID);
    pending_highlight_xpath = backendSynthesizer.interpretByIndex(programID, index, currentDOM);
    console.log("interpreted " + pending_highlight_xpath.length.toString() + " target element(s)");
  }
  is_enable_highlight = req.body.params.enable;
  res.send(JSON.stringify({"length": pending_highlight_xpath.length}));
});

app.post("/highlight_by_loop", function (req, res) {
  console.log("got a post request to highlight loop at line " + req.body.params.index.toString() + " onOff: " + req.body.params.enable);
  let index = parseInt(req.body.params.index.toString());
  let currentDOM = cachedDOM[cachedDOM.length - 1];
  pending_highlight_xpath = [];
  if (savedPrograms !== undefined && savedPrograms.length > 0) {
    let programID = 0;
    if (backendSynthesizer.queryStatementByIndex(programID, index) instanceof ForEachDOMNodes) {
        let explicit_highlight_xpath = backendSynthesizer.interpretByIndex(programID, index, currentDOM);
        let fuzzy_pattern = /^(.+)\[\d+]$/;
        for (let xpath of explicit_highlight_xpath) {
          if (fuzzy_pattern.test(xpath)) {
            pending_highlight_xpath.push(xpath.replace(fuzzy_pattern, "$1"));
          }
        }
        pending_highlight_xpath = pending_highlight_xpath.concat(explicit_highlight_xpath);
        console.log("interpreted " + pending_highlight_xpath.length.toString() + " fuzzy element(s) from "
            + explicit_highlight_xpath.length.toString() + " target element(s)");
    }
  }
  is_enable_highlight = req.body.params.enable;
  res.send(JSON.stringify({"length": pending_highlight_xpath.length}));
})

app.post("/highlight_by_index", function (req, res) {
  console.log("got a post request to highlight target element at line " + req.body.params.index.toString() + " onOff: " + req.body.params.enable);
  let index = parseInt(req.body.params.index.toString());
  let currentDOM = cachedDOM[cachedDOM.length - 1];
  pending_highlight_xpath = [];
  if (savedPrograms !== undefined && savedPrograms.length > 0) {
    let programID = 0;
    let thisStatement = backendSynthesizer.queryStatementByIndex(programID, index);
    if (thisStatement instanceof Click || thisStatement instanceof SendKeys || thisStatement instanceof SendData) {
      pending_highlight_xpath = backendSynthesizer.interpretByIndex(programID, index, currentDOM);
      console.log("interpreted " + pending_highlight_xpath.length.toString() + " target element(s)");
    }
  }
  is_enable_highlight = req.body.params.enable;
  res.send(JSON.stringify({"length": pending_highlight_xpath.length}));
})

// NL program translation support
enum XpathType {
  Unknown, Div, Table, List, OrderedList, UnorderedList,
  DescriptionList, DescriptionListItem
}

let XpathDictionary: { [tag: string]: XpathType } = {
  "div": XpathType.Div, "table": XpathType.Table, "tr": XpathType.Table, "td": XpathType.Table,
  "li": XpathType.List, "ol": XpathType.OrderedList, "ul": XpathType.UnorderedList,
  "dl": XpathType.DescriptionList, "dt": XpathType.DescriptionListItem, "dd": XpathType.DescriptionListItem
}

app.post("/get_column_by_index", function (req, res) {
  let index = parseInt(req.body.index);
  let programID = 0;
  let columnID = backendSynthesizer.queryColumnIDByIndex(programID, index);
  res.send(JSON.stringify({"columnID": columnID}));
})

app.post("/get_type_by_index", function (req, res) {
  let index = parseInt(req.body.index);
  let currentDOM = cachedDOM[cachedDOM.length - 1];
  let type: XpathType = XpathType.Unknown;
  if (savedPrograms !== undefined && savedPrograms.length > 0) {
    let programID = 0;
    if (backendSynthesizer.queryStatementByIndex(programID, index) instanceof ForEachDOMNodes) {
      let sample_xpath = backendSynthesizer.interpretByIndex(programID, index, currentDOM)[0];
      for (let tag in XpathDictionary) {
        if (sample_xpath.includes(tag)) {
          type = XpathDictionary[tag];
          break;
        }
      }
    }
  }
  res.send(JSON.stringify({"type": XpathType[type]}));
})

var index_dictionary: { [index: number]: string } = {};
var query_xpath: string[] = [];
var result_xpath: { [xpath: string]: string } = {};
let input_box_pattern: RegExp = /input/;

app.post("/get_text_by_index", function (req, res) {
  let index = parseInt(req.body.params.index.toString());
  console.log("got a post request to get text by index " + index.toString());
  let xpath = index in index_dictionary ? index_dictionary[index] : "";
  let text: string;
  if (xpath in result_xpath && result_xpath[xpath].length > 0) {
    text = result_xpath[xpath]
  } else if (index > 1 && backendSynthesizer.queryFunctionTypeByIndex(0, index - 1)
      === StatementFunctionType.Input) {
    text = "Search"
  } else if (index > 0 && backendSynthesizer.queryFunctionTypeByIndex(0, index)
      === StatementFunctionType.Navigate) {
    text = "Next page"
  } else if (input_box_pattern.test(xpath)) {
    text = "Input box"
  } else if (xpath.length > 0) {
    text = "Item link"
  } else {
    text = ""
  }
  res.send(JSON.stringify({"text": text}));
})

app.post("/check-text-query", function (req, res) {
  res.send(JSON.stringify({"xpaths": query_xpath}));
  query_xpath = [];
})

app.post("/send-text-query", function (req, res) {
  let data: { [xpath: string]: string } = req.body.data;
  for (let xpath in data) {
    result_xpath[xpath] = data[xpath].replace(/^\s*(|\S|\S.*\S)\s*$/, "$1");
  }
  res.send("");
})

// Optimized ScrapeNext support
var do_scrape_next: boolean = false

app.post("/request_scrape_next", function (req, res) {
  do_scrape_next = true;
  res.send(JSON.stringify({"status": do_scrape_next}));
})

app.post("/check-scrape-next", function (req, res) {
  res.send(JSON.stringify({"status": do_scrape_next}));
  if (do_scrape_next) {
    do_scrape_next = false;
  }
})

// Anomaly detection support
export enum AnomalyStatus {
  VALID, INVALID_NOT_EXIST, INVALID_EMPTY, INVALID_WRONG_FORMAT, INVALID_DUPLICATE
}

var anomaly_status: AnomalyStatus = AnomalyStatus.VALID;

app.post("/is_entry_valid", function (req, res) {
  res.send(JSON.stringify({"status": anomaly_status}));
  if (anomaly_status !== AnomalyStatus.VALID) {
    anomaly_status = AnomalyStatus.VALID;
  }
})

app.post("/set_anomaly_status", function (req, res) {
  let status = parseInt(req.body.status);
  if (AnomalyStatus[status] !== undefined) {
    anomaly_status = status;
  }
  res.send(JSON.stringify({"status": AnomalyStatus[status]}));
})

//chrome extension can send scraped data to the server
//format:
// {
//   "data":data scraped,
//     "timeStamp":time when data is scraped
// }
enum PatternType {
  STRING, TEXT, NUMBER, LINK, EMAIL, DATE, PHONE, MONEY, EMPTY
}

let PatternDictionary: RegExp[] = [
  /^.+$/, // string
  /^[\d\sA-Za-z,.;:\/\-"'?!~&()\[\]]+$/, // text
  /^(?![\s,.+\-]*$)(?:|[+\-])[\d\s,]*\d(?:|[,.][\d\s]+)(?:|%)$/, // number
  /^http(?:|s):\/{2}\S+$/, // link
  /^\S+@\S+$/, // email
  /^(?:\d{1,2}|\d{4})([.\/\-])\d{1,2}\1(?:\d{1,2}|\d{4})$/, // date
  /^(?!\d{10})(?:|(?:|\+)\d{1,3})(?:|[\s-])(?:\(\d{3}\)|\d{3})(?:|[\s-])\d{3}(?:|[\s-])\d{4}$/, // phone
  /^[$€£]\s*(?![\s,.]*$)[\d\s,]*\d(?:|[,.][\d\s]+)$/ // money
]

function parsePattern(data: string): PatternType {
  if (PatternDictionary[PatternType.MONEY].test(data)) {
    return PatternType.MONEY;
  }
  if (PatternDictionary[PatternType.PHONE].test(data)) {
    return PatternType.PHONE;
  }
  if (PatternDictionary[PatternType.DATE].test(data)) {
    return PatternType.DATE;
  }
  if (PatternDictionary[PatternType.EMAIL].test(data)) {
    return PatternType.EMAIL;
  }
  if (PatternDictionary[PatternType.LINK].test(data)) {
    return PatternType.LINK;
  }
  if (PatternDictionary[PatternType.NUMBER].test(data)) {
    return PatternType.NUMBER;
  }
  if (PatternDictionary[PatternType.TEXT].test(data)) {
    return PatternType.TEXT;
  }
  if (PatternDictionary[PatternType.STRING].test(data)) {
    return PatternType.STRING;
  }
  return PatternType.EMPTY;
}

function parseColumnPattern(columnID: number): PatternType {
  if (columnID >= 0 && columnID < column_number) {
    let columnPattern: PatternType = PatternType.EMPTY;
    for (let i = columnID; i < scrapedData.length; i += column_number) {
      let thisPattern = parsePattern(scrapedData[i].data);
      if (columnPattern === PatternType.EMPTY) {
        columnPattern = thisPattern;
      } else if (thisPattern !== PatternType.EMPTY && columnPattern !== thisPattern) {
        columnPattern = PatternType.EMPTY;
        break;
      }
    }
    return columnPattern;
  }
  return PatternType.EMPTY;
}

function parseExclusiveColumnPattern(columnID: number, timestamp: number): PatternType {
  if (columnID >= 0 && columnID < column_number) {
    let columnPattern: PatternType = PatternType.EMPTY;
    for (let i = columnID; i < scrapedData.length; i += column_number) {
      if (scrapedData[i].timeStamp !== timestamp) {
        let thisPattern = parsePattern(scrapedData[i].data);
        if (columnPattern === PatternType.EMPTY) {
          columnPattern = thisPattern;
        } else if (thisPattern !== PatternType.EMPTY && columnPattern !== thisPattern) {
          columnPattern = PatternType.EMPTY;
          break;
        }
      }
    }
    return columnPattern;
  }
  return PatternType.EMPTY;
}

var column_pattern: PatternType[] = [];

app.post("/add_scraped_data", function (req, res) {
  if (backendMode === BackendMode.PAUSE) {
    console.log("invalid mode, add_scraped_data request rejected")
    res.send("");
    return
  }
  console.log("got a post request to add scraped data:");
  console.log(req.body.data);
  console.log(req.body.timeStamp);
  let data: string = req.body.data;
  let timeStamp: number = parseInt(req.body.timeStamp);
  if (req.body.isUpdate && req.body.isInsert) {
    console.log("ambiguous add_scraped_data request: isUpdate and isInsert are both true, data unchanged");
  } else if (req.body.isUpdate) {
    let updated = false;
    let columnID = -1;
    console.log("trying to replace updated item in scrape list");
    for (let i = 0; i < scrapedData.length; i++) {
      if (scrapedData[i].timeStamp === pending_update_timestamp) {
        console.log("found old scraped data to replace - replaced at index " + i.toString());
        scrapedData[i] = {"data": data, "timeStamp": timeStamp};
        columnID = i % column_number;
        updated = true;
        break;
      }
    }
    if (!updated) {
      console.log("can't found old scraped data to be replaced - not replaced")
      throw "received add_scraped_data request with isUpdate = true, but can't find target to be updated."
    }
    if (column_pattern[columnID] === PatternType.EMPTY) {
      let exclusivePattern = parseExclusiveColumnPattern(columnID, timeStamp);
      if (scrapedData.length > column_number + columnID && exclusivePattern !== PatternType.EMPTY
          && parsePattern(data) !== exclusivePattern) {
        anomaly_status = AnomalyStatus.INVALID_WRONG_FORMAT;
        column_pattern[columnID] = PatternType.EMPTY;
      } else {
        column_pattern[columnID] = exclusivePattern;
      }
    } else if (parsePattern(data) !== column_pattern[columnID]) {
      if (scrapedData.length > column_number + columnID) {
        anomaly_status = AnomalyStatus.INVALID_WRONG_FORMAT;
      }
      column_pattern[columnID] = parseColumnPattern(columnID);
    }
  } else if (req.body.isInsert) {
    let inserted = false;
    console.log("trying to insert new item in scrape list");
    for (let i = 0; i < scrapedData.length; i++) {
      if (scrapedData[i].timeStamp === pending_insert_timestamp) {
        console.log("found valid position to insert - inserted before index " + i.toString());
        scrapedData.splice(i, 0, {"data": data, "timeStamp": timeStamp});
        inserted = true;
        break;
      }
    }
    if (!inserted) {
      console.log("can't found valid position to insert - not inserted")
      throw "received add_scraped_data request with isInsert = true, but can't find where to insert."
    }
    for (let columnID = 0; columnID < column_number; columnID++) {
      let thisPattern = parseColumnPattern(columnID);
      if (scrapedData.length > column_number + columnID && thisPattern === PatternType.EMPTY
          && column_pattern[columnID] !== PatternType.EMPTY) {
        anomaly_status = AnomalyStatus.INVALID_WRONG_FORMAT;
      }
      column_pattern[columnID] = thisPattern;
    }
  } else {
    scrapedData.push({"data": data, "timeStamp": timeStamp})
    let columnID = (scrapedData.length - 1) % column_number;
    if (column_pattern[columnID] === PatternType.EMPTY) {
      column_pattern[columnID] = parseColumnPattern(columnID);
    } else if (column_pattern[columnID] !== PatternType.EMPTY && parsePattern(data) !== column_pattern[columnID]) {
      anomaly_status = AnomalyStatus.INVALID_WRONG_FORMAT;
      column_pattern[columnID] = parseColumnPattern(columnID);
    }
  }
  if (data === undefined || data.length === 0) {
    anomaly_status = AnomalyStatus.INVALID_EMPTY;
    console.log("NOTHING HERE")
  }
  console.log("deduced data pattern: " + (() => {
    let patternAbstract: string = "";
    for (let thisPattern of column_pattern) {
      patternAbstract += PatternType[thisPattern] + ' ';
    }
    return patternAbstract;
  })());
  res.send("");
});

app.post("/delete_data", function (req, res) {
  //changed to integrate with backend
  console.log("[delete request:]");
  console.log(req.body.params.timeStamp);
  let [isLastActionDeleted, latestAction] = backendSynthesizer.deleteAction(req.body.params.timeStamp);
  if (isLastActionDeleted) {
    lastAction = latestAction;
  }
  let targetIndex = -1;
  scrapedData = scrapedData.filter(function (record, index) {
    if (record.timeStamp == req.body.params.timeStamp) {
      targetIndex = index
    }
    return record.timeStamp != req.body.params.timeStamp
  });
  if (targetIndex === scrapedData.length && scrapedData.length < column_number) {
    column_pattern[targetIndex] = PatternType.EMPTY;
  } else if (targetIndex < scrapedData.length) {
    for (let columnID = 0; columnID < column_number; columnID++) {
      let thisPattern = parseColumnPattern(columnID);
      if (scrapedData.length > columnID && thisPattern === PatternType.EMPTY
          && column_pattern[columnID] !== PatternType.EMPTY) {
        anomaly_status = AnomalyStatus.INVALID_WRONG_FORMAT;
      }
      column_pattern[columnID] = thisPattern;
    }
  }
  console.log("deduced data pattern: " + (() => {
    let patternAbstract: string = "";
    for (let thisPattern of column_pattern) {
      patternAbstract += PatternType[thisPattern] + ' ';
    }
    return patternAbstract;
  })());
  res.send(JSON.stringify(scrapedData));
});

app.post("/update_data", function (req, res) {
  //changed to integrate with backend
  console.log("[update request:]");
  console.log(req.body.params.timeStamp);
  backendMode = BackendMode.PENDING_UPDATE
  pending_update_timestamp = parseInt(req.body.params.timeStamp)
  let target_action = backendSynthesizer.getActionByTimestamp(pending_update_timestamp)
  if (target_action === null) {
    console.log("in update request: can't find action in original list")
  } else {
    if (target_action instanceof ActionWithTarget) {
      pending_update_xpath = target_action.target.toString()
    } else {
      pending_update_xpath = null
    }
  }
  res.send(JSON.stringify(scrapedData))
});

app.post("/insert_data", function (req, res) {
  console.log("[insert request:]");
  console.log(req.body.params.timeStamp);
  backendMode = BackendMode.PENDING_INSERT
  pending_insert_timestamp = parseInt(req.body.params.timeStamp)
  if (backendSynthesizer.getIndexByTimestamp(pending_insert_timestamp)) {
    console.log("in insert request: can't find action in original list")
  }
  res.send(JSON.stringify(scrapedData))
})

app.post("/get_scraped_data", function (req, res) {
  res.send(JSON.stringify(scrapedData))
});

app.post("/get_scraped_data_with_description", function (req, res) {
  let resultList = []
  let actionTrace: Action[] = backendSynthesizer.getActionTrace().slice(-15 * column_number)
  for (let action of actionTrace) {
    let name: string = action.getNameAndTimestamp().name
    let data: string = "Unknown element"
    let timestamp: number = action.timestamp
    if (action instanceof ScrapeText || action instanceof ScrapeLink) {
      for (let item of scrapedData) {
        if (timestamp === item.timeStamp) {
          data = item.data
          break
        }
      }
    } else if (action instanceof Click) {
      let xpath = action.target.toString()
      if (xpath in result_xpath && result_xpath[xpath].length > 0) {
        data = result_xpath[xpath]
      } else if (action.index > 1 && backendSynthesizer.queryFunctionTypeByIndex(0, action.index - 1)
          === StatementFunctionType.Input) {
        data = "Search"
      } else if (action.index > 0 && backendSynthesizer.queryFunctionTypeByIndex(0, action.index)
          === StatementFunctionType.Navigate) {
        data = "Next page"
      } else if (input_box_pattern.test(xpath)) {
        data = "Input box"
      } else if (xpath.length > 0) {
        data = "Item link"
      } else {
        data = ""
      }
    } else if (action instanceof SendKeys) {
      data = action.keysText
    } else if (action instanceof SendData) {
      if (action.dataPath.nodeList.length > 0) {
        data = datapath_dictionary[action.dataPath.nodeList[0].toString()];
      }
    } else if (action instanceof Download) {
      data = action.target.toString()
    } else if (action instanceof GoBack || action instanceof ExtractURL) {
      data = "" // no action-specific data
    }
    resultList.push({"name":name, "data":data, "timeStamp":timestamp})
  }
  res.send(JSON.stringify(resultList))
});

app.post("/restart_program", function (req, res) {
  console.log("restarted back-end");
  scrapedData = savedData
  backendMode = BackendMode.RUN
  res.send(JSON.stringify(scrapedData))
});

app.post("/clear_data", function (req, res) {
  console.log("cleared everything, hopefully")
  cachedDOM = [];
  scrapedData = [];
  savedPrograms = [];
  lastAction = null;
  savedData = scrapedData;
  pending_update_timestamp = 0;
  pending_update_xpath = null;
  pending_insert_timestamp = 0
  is_program_unavailable = true;
  is_last_prediction_click = false;
  is_dom_changed_after_click = false;
  pending_highlight_xpath = [];
  is_enable_highlight = false;
  index_dictionary = {};
  query_xpath = [];
  result_xpath = {};
  do_scrape_next = false;
  anomaly_status = AnomalyStatus.VALID;
  column_pattern = [];
  for (let i = 0; i < column_number; i++) {
    column_pattern.push(PatternType.EMPTY);
  }
  backendSynthesizer.restart(input_data);
  backendMode = BackendMode.RUN;
  inScrapeInBulkMode = false;
  res.send(JSON.stringify(scrapedData))
});

app.post("/pause", function (req, res) {
  console.log("paused back-end")
  backendMode = BackendMode.PAUSE
});

app.post("/check-update-status", function (req, res) {
  res.send(JSON.stringify({"status":backendMode === BackendMode.PENDING_UPDATE, "xpath": pending_update_xpath}))
});

app.post("/check-insert-status", function (req, res) {
  res.send(JSON.stringify({"status":backendMode === BackendMode.PENDING_INSERT}))
});

app.post("/active-scrape-in-bulk-mode", function (req, res) {
  console.log("scrape in bulk mode activated")
  inScrapeInBulkMode = true
  res.send("")
});

app.post("/deactive-scrape-in-bulk-mode", function (req, res) {
  console.log("scrape in bulk mode deactivated")
  inScrapeInBulkMode = false
  res.send("")
});

app.post("/check-bulk", function (req, res) {
  res.send(JSON.stringify({"status": inScrapeInBulkMode}))
})

app.post("/append-bulk", function (req, res) {
  console.log("got a post request to append bulk action trace");
  let bulkActions: Action[] = [];
  for (let actionObject of req.body) {
    let actionInput: { [index: string]: any } = actionObject.action;
    let timestamp: number = actionObject.timeStamp;
    let url: string = actionObject.url;
    let action = actionFactory(actionInput, timestamp, url, data_dictionary);
    if (lastAction === null || lastAction === undefined || action.toString() !== lastAction.toString()) {
      lastAction = action;
      bulkActions.push(action);
    } else {
      console.log("duplicate bulk action detected, discarding trace content");
      anomaly_status = AnomalyStatus.INVALID_DUPLICATE;
      scrapedData = scrapedData.filter(function (record) {
        return record.timeStamp !== timestamp;
      });
    }
  }
  backendSynthesizer.updateActionForBulk(bulkActions);
  res.send("")
});

app.post("/get-program-info", function (req, res) {
  if (is_program_unavailable || savedPrograms === undefined || savedPrograms.length === 0) {
    res.send(JSON.stringify({"columnNumber": 0, "programType": -1}));
    return
  }
  let savedProgram = savedPrograms[0].toString();
  let numOfColumns = 0;
  let programType = 0; // 0: single page, 1: multiple pages
  let lineNum = 1;
  let targetLine = 0;
  let isEnd = false;
  // get inner most ForEach
  savedProgram.split("\n").forEach((line) => {
    if (line.match(/ForEach/) && line.match(/{/)) {
      targetLine = lineNum;
    }
    lineNum++;
  });
  lineNum = 1;
  savedProgram.split("\n").forEach((line) => {
    if (lineNum >= targetLine && !isEnd) {
      if (line.match(/GoBack/)) {
        programType = 1;
      }
      if (line.match(/Scrape/)) {
        numOfColumns++;
      }
      if (line.match(/}/)) {
        isEnd = true;
      }
    }
    lineNum++;
  });
  res.send(JSON.stringify({"columnNumber": numOfColumns, "programType": programType, "program": savedProgram}));
});

app.listen(port, () => {
  console.log(`server started at http://localhost:${port}`);
});

var backendSynthesizer = new BackendSynthesizer();
var backendMode = BackendMode.RUN
var inScrapeInBulkMode = false
