"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = __importDefault(require("express"));
var DSL_1 = require("./lib/DSL");
var backendSynthesizer_1 = require("./lib/backendSynthesizer");
//server response and interaction logic
var app = (0, express_1.default)();
var port = 3000;
var showFullInfo = false;
var bodyParser = require("body-parser");
app.use(bodyParser.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({
    limit: "50mb",
    extended: true,
    parameterLimit: 50000,
}));
app.use(function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    // authorized headers for preflight requests
    // https://developer.mozilla.org/en-US/docs/Glossary/preflight_request
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
    app.options('*', function (req, res) {
        // allowed XHR methods
        res.header('Access-Control-Allow-Methods', 'GET, PATCH, PUT, POST, DELETE, OPTIONS');
        res.send();
    });
});
app.use(express_1.default.json());
var BackendMode;
(function (BackendMode) {
    BackendMode[BackendMode["RUN"] = 0] = "RUN";
    BackendMode[BackendMode["PAUSE"] = 1] = "PAUSE";
    BackendMode[BackendMode["PENDING_UPDATE"] = 2] = "PENDING_UPDATE";
})(BackendMode || (BackendMode = {}));
app.get("/", function (req, res) {
    console.log("get a get request");
    res.send("Hello World!");
});
var cachedDOM = [];
var scrapedData = [];
var savedData = scrapedData;
var pending_update_timestamp = 0;
var pending_update_xpath = null;
// Append an action and a dom to backend synthesizer. This function is called when user manually performs actions.
// req.body should have req.body.action and req.body.dom keys,where req.body.dom is
// the dom on which the action triggered, and action should be an object as following:
// action example:
// {
//     "actionName" : "Click",
//     "targetElement" : (element matrix)
// }
//
// {
//     "actionName" : "SendKeys",
//     "targetElement" : (element matrix),
//     "data": "123"
// }
// {
//     "actionName" : "SendData",
//     "targetElement" : (element matrix),
//     "data": "names[0].firstName" (0 based) or "names[0]"
// }
//
// {
//     "actionName" : "GoBack"
// }
app.post("/append-action-and-dom", function (req, res) {
    if (backendMode !== BackendMode.RUN && backendMode !== BackendMode.PENDING_UPDATE) {
        res.send("");
        return;
    }
    console.log("got a post request:");
    console.log(req.body.timeStamp);
    console.log(req.body.url);
    console.log(req.body.isUpdate);
    if (showFullInfo) {
        console.log(JSON.stringify(req.body));
    }
    else {
        console.log(JSON.stringify(req.body).substring(0, 100));
    }
    var actionInput = req.body.action;
    var domInput = req.body.dom;
    var timestamp = req.body.timeStamp;
    var url = req.body.url;
    if (req.body.isUpdate) {
        console.log("trying to update action in backend");
        var action = (0, DSL_1.actionFactory)(actionInput, timestamp, url);
        backendSynthesizer.updateAction(pending_update_timestamp, action, new DSL_1.DOMState(domInput));
        backendMode = BackendMode.RUN;
    }
    else {
        var action = (0, DSL_1.actionFactory)(actionInput, timestamp, url);
        if (cachedDOM.length === 0) {
            backendSynthesizer.appendActionAndDOM(action, new DSL_1.DOMState(domInput));
        }
        else {
            backendSynthesizer.appendActionAndDOM(action, cachedDOM[cachedDOM.length - 1]);
        }
    }
    res.send("");
});
// //append a DOM to backend synthesizer
// app.post("/append-dom", function (req, res) {
//   let domInput: string = req.body;
//   backendSynthesizer.appendDOM(new DOMState(domInput));
// });
//
// //append an action to backend synthesizer
// app.post("/append-action", function (req, res) {
//   console.log("got a post request", JSON.stringify(req.body));
//   let actionInput: { [index: string]: any } = req.body.action;
//   backendSynthesizer.appendAction(actionFactory(actionInput));
// });
app.post("/set-input-data", function (req, res) {
    console.log("got a post request:");
    console.log(req.body.timeStamp);
    var inputData = req.body.input;
    var timestamp = req.body.timeStamp;
    backendSynthesizer.setInputData(new DSL_1.InputJSON(inputData));
    res.send("");
});
//get predictions from synthesizer
//req.body.currentDOM is the DOM where the prediction should be made
var count = 0;
app.post("/get-predictions", function (req, res) {
    if (backendMode !== BackendMode.RUN) {
        res.send("");
        return;
    }
    console.log("got a post request to get new predictions");
    if (showFullInfo) {
        console.log(JSON.stringify(req.body));
    }
    else {
        console.log(JSON.stringify(req.body).substring(0, 100));
    }
    console.log();
    var currentDOM = req.body.currentDOM;
    //changed here
    cachedDOM.push(new DSL_1.DOMState(currentDOM));
    if (inScrapeInBulkMode) {
        var _a = backendSynthesizer.getNextPredictionInBulk(cachedDOM[cachedDOM.length - 1]), programs = _a[0], predictedActions = _a[1];
        // let [programs, predictedActions] = backendSynthesizer.getNextPrediction(
        //     new DOMState(currentDOM)
        // );
        console.log("trace at this point:");
        var trace = backendSynthesizer.getActionTrace();
        for (var _i = 0, trace_1 = trace; _i < trace_1.length; _i++) {
            var a = trace_1[_i];
            console.log(a.toString());
        }
        console.log("");
        console.log("synthesized programs (first ranked one):");
        if (programs.length > 0) {
            console.log(programs[0].toString());
        }
        console.log("predicted actions(bulk):");
        if (predictedActions.length > 0) {
            for (var _b = 0, predictedActions_1 = predictedActions; _b < predictedActions_1.length; _b++) {
                var predicted = predictedActions_1[_b];
                console.log(predicted.toString());
            }
        }
        var predictions = [];
        for (var _c = 0, predictedActions_2 = predictedActions; _c < predictedActions_2.length; _c++) {
            var action = predictedActions_2[_c];
            var prediction = { actionType: "" };
            if (action instanceof DSL_1.Click) {
                prediction.actionType = DSL_1.StatementDisplayName.Click;
                prediction.targetElementXpath = action.target.toString();
            }
            else if (action instanceof DSL_1.ScrapeText) {
                prediction.actionType = DSL_1.StatementDisplayName.ScrapeText;
                prediction.targetElementXpath = action.target.toString();
            }
            else if (action instanceof DSL_1.ScrapeLink) {
                prediction.actionType = DSL_1.StatementDisplayName.ScrapeLink;
                prediction.targetElementXpath = action.target.toString();
            }
            else if (action instanceof DSL_1.Download) {
                prediction.actionType = DSL_1.StatementDisplayName.Download;
                prediction.targetElementXpath = action.target.toString();
            }
            else if (action instanceof DSL_1.GoBack) {
                prediction.actionType = DSL_1.StatementDisplayName.GoBack;
            }
            else if (action instanceof DSL_1.ExtractURL) {
                prediction.actionType = DSL_1.StatementDisplayName.ExtractURL;
            }
            else if (action instanceof DSL_1.SendKeys) {
                prediction.actionType = DSL_1.StatementDisplayName.SendKeys;
                prediction.dataParameter = action.keysText;
            }
            else if (action instanceof DSL_1.SendData) {
                prediction.actionType = DSL_1.StatementDisplayName.SendData;
                prediction.targetElementXpath = action.target.toString();
                prediction.dataParameter = action.dataPath.toString();
            }
            predictions.push(prediction);
        }
        res.send(JSON.stringify({ isBulk: true, suggestion: predictions }));
    }
    else {
        var _d = backendSynthesizer.getNextPrediction(cachedDOM[cachedDOM.length - 1]), programs = _d[0], predictedActions = _d[1];
        // let [programs, predictedActions] = backendSynthesizer.getNextPrediction(
        //     new DOMState(currentDOM)
        // );
        console.log("trace at this point:");
        var trace = backendSynthesizer.getActionTrace();
        for (var _e = 0, trace_2 = trace; _e < trace_2.length; _e++) {
            var a = trace_2[_e];
            console.log(a.toString());
        }
        console.log("");
        console.log("synthesized programs (first ranked one):");
        if (programs.length > 0) {
            console.log(programs[0].toString());
        }
        console.log("predicted actions:");
        if (predictedActions.length > 0) {
            console.log(predictedActions[0].toString());
        }
        var predictions = [];
        for (var _f = 0, predictedActions_3 = predictedActions; _f < predictedActions_3.length; _f++) {
            var action = predictedActions_3[_f];
            var prediction = { actionType: "" };
            if (action instanceof DSL_1.Click) {
                prediction.actionType = DSL_1.StatementDisplayName.Click;
                prediction.targetElementXpath = action.target.toString();
            }
            else if (action instanceof DSL_1.ScrapeText) {
                prediction.actionType = DSL_1.StatementDisplayName.ScrapeText;
                prediction.targetElementXpath = action.target.toString();
            }
            else if (action instanceof DSL_1.ScrapeLink) {
                prediction.actionType = DSL_1.StatementDisplayName.ScrapeLink;
                prediction.targetElementXpath = action.target.toString();
            }
            else if (action instanceof DSL_1.Download) {
                prediction.actionType = DSL_1.StatementDisplayName.Download;
                prediction.targetElementXpath = action.target.toString();
            }
            else if (action instanceof DSL_1.GoBack) {
                prediction.actionType = DSL_1.StatementDisplayName.GoBack;
            }
            else if (action instanceof DSL_1.ExtractURL) {
                prediction.actionType = DSL_1.StatementDisplayName.ExtractURL;
            }
            else if (action instanceof DSL_1.SendKeys) {
                prediction.actionType = DSL_1.StatementDisplayName.SendKeys;
                prediction.dataParameter = action.keysText;
            }
            else if (action instanceof DSL_1.SendData) {
                prediction.actionType = DSL_1.StatementDisplayName.SendData;
                prediction.targetElementXpath = action.target.toString();
                prediction.dataParameter = action.dataPath.toString();
            }
            predictions.push(prediction);
        }
        res.send(JSON.stringify({ isBulk: false, suggestion: predictions }));
    }
    // for testing pause/resume functionalities
    // count = count + 1;
    // if (count != 12) {
    //   res.send(JSON.stringify(predictions));
    // } else {
    //   console.log("paused!");
    //   setTimeout(()=>{console.log("resumed"); res.send(JSON.stringify(predictions));}, 5000);
    // }
});
//chrome extension can send scraped data to the server
//format:
// {
//   "data":data scraped,
//     "timeStamp":time when data is scraped
// }
app.post("/add_scraped_data", function (req, res) {
    if (backendMode !== BackendMode.RUN && backendMode !== BackendMode.PENDING_UPDATE) {
        res.send("");
        return;
    }
    console.log("got a post request for scraped data:");
    console.log(req.body.data);
    console.log(req.body.timeStamp);
    var data = req.body.data;
    var timeStamp = parseInt(req.body.timeStamp);
    if (req.body.isUpdate) {
        var updated = false;
        for (var i = 0; i < scrapedData.length; ++i) {
            if (scrapedData[i].timeStamp === pending_update_timestamp) {
                console.log("found old scraped data to be replaced - replaced");
                scrapedData[i].data = req.body.data;
                scrapedData[i].timeStamp = req.body.timeStamp;
                updated = true;
                break;
            }
        }
        if (!updated) {
            console.log("can't found old scraped data to be replaced - not replaced");
            throw "received add_scraped_data request with isUpdate = true, but can't find target to be updated.";
        }
    }
    else {
        scrapedData.push({ "data": data, "timeStamp": timeStamp });
    }
    res.send("");
});
app.post("/delete_data", function (req, res) {
    //changed to integrate with backend
    console.log("[delete request:]");
    console.log(req.body.params.timeStamp);
    scrapedData = scrapedData.filter(function (record) { return record.timeStamp != req.body.params.timeStamp; });
    backendSynthesizer.deleteAction(req.body.params.timeStamp);
    res.send(JSON.stringify(scrapedData));
});
app.post("/update_data", function (req, res) {
    //changed to integrate with backend
    console.log("[update request:]");
    console.log(req.body.params.timeStamp);
    backendMode = BackendMode.PENDING_UPDATE;
    pending_update_timestamp = req.body.params.timeStamp;
    var target_action = backendSynthesizer.getActionByTimestamp(req.body.params.timeStamp);
    if (target_action === null) {
        console.log("in update request: can't find action in original list");
    }
    else {
        if (target_action instanceof DSL_1.ActionWithTarget) {
            pending_update_xpath = target_action.target;
        }
        else {
            pending_update_xpath = null;
        }
    }
    res.send(JSON.stringify(scrapedData));
});
app.post("/get_scraped_data", function (req, res) {
    res.send(JSON.stringify(scrapedData));
});
app.post("/get_scraped_data_with_description", function (req, res) {
    var resultList = [];
    var actionWithNameAndTimestamp = backendSynthesizer.getActionTraceWithNameAndTimestamp();
    for (var _i = 0, scrapedData_1 = scrapedData; _i < scrapedData_1.length; _i++) {
        var item = scrapedData_1[_i];
        var timestamp = item.timeStamp;
        var data = item.data;
        var name_1 = "unfound";
        for (var _a = 0, actionWithNameAndTimestamp_1 = actionWithNameAndTimestamp; _a < actionWithNameAndTimestamp_1.length; _a++) {
            var action = actionWithNameAndTimestamp_1[_a];
            if (timestamp === action["timestamp"]) {
                name_1 = action["name"];
            }
        }
        resultList.push({ "name": name_1, "data": data, "timeStamp": timestamp });
    }
    res.send(JSON.stringify(resultList));
});
app.post("/restart_program", function (req, res) {
    console.log("got a restart request:");
    scrapedData = savedData;
    backendMode = BackendMode.RUN;
    res.send(JSON.stringify(scrapedData));
});
app.post("/clear_data", function (req, res) {
    savedData = scrapedData;
    scrapedData = [];
    backendSynthesizer.restart();
    cachedDOM = [];
    backendMode = BackendMode.RUN;
    res.send(JSON.stringify(scrapedData));
});
app.post("/pause", function (req, res) {
    backendMode = BackendMode.PAUSE;
});
app.post("/check-update-status", function (req, res) {
    res.send(JSON.stringify({ "status": backendMode === BackendMode.PENDING_UPDATE, "xpath": pending_update_xpath }));
});
app.post("/active-scrape-in-bulk-mode", function (req, res) {
    console.log("scrape in bulk mode activated");
    inScrapeInBulkMode = true;
    res.send("");
});
app.post("/deactive-scrape-in-bulk-mode", function (req, res) {
    console.log("scrape in bulk mode deactivated");
    inScrapeInBulkMode = false;
    res.send("");
});
app.post("/append-bulk", function (req, res) {
    console.log("append bulk");
    console.log(req.body);
    var actions_to_replace = [];
    for (var _i = 0, _a = req.body; _i < _a.length; _i++) {
        var action = _a[_i];
        var actionInput = req.body.action;
        var timestamp = req.body.timeStamp;
        var url = req.body.url;
        actions_to_replace.push((0, DSL_1.actionFactory)(actionInput, timestamp, url));
    }
    backendSynthesizer.updateActionForBulk(actions_to_replace);
    res.send("");
});
app.listen(port, function () {
    console.log("server started at http://localhost:" + port);
});
var backendSynthesizer = new backendSynthesizer_1.BackendSynthesizer();
var backendMode = BackendMode.RUN;
var inScrapeInBulkMode = false;
//# sourceMappingURL=server.js.map