# Web-automation Server

A nodejs server that takes user actions on a web and returns a user action prediction.

## Installation

`yarn` or `yarn install`

## Build

Before your first run or after any modification of the scripts, run
```
yarn build
```

to rebuild the javascript files from typescript files.

## Start the live server

To run the server, execute

```
yarn start
```

The localhost is using port 3000. You will also see the url in the console that runs the server.
