import {
    Action,
    ActionTrace,
    DOMState,
    DOMStateTrace,
    ExecEnvironment,
    Statement,
    ForEachDOMNodes,
    Program,
    GlobalRunningEnv,
    InputJSON,
    DOMPersistentVerifier,
    Click,
    ScrapeText,
    ScrapeLink,
    Download,
    SendKeys,
    SendData,
    NoRepeatWorkListArray,
    NoRepeatActionArray,
    DOMNode,
    WhileLoopWithClick,
    ForEachInput,
    LoopyStatement,
    Variable, DOMNodes, InputCollection
} from "./DSL";
import {Bottom, Interpreter, RunningState} from "./interpreter";
import {StatementDOMNodeUnifyResultUnit, StatementInputPathUnifyResultUnit, Unifier} from "./unifier";
import {Parameterizer} from "./parameterizer";

var FOR_LOOP_VISION_RANGE = 12
var NUM_WORKLIST_LIMIT = 5000
var NUM_RESULT_LIMIT = 20
// var NUM_VALIDATED_PROGRAMS = 30000
// var NUM_WORKLIST_ITEM = 100

//check if left is a strict prefix of right
export function isStrictPrefixActionTrace(left:ActionTrace|Bottom, right:ActionTrace|Bottom):boolean{
    if(left instanceof Bottom || right instanceof Bottom){
        return false
    }
    if(right.prediction !== undefined){
        return left.start == right.start && left.end <= right.end;
    }
    else{
        return left.start == right.start && left.end < right.end;
    }

}
export function isPrefixActionTrace(left:ActionTrace|Bottom, right:ActionTrace|Bottom):boolean{
    if(left instanceof Bottom || right instanceof Bottom){
        return false
    }
    if(right.prediction !== undefined){
        return left.start == right.start && left.end <= right.end;
    }
    else{
        return left.start == right.start && left.end <= right.end;
    }

}

function concatDOMStatesVec(domStatesVec:DOMStateTrace[], start:number, end:number):DOMStateTrace{
    let newStart:number = domStatesVec[start].start
    let newEnd:number = domStatesVec[end-1].end
    for(let i = start; i < end-1; ++i){
        if(domStatesVec[i].end+1 !== domStatesVec[i+1].start){
            throw "DOM State vec not continuous!"
        }
    }
    return new DOMStateTrace(newStart, newEnd)
}
function concatActionTraceVec(actionTraceVec:ActionTrace[], start:number, end:number):ActionTrace{
    let newStart:number = actionTraceVec[start].start
    let newEnd:number = actionTraceVec[end-1].end
    for(let i = start; i < end-1; ++i){
        if(actionTraceVec[i].end+1 !== actionTraceVec[i+1].start){
            throw "Action vec not continuous!"
        }
    }
    return new ActionTrace(newStart, newEnd)
}

export class RewriteWorklistUnit{
    public program:Program
    public domStatesVec:DOMStateTrace[]
    public actionTraceVec:ActionTrace[]
    public startIndex:number
    constructor(program:Program, domStatesVec:DOMStateTrace[], actionTraceVec:ActionTrace[], startIndex:number = 0) {
        this.program = program
        this.domStatesVec = domStatesVec
        this.actionTraceVec = actionTraceVec
        this.startIndex = startIndex
    }

    public extendOneWithEndForLoop():RewriteWorklistUnit{
        let newDomStatesVec:DOMStateTrace[] = this.domStatesVec.slice()
        //extend final vector by 1
        newDomStatesVec[newDomStatesVec.length-1] = new DOMStateTrace(newDomStatesVec[newDomStatesVec.length-1].start,newDomStatesVec[newDomStatesVec.length-1].end+1)
        let newActionVec:ActionTrace[] = this.actionTraceVec.slice()
        //extend final vector by 1
        newActionVec[newActionVec.length-1] = new ActionTrace(newActionVec[newActionVec.length-1].start,newActionVec[newActionVec.length-1].end+1)
        return new RewriteWorklistUnit(this.program, newDomStatesVec, newActionVec)
    }

    public extendOneWithNewAction(action:Action):RewriteWorklistUnit{
        let newDomStatesVec:DOMStateTrace[] = this.domStatesVec.slice()
        //extend final vector by 1
        newDomStatesVec.push(new DOMStateTrace(newDomStatesVec[newDomStatesVec.length-1].end+1,newDomStatesVec[newDomStatesVec.length-1].end+1))
        let newActionVec:ActionTrace[] = this.actionTraceVec.slice()
        //extend final vector by 1
        newActionVec.push(new ActionTrace(newActionVec[newActionVec.length-1].end+1,newActionVec[newActionVec.length-1].end+1))
        let newProgram = new Program(this.program.blocks.slice())
        newProgram.blocks.push(action)
        return new RewriteWorklistUnit(newProgram, newDomStatesVec, newActionVec)
    }

    public deleteLastRangeUntil(range:number):RewriteWorklistUnit{
        let newDomStatesVec:DOMStateTrace[] = this.domStatesVec.slice()
        //extend final vector by 1
        newDomStatesVec[newDomStatesVec.length-1] = new DOMStateTrace(newDomStatesVec[newDomStatesVec.length-1].start,range)
        let newActionVec:ActionTrace[] = this.actionTraceVec.slice()
        //extend final vector by 1
        newActionVec[newActionVec.length-1] = new ActionTrace(newActionVec[newActionVec.length-1].start,range)
        return new RewriteWorklistUnit(this.program, newDomStatesVec, newActionVec)
    }
}

class SpeculativeRewriteUnit{
    public startingIndex:number
    public rewriteBlock:Statement
    public leastRewrittenIndex:number
    constructor(startingIndex:number, rewriteBlock:Statement, leastRewrittenIndex:number) {
        this.startingIndex = startingIndex
        this.rewriteBlock = rewriteBlock
        this.leastRewrittenIndex = leastRewrittenIndex
    }

    toString(){
        return "index: " + this.startingIndex + "\nprogram:\n" + this.rewriteBlock.toString() +"\n"
    }
}


export function synthesize(domStates:DOMState[],actionTrace:Action[],inputData:InputJSON, previousCachedWorkListItems?:RewriteWorklistUnit[]):[CachedUnits:RewriteWorklistUnit[], CorrectUnits:RewriteWorklistUnit[],PredictedActions:Action[]]{
    FileReadTimeCounter.init()
    let terminateCount:number = 0
    TimeBudget.initTotalTime()
    GlobalRunningEnv.init(actionTrace,domStates,inputData)
    //initDOMPersistentVerifier(actionTrace, domStates)

    let workList:NoRepeatWorkListArray = new NoRepeatWorkListArray()
    let result:NoRepeatWorkListArray = new NoRepeatWorkListArray()
    let predictedActions:NoRepeatActionArray = new NoRepeatActionArray()
    let cachedWorkList:NoRepeatWorkListArray = new NoRepeatWorkListArray()

    //begin with cached WorkListItem
    if(previousCachedWorkListItems && previousCachedWorkListItems.length > 0){
        for(let c of previousCachedWorkListItems){
            workList.push(c)
        }
    }

    let numWorklistLeastEnterTime = 1

    while(workList.length > 0 && ((!TimeBudget.reachTotalLimit() && cachedWorkList.length < NUM_WORKLIST_LIMIT) || numWorklistLeastEnterTime > 0)){
        numWorklistLeastEnterTime = numWorklistLeastEnterTime - 1

        workList.sort(workListSortFunc)
        let workListItem = workList.shift()
        if(workListItem === undefined){
            break;
        }
        let speculativeRewrites:SpeculativeRewriteUnit[] = generateSpeculativeRewrites(workListItem.program,
            workListItem.actionTraceVec, workListItem.domStatesVec, workListItem.startIndex)
        let validatedRewrites:RewriteWorklistUnit[] = []
        // if(DEBUG.on){
        //     console.log("<<<<<<Speculative rewrites begin>>>>>>>")
        //     for(let s of speculativeRewrites){
        //         console.log(s.toString())
        //     }
        //     console.log("<<<<<<Speculative rewrites end>>>>>>>>")
        // }

        if(speculativeRewrites.length === 0){
            validatedRewrites.push(workListItem)
        }
        else{
                validatedRewrites = validateRewrite(workListItem.program,
                workListItem.domStatesVec, workListItem.actionTraceVec, speculativeRewrites)

            if(DEBUG.on){
                console.log("------Start adding to final result------")
            }
        }
        let leastVerifiedItem = 1
        for(let item of validatedRewrites){
            if(TimeBudget.reachValidateLimit() && leastVerifiedItem <= 0){
                break
            }
            leastVerifiedItem = leastVerifiedItem - 1
            // if(terminateCount >= NUM_WORKLIST_ITEM){
            //     break
            // }
            workList.push(item)
            if(DEBUG.on){
                console.log("Testing strict prefix:")
                console.log(item.program.toString())
                console.log()
            }
            let runningState:RunningState = Interpreter.evaluate(new RunningState(new DOMStateTrace(0,domStates.length-1),new ActionTrace(0,actionTrace.length-1),
                new ExecEnvironment()),item.program,false,true)
            if(isStrictPrefixActionTrace(new ActionTrace(0, actionTrace.length-1),runningState.actionTrace)){
                result.push(item)
                //if the worklist rewrite can generate for loop, then push it to cached worklist
                cachedWorkList.push(item)
                if(cachedWorkList.length > NUM_WORKLIST_LIMIT){
                    break
                }
                let tmp:ActionTrace = <ActionTrace>runningState.actionTrace
                predictedActions.push(tmp.trace[tmp.trace.length-1])
                terminateCount = terminateCount + 1
            }
            else if(isPrefixActionTrace(new ActionTrace(0, actionTrace.length-1),runningState.actionTrace) && getLoopNestedLevel(item.program) >= 2){
                //save synthesized multi-level loop
                cachedWorkList.push(item)
                if(cachedWorkList.length > NUM_WORKLIST_LIMIT){
                    break
                }
            }
        }
    }
    result.sort(workListSortFunc)
    //append remaining worklist to cached worklist
    cachedWorkList.concat(workList)
    cachedWorkList.sort(workListSortFunc)
    return [cachedWorkList.values(),result.values().slice(0,NUM_RESULT_LIMIT),predictedActions.values()]
}

export function generateSpeculativeRewrites(program:Program, actionTraceVec:ActionTrace[], domTraceVec:DOMStateTrace[], startIndex:number = 0):SpeculativeRewriteUnit[]{
    TimeBudget.initSpeculativeRewrite()
    let resultOverall:SpeculativeRewriteUnit[] = []

    //This part corresponds to the one that generates ForInput structure
    for(let i = startIndex ; i < program.blocks.length ; ++i){
        if(TimeBudget.reachSpeculateLimit() || TimeBudget.reachTotalLimit()){
            break
        }
        for(let j = i; j < Math.min(i+FOR_LOOP_VISION_RANGE, program.blocks.length) ; ++j){
            if(TimeBudget.reachSpeculateLimit() || TimeBudget.reachTotalLimit()){
                break
            }
            for(let p = i; p <= j; ++p){
                if(TimeBudget.reachSpeculateLimit() || TimeBudget.reachTotalLimit()){
                    break
                }
                let q = j+(p-i)+1
                if(q >= program.blocks.length){
                    continue
                }
                //the loop body should be fully covered
                if(j+(j-i)+1 >= program.blocks.length){
                    break
                }
                // {S_i;...;S_p;...S_j};...S_q
                //here we just deal with the case when both actions are SendData
                if(!(program.blocks[p] instanceof SendData && program.blocks[q] instanceof SendData)){
                    continue
                }
                let statementUnifyResult:StatementInputPathUnifyResultUnit[]|null = Unifier.unifyStatementsForInputPathLoop(program.blocks[p], program.blocks[q])
                if(!statementUnifyResult){
                    continue
                }
                for(let s of statementUnifyResult){
                    if(TimeBudget.reachSpeculateLimit()){
                        break
                    }
                    if(!s){
                        continue
                    }
                    let [firstInputPath,_] = s.collection.next(new ExecEnvironment())
                    let parameterizedStatementsList:Statement[][] = []
                    let valid = true
                    for(let cur = i; cur <= j; ++cur) {
                        parameterizedStatementsList.push([])
                        if (cur === p) {
                            parameterizedStatementsList[p - i].push(s.parameterizedStatement)
                            continue
                        }
                        let parameterizedStatements: Statement[] = Parameterizer.parameterizeStatementForInputNode(program.blocks[cur], s.variable, firstInputPath, program.blocks[cur - i + j + 1])
                        if (parameterizedStatements.length === 0) {
                            valid = false
                            break
                        }
                        parameterizedStatementsList[cur-i] = parameterizedStatements
                    }
                    if(valid){
                        resultOverall = resultOverall.concat(generateCartesianProdRewriteBlocksForInputNode(parameterizedStatementsList, s.variable, s.collection, i, q))
                    }

                }
            }
        }
    }

    //This part corresponds to the one that generates ForDOMNode structure
    for(let i = startIndex ; i < program.blocks.length ; ++i){
        if(TimeBudget.reachSpeculateLimit() || TimeBudget.reachTotalLimit()){
            break
        }
        for(let j = i; j < Math.min(i+FOR_LOOP_VISION_RANGE, program.blocks.length) ; ++j){
            if(TimeBudget.reachSpeculateLimit() || TimeBudget.reachTotalLimit()){
                break
            }
            for(let p = i; p <= j; ++p){
                if(TimeBudget.reachSpeculateLimit() || TimeBudget.reachTotalLimit()){
                    break
                }
                let q = j+(p-i)+1
                if(q >= program.blocks.length){
                    continue
                }
                //the loop body should be fully covered
                if(j+(j-i)+1 >= program.blocks.length){
                    break
                }
                // {S_i;...;S_p;...S_j};...S_q
                let statementUnifyResult:StatementDOMNodeUnifyResultUnit[]|null = Unifier.unifyStatementsForDomNodeLoop(program.blocks[p], program.blocks[q])
                if(!statementUnifyResult){
                    continue
                }
                for(let s of statementUnifyResult){
                    if(TimeBudget.reachSpeculateLimit() || TimeBudget.reachTotalLimit()){
                        break
                    }
                    if(!s){
                        continue
                    }
                    let [firstDOMNode,_] = s.collection.next(new ExecEnvironment())
                    let parameterizedStatementsList:Statement[][] = []
                    let valid = true
                    for(let cur = i; cur <= j; ++cur) {
                        parameterizedStatementsList.push([])
                        if (cur === p) {
                            parameterizedStatementsList[p - i].push(s.parameterizedStatement)
                            continue
                        }
                        let parameterizedStatements: Statement[] = Parameterizer.parameterizeStatementForDOMNode(program.blocks[cur], s.variable,firstDOMNode , program.blocks[cur - i + j + 1])
                        if (parameterizedStatements.length === 0) {
                            valid = false
                            break
                        }
                        parameterizedStatementsList[cur-i] = parameterizedStatements
                    }
                    if(valid){
                        resultOverall = resultOverall.concat(generateCartesianProdRewriteBlocksForDOMNode(parameterizedStatementsList, s.variable, s.collection, i, q))
                    }

                }
            }
        }
    }

    //This part corresponds to the one that generates while loop
    for(let i = startIndex ; i < program.blocks.length ; ++i){
       for(let p = i+1; p < Math.min(i+FOR_LOOP_VISION_RANGE,program.blocks.length); ++p){
           let q = 2 * p - i + 1 // p - i + 1 = q - p
           if(q >= program.blocks.length){
               break
           }
           let actionA = program.blocks[p]
           let actionB = program.blocks[q]
           if(actionA instanceof Click && actionB instanceof Click){
               //here we need to validate it - two while loop body should be equal
               let bodyFirst = new Program(program.blocks.slice(i,p))
               let bodySecond = new Program(program.blocks.slice(p+1,q))
               if(!bodyFirst.equals(bodySecond)){
                   continue
               }
               let commonXpathSet:DOMNode[] = actionA.target.getSharedXpath(actionB.target)
               for(let commonXpathResult of commonXpathSet){
                   resultOverall.push(new SpeculativeRewriteUnit(i, new WhileLoopWithClick(new Program(program.blocks.slice(i, p)), new Click(commonXpathResult, 0)), q))
               }
           }
       }
    }

    return resultOverall;
}

export function validateRewrite(program:Program, domStatesVec:DOMStateTrace[], actionTraceVec:ActionTrace[],
                                speculativeRewrites:SpeculativeRewriteUnit[]):RewriteWorklistUnit[]{
    TimeBudget.initValidateBeginTime()
    let returnResult:RewriteWorklistUnit[] = []
    for(let speculativeRewrite of speculativeRewrites){
        if(DEBUG.on){
            console.log("Validating ....")
            console.log(speculativeRewrite.rewriteBlock.toString())
            console.log("............")
        }

        let runningState = Interpreter.evaluate(
            new RunningState(concatDOMStatesVec(domStatesVec,speculativeRewrite.startingIndex,program.blocks.length),
                concatActionTraceVec(actionTraceVec,speculativeRewrite.startingIndex,program.blocks.length),
                new ExecEnvironment()),
            speculativeRewrite.rewriteBlock,false,true)

        if(runningState.domStateTrace instanceof Bottom || runningState.actionTrace instanceof Bottom){
            if(DEBUG.on){
                console.log("NOT CONSISTENT")
            }
            continue
        }
        for(let r = speculativeRewrite.leastRewrittenIndex+1; r <= domStatesVec.length; ++r){
            let tmpDOMStates = concatDOMStatesVec(domStatesVec,speculativeRewrite.startingIndex,r)
            if(tmpDOMStates.length < runningState.domStateTrace.length){
                continue
            }
            if(tmpDOMStates.length > runningState.domStateTrace.length){
                if(DEBUG.on){
                    console.log("FAILED - dom length larger than original length ")
                }
                break
            }
            let tmpActionTrace = concatActionTraceVec(actionTraceVec,speculativeRewrite.startingIndex,r)
            if(tmpActionTrace.trace.length < runningState.actionTrace.trace.length){
                if(tmpActionTrace.trace.length === runningState.actionTrace.trace.length-1){
                    //this case happens when the last for loop predicts an action
                }else{
                    continue
                }
            }
            if(tmpActionTrace.trace.length > runningState.actionTrace.trace.length){
                if(DEBUG.on){
                    console.log("FAILED - action length larger than original length ")
                }
                break
            }
            if(tmpDOMStates.equals(runningState.domStateTrace) && (tmpActionTrace.equals(runningState.actionTrace) || isStrictPrefixActionTrace(tmpActionTrace,runningState.actionTrace))){
                //console.log('\x1b[32m%s\x1b[0m', "VALIDATED\n")

                //here, we restrict that validated program must has a for loop in the end
                let programAfterRewriteBlock:Statement[] = program.blocks.slice(r)
                if(programAfterRewriteBlock.length > 0){
                    // //todo: when adding new for loop style, need to modify
                    // if(!(programAfterRewriteBlock[programAfterRewriteBlock.length-1] instanceof ForEachDOMNodes)){
                    //     break;
                    // }
                }

                let programNew = new Program(program.blocks.slice(0,speculativeRewrite.startingIndex).concat(
                    speculativeRewrite.rewriteBlock).concat(program.blocks.slice(r)))
                let domStatesVecNew = domStatesVec.slice(0,speculativeRewrite.startingIndex).concat(runningState.domStateTrace).concat(
                    domStatesVec.slice(r))
                let actionTraceVecNew = actionTraceVec.slice(0,speculativeRewrite.startingIndex).concat(runningState.actionTrace).concat(
                    actionTraceVec.slice(r))
                returnResult.push(new RewriteWorklistUnit(programNew,domStatesVecNew,actionTraceVecNew))
                if(DEBUG.on){
                    console.log("SUCCEED")
                }
                break;
            }
        }
        if(TimeBudget.reachValidateLimit() || TimeBudget.reachTotalLimit()){
            break
        }
    }
    return returnResult
}

// function initDOMPersistentVerifier(actions:Action[], doms:DOMState[]){
//     let i = 0;
//     for(let a of actions){
//         if(a instanceof Click){
//             DOMPersistentVerifier.addConfirmedElement(doms[i],a.target)
//         }
//         if(a instanceof ScrapeText){
//             DOMPersistentVerifier.addConfirmedElement(doms[i],a.target)
//         }
//         if(a instanceof ScrapeLink){
//             DOMPersistentVerifier.addConfirmedElement(doms[i],a.target)
//         }
//         if(a instanceof Download){
//             DOMPersistentVerifier.addConfirmedElement(doms[i],a.target)
//         }
//         if(a instanceof SendKeys){
//             DOMPersistentVerifier.addConfirmedElement(doms[i],a.target)
//         }
//         if(a instanceof SendData){
//             DOMPersistentVerifier.addConfirmedElement(doms[i],a.target)
//         }
//         i = i+1
//     }
// }

export class DEBUG{
    public static on = false
    public static showTestingResult = false
    public static showDOMVerifierCache = false
    public static procedureInfoDisplay = false
}

export class SELECTORSYN{
    public static twoLevelOn = true
    public static numConst = 500
}

export class TimeBudget{
    private static speculativeRewriteBeginTime:Date = new Date()
    private static totalBeginTime:Date = new Date()
    private static validateBeginTime:Date = new Date()
    private static timeBudgetTotalInMs:number = 1000
    private static timeBudgetSpeculateRewriteInMs:number = 300
    private static timeBudgetValidateInMs:number = 100

    public static setTimeBudget(speculate:number, validate:number, total:number){
        TimeBudget.timeBudgetSpeculateRewriteInMs = speculate
        TimeBudget.timeBudgetValidateInMs = validate
        TimeBudget.timeBudgetTotalInMs = total
    }
    public static initSpeculativeRewrite(){
        TimeBudget.speculativeRewriteBeginTime = new Date()
    }
    public static initValidateBeginTime(){
        TimeBudget.validateBeginTime = new Date()
    }
    public static initTotalTime(){
        TimeBudget.totalBeginTime = new Date()
    }

    public static reachTotalLimit():boolean{
        let curTime = new Date()
        let timeDiff = curTime.getTime()-TimeBudget.totalBeginTime.getTime()-FileReadTimeCounter.getTimeSpent()
        if(timeDiff >= TimeBudget.timeBudgetTotalInMs){
            if(DEBUG.procedureInfoDisplay){
                console.log("reach total limit")
            }
            return true
        }
        else{
            return false
        }
    }
    public static reachSpeculateLimit():boolean{
        let curTime = new Date()
        let timeDiff = curTime.getTime()-TimeBudget.speculativeRewriteBeginTime.getTime()-FileReadTimeCounter.getTimeSpent()
        if(timeDiff >= TimeBudget.timeBudgetSpeculateRewriteInMs){
            if(DEBUG.procedureInfoDisplay){
                console.log("reach speculate limit")
            }
            return true
        }
        else{
            return false
        }
    }
    public static reachValidateLimit():boolean{
        let curTime = new Date()
        let timeDiff = curTime.getTime()-TimeBudget.validateBeginTime.getTime()-FileReadTimeCounter.getTimeSpent()
        if(timeDiff >= TimeBudget.timeBudgetValidateInMs){
            if(DEBUG.procedureInfoDisplay){
                console.log("reach validate limit")
            }
            return true
        }
        else{
            return false
        }
    }
}



function workListSortFunc(a:RewriteWorklistUnit, b:RewriteWorklistUnit){
    if(a.program.blocks.length > b.program.blocks.length){
        return 1
    }
    if(a.program.blocks.length < b.program.blocks.length){
        return -1
    }
    return 0
}

function getLoopNestedLevel(p:Program|Statement):number{
    if(p instanceof Program){
        let maxNestedLevel = 0
        for(let s of p.blocks){
            let nestedLevelForS = getLoopNestedLevel(s)
            if(maxNestedLevel< nestedLevelForS){
                maxNestedLevel = nestedLevelForS
            }
        }
        return maxNestedLevel
    }
    if(p instanceof LoopyStatement){
        return getLoopNestedLevel(p.loopBody) + 1
    }
    return 0
}

function generateCartesianProdRewriteBlocksForDOMNode(statements:Statement[][], variable:Variable, collection:DOMNodes,startIndex:number, leastRewriteIndex:number):SpeculativeRewriteUnit[]{
    let result:SpeculativeRewriteUnit[] = []
    //selecting indices
    let selectIndices:number[] = []
    let selectIndicesMax:number[] = []
    for(let i = 0; i < statements.length; ++i){
        selectIndices.push(0)
        selectIndicesMax.push(statements[i].length-1)
    }
    while(!shouldCartesianProductStop(selectIndices,selectIndicesMax)&&!TimeBudget.reachSpeculateLimit()){
        let program:Program = new Program()
        for(let i = 0; i < selectIndices.length; ++i){
            program.blocks.push(statements[i][selectIndices[i]])
        }
        result.push(new SpeculativeRewriteUnit(startIndex,new ForEachDOMNodes(variable,collection,program),leastRewriteIndex))
        selectIndices = getNextCartesianProductIndices(selectIndices,selectIndicesMax)
    }
    return result
}
function generateCartesianProdRewriteBlocksForInputNode(statements:Statement[][], variable:Variable, collection:InputCollection,startIndex:number, leastRewriteIndex:number):SpeculativeRewriteUnit[]{
    let result:SpeculativeRewriteUnit[] = []
    //selecting indices
    let selectIndices:number[] = []
    let selectIndicesMax:number[] = []
    for(let i = 0; i < statements.length; ++i){
        selectIndices.push(0)
        selectIndicesMax.push(statements[i].length-1)
    }
    while(!shouldCartesianProductStop(selectIndices,selectIndicesMax)&&!TimeBudget.reachSpeculateLimit()){
        let program:Program = new Program()
        for(let i = 0; i < selectIndices.length; ++i){
            program.blocks.push(statements[i][selectIndices[i]])
        }
        result.push(new SpeculativeRewriteUnit(startIndex,new ForEachInput(variable,collection,program),leastRewriteIndex))
        selectIndices = getNextCartesianProductIndices(selectIndices,selectIndicesMax)
    }
    return result
}

function shouldCartesianProductStop(selectIndices:number[], selectIndicesMax:number[]):boolean{
    for(let i = 0; i < selectIndicesMax.length; ++i){
        if(selectIndices[i] > selectIndicesMax[i]){
            return true
        }
    }
    return false
}

function getNextCartesianProductIndices(selectIndices:number[], selectIndicesMax:number[]):number[]{
    for(let i = 0; i < selectIndicesMax.length; ++i){
        if(selectIndices[i] < selectIndicesMax[i]){
            //return it
            selectIndices[i] = selectIndices[i]+1
            return selectIndices
        }
    }
    selectIndices[0]=selectIndices[0]+1
    return selectIndices
}

export class FileReadTimeCounter{
    private static totalTimeInMsSpend = 0
    private static tmpStartDate:Date = new Date()
    public static init(){
        FileReadTimeCounter.totalTimeInMsSpend = 0
    }

    public static start(){
        FileReadTimeCounter.tmpStartDate = new Date()
    }

    public static end(){
        FileReadTimeCounter.totalTimeInMsSpend += (new Date().getTime() - FileReadTimeCounter.tmpStartDate.getTime())
    }

    public static getTimeSpent(){
        return FileReadTimeCounter.totalTimeInMsSpend
    }

}