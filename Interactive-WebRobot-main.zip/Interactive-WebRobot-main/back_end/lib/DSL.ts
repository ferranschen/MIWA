"use strict"
/* Libraries imported */
// import {JSDOM} from "jsdom"
const xpathlib = require('xpath');
const parse5 = require('parse5');
const xmlser = require('xmlserializer');
const domlib = require('xmldom').DOMParser;
import {
    DEBUG,
    FileReadTimeCounter,
    isPrefixActionTrace,
    isStrictPrefixActionTrace,
    RewriteWorklistUnit,
    SELECTORSYN
} from "./algorithms";
import {ForLoopVerifyStatus, InterpreterForForLoopValid} from "./interpreter";
import {readFileSync} from "fs";

/* Some helper functions */
function getIndent(indent_num?:number): string{
    let result:string = ""
    if(indent_num !== undefined)
    {
        for(let i = 0; i < indent_num; ++i){
            result += "  "
        }
    }
    return result;
}
export function programToString(p:Program): string{
    AlphaEquivVarPrinter.fresh()
    return p.toString()
}
export function actionFactory(actionObject:{ [index: string]: any }, timestamp:number = 0, url:string = "",
                              data_dictionary?:{ [data: string]: string }): Action {
    let action = actionObject.actionName
    switch (action){
        case "Click":
            actionObject.targetElement = DOMNodeMatrix.constructFromStringMatrix(actionObject.targetElement)
            return new Click(new DOMNodePointer(actionObject.targetElement), timestamp, url)
        case "SendKeys":
            actionObject.targetElement = DOMNodeMatrix.constructFromStringMatrix(actionObject.targetElement)
            return new SendKeys(new DOMNodePointer(actionObject.targetElement),actionObject.data, timestamp, url)
        case "SendData":
            actionObject.targetElement = DOMNodeMatrix.constructFromStringMatrix(actionObject.targetElement)
            return new SendData(new DOMNodePointer(actionObject.targetElement),
                new InputPath(data_dictionary ? data_dictionary[actionObject.data] : actionObject.data),
                timestamp, url)
        case "ScrapeText":
            actionObject.targetElement = DOMNodeMatrix.constructFromStringMatrix(actionObject.targetElement)
            return new ScrapeText(new DOMNodePointer(actionObject.targetElement), timestamp, url)
        case "ScrapeLink":
            actionObject.targetElement = DOMNodeMatrix.constructFromStringMatrix(actionObject.targetElement)
            return new ScrapeLink(new DOMNodePointer(actionObject.targetElement), timestamp, url)
        case "Download":
            actionObject.targetElement = DOMNodeMatrix.constructFromStringMatrix(actionObject.targetElement)
            return new Download(new DOMNodePointer(actionObject.targetElement), timestamp, url)
        case "ExtractURL":
        case "ScrapeCurURL":
        case "ScrapeURL":
            return new ExtractURL(timestamp, url)
        case "GoBack":
        case "Goback":
            return new GoBack(timestamp, url)
        default:
            throw "Wrong action format: " + action
    }
}

/* Enum classes */
export enum StatementDisplayName{
    Click = "Click",
    ScrapeText = "ScrapeText",
    ScrapeLink = "ScrapeLink",
    Download = "Download",
    ExtractURL = "ExtractURL",
    GoBack = "GoBack",
    SendKeys = "SendKeys",
    SendData = "SendData",
    ForEachDOMNodes = "ForEach",
    ForEachInput = "ForEachInput",
    WhileLoopWithClick = "While",
    IterateElement = "IterateElement"
}

export enum StatementFunctionType {
    Null,       // IterateElement
    Scrape,     // ScrapeText | ScrapeLink | Download | ExtractURL
    Input,      // SendKeys | SendData
    Click,      // Click
    Navigate,   // WhileClick | GoBack
    Control     // ForEachDOMNodes | ForEachInput | WhileLoopWithClick
}

enum PredicateSearchType{
    Child,
    Descendant,
    Root
}

/* Environment related classes */
export class GlobalRunningEnv{
    public static actionTrace: Action[] = []
    public static domTrace: DOMState[] = []
    public static inputData:InputJSON

    public static init(actionTrace: Action[], domTrace:DOMState[], inputDataJson:InputJSON){
        GlobalRunningEnv.actionTrace = actionTrace
        GlobalRunningEnv.domTrace = domTrace
        GlobalRunningEnv.inputData = inputDataJson
    }

    public static clear(){
        for(let i = 0; i < GlobalRunningEnv.domTrace.length; ++i){
            GlobalRunningEnv.domTrace[i] = new DOMState("")
        }
    }

    public static getActionByIndex(index:number){
        return GlobalRunningEnv.actionTrace[index]
    }

    public static getDomByIndex(index:number){
        return GlobalRunningEnv.domTrace[index]
    }

    public static getInputDataByPath(inputPath:InputPath){
        return GlobalRunningEnv.inputData.load(inputPath).toString()
    }

}
export class ExecEnvironment{
    public readonly variableDict: {[variableId: number]:any}
    constructor() {
        this.variableDict = {}
    }

    public load(variable:Variable):any{
        let tmp = this.variableDict[variable.getID]
        if(tmp !== undefined)
        {
            return this.variableDict[variable.getID]
        }
        else
        {
            throw "Error evaluating " + variable.getName + " from the environment."
        }

    }

    public save(variable:Variable,value:any){
        this.variableDict[variable.getID] = value
    }

}
export class Variable{
    public readonly id:number
    public readonly name:string

    constructor(isInputVariable:boolean = false) {
        if(isInputVariable){
            this.id = UniqueIDGenerator.getNewInputId()
            this.name = UniqueVariableNameGenerator.getNewInputName()
        }
        else
        {
            this.id = UniqueIDGenerator.getNewId()
            this.name = UniqueVariableNameGenerator.getNewName()
        }
    }

    get getID(){
        return this.id
    }
    get getName(){
        return this.name
    }

    public equals(other:Variable):boolean{
        return this.id === other.id
    }
    toString(){
        return AlphaEquivVarPrinter.print(this)
    }
}

/* Trace related classes */
export class DOMState {
    public readonly id:number;
    // public dataDOM:any = null;
    public dataDOM:any;

    constructor(dom:string) {
        this.id = UniqueRealIDGenerator.getNewId()
        // this.dataDOM = new dom({
        //     locator: {},
        //     errorHandler: { warning: function (w:any) { },
        //         error: function (e:any) { },
        //         fatalError: function (e:any) { console.error(e) } }
        // }).parseFromString(domString);
        this.dataDOM = null
        let document = parse5.parse(dom.toString())
        let xhtml = xmlser.serializeToString(document)
        this.dataDOM = new domlib().parseFromString(xhtml)
    }

    public equals(other:DOMState):boolean{
        return this.id === other.id;
    }

    public isEqualNode(left:DOMNodeRepresentative, right:DOMNodeRepresentative):boolean{
        if(left instanceof DOMNode && right instanceof DOMNode){
            let a = this.__getNode(left)
            let b = this.__getNode(right)
            if(a === null || b === null){
                return false
            }
            return a === b
        }
        if(left instanceof DOMNodePointer && right instanceof DOMNode){
            let a = this.__getNode(left.getNodeSet()[0])
            let b = this.__getNode(right)
            if(a === null || b === null){
                return false
            }
            return a === b
        }
        if(left instanceof DOMNode && right instanceof DOMNodePointer){
            let a = this.__getNode(left)
            let b = this.__getNode(right.getNodeSet()[0])
            if(a === null || b === null){
                return false
            }
            return a === b
        }
        if(left instanceof DOMNodePointer && right instanceof DOMNodePointer){
            let a = this.__getNode(left.getNodeSet()[0])
            let b = this.__getNode(right.getNodeSet()[0])
            if(a === null || b === null){
                return false
            }
            return a === b
        }
        return false

    }

    public checkValidFromDOM(target:DOMNodeRepresentative):boolean{
        // return true
        if(target instanceof DOMNode){
            return DOMPersistentVerifier.valid(this,target)
        }
        else if(target instanceof DOMNodePointer){
            return DOMPersistentVerifier.valid(this,target.getNodeSet()[0])
        }
        return false
    }

    public checkValidForLoop(domTrace:DOMStateTrace, actionTrace:ActionTrace, env:ExecEnvironment, loopBody:Program):ForLoopCheckValidResult{
        // return ForLoopCheckValidResult.Valid
        //This function is designed to do the following:
        //given an action trace, check if the execution of loop body is a prefix of actionTrace. If it is, then we say this for loop pass the valid check
        let verifyResult = InterpreterForForLoopValid.evaluate(new ForLoopVerifyStatus(domTrace, actionTrace, env, ForLoopCheckValidResult.NotDecided),loopBody);
        if(verifyResult.verifyStatus === ForLoopCheckValidResult.NotDecided){
            if(isPrefixActionTrace(verifyResult.actionTrace, actionTrace)){
                return ForLoopCheckValidResult.Valid
            }
            else{
                return ForLoopCheckValidResult.NotValid
            }
        }
        return verifyResult.verifyStatus

    }

    public __valid(target:DOMNode):boolean{
        // return true
        let currentNode:any= this.dataDOM
        for(let node of target.nodePartList){
            if(node instanceof DOMNodePartPredicate){
                let queryString = "."
                if(node.searchType === PredicateSearchType.Descendant)
                {
                    queryString += "//"
                }
                else if(node.searchType === PredicateSearchType.Child)
                {
                    queryString += "/"
                }
                queryString += "x:"+node.predicate.tagName
                if(node.predicate.attributeName !== ""){
                    if(node.predicate.getAttributeValue() !== ""){
                        queryString += "[" + node.predicate.attributeName + "=" + node.predicate.getAttributeValue() +"]"
                    }
                    else{
                        queryString += "[" + node.predicate.attributeName +"]"
                    }
                }

                let snapshots = this.getElementsByXpath(queryString,currentNode)
                if(snapshots.length === 0){
                    return false
                }
                if(node.index === 0 || node.index === 1){
                    if(snapshots.length >= 1){
                        let tmp = snapshots[0]
                        if(tmp){
                            currentNode = tmp
                        }
                        continue
                    }
                    else{
                        return false
                    }
                }else if(node.index > 1){
                    if(snapshots.length >= node.index){
                        let tmp = snapshots[node.index-1]
                        if(tmp) {
                            currentNode = tmp
                        }
                        continue
                    }
                    else{
                        return false
                    }
                }
                else{
                    throw "negative index"
                }
                return false
            }
            else{
                throw "Shouldn't get there - not constant predicates parameter passed to valid function "
            }
        }
        return true
    }

    public __getNode(target:DOMNode){
        // return true
        let currentNode:any= this.dataDOM
        for(let node of target.nodePartList){
            if(node instanceof DOMNodePartPredicate){
                let queryString = "."
                if(node.searchType === PredicateSearchType.Descendant)
                {
                    queryString += "//"
                }
                else if(node.searchType === PredicateSearchType.Child)
                {
                    queryString += "/"
                }
                queryString += "x:"+node.predicate.tagName
                if(node.predicate.attributeName !== ""){
                    if(node.predicate.getAttributeValue() !== ""){
                        queryString += "[" + node.predicate.attributeName + "=" + node.predicate.getAttributeValue() +"]"
                    }
                    else{
                        queryString += "[" + node.predicate.attributeName +"]"
                    }
                }

                let snapshots = this.getElementsByXpath(queryString,currentNode)
                if(snapshots.length === 0){
                    return null
                }
                if(node.index === 0 || node.index === 1){
                    if(snapshots.length >= 1){
                        let tmp = snapshots[0]
                        if(tmp){
                            currentNode = tmp
                        }
                        continue
                    }
                    else{
                        return null
                    }
                }else if(node.index > 1){
                    if(snapshots.length >= node.index){
                        let tmp = snapshots[node.index-1]
                        if(tmp) {
                            currentNode = tmp
                        }
                        continue
                    }
                    else{
                        return null
                    }
                }
                else{
                    throw "negative index"
                }
                return null
            }
            else{
                throw "Shouldn't get there - not constant predicates parameter passed to valid function "
            }
        }
        return currentNode
    }
    //return snapshots of a xpath selection
    private getElementsByXpath(xpath:string, parentNode:any){
        let select = xpathlib.useNamespaces({"x": "http://www.w3.org/1999/xhtml"})
        return select(xpath,parentNode)
    }
}
export class DOMStateTrace {
    public start: number = 0 //included
    public end: number = 0 //included
    constructor(start:number = 0, end:number = -1) {
        this.start = start
        this.end = end
    }

    public equals(other:DOMStateTrace){
        return this.start === other.start && this.end === other.end
    }
    public empty():boolean{
        return this.start > this.end
    }
    get length():number{
        return this.end-this.start+1
    }

    get trace():DOMState[]{
        let tmpTrace:DOMState[] = []
        for(let i = this.start; i <= this.end; ++i){
            tmpTrace.push(GlobalRunningEnv.domTrace[i])
        }
        return tmpTrace
    }
}

export class ActionTrace{
    public start: number = 0 //included
    public end: number = 0 //included
    public prediction?:Action = undefined
    constructor(start:number = -1, end:number = -2, prediction?:Action) {
        this.start = start
        this.end = end
        this.prediction = prediction
    }

    public empty():boolean{
        return this.start > this.end && this.prediction === undefined
    }

    get trace():Action[]{
        let tmpTrace:Action[] = []
        for(let i = this.start; i <= this.end; ++i){
            tmpTrace.push(GlobalRunningEnv.actionTrace[i])
        }
        if(this.prediction){
            tmpTrace.push(this.prediction)
        }
        return tmpTrace
    }

    get length():number{
        if(this.start <= this.end){
            return this.end - this.start + 1 + (this.prediction?1:0)
        }
        return 0;
    }

    equals(other:ActionTrace):boolean{
        return this.start === other.start && this.end === other.end
    }


}
/* Statement related classes */
export class Program{
    public content: Statement[] = []
    public index: number = 0 // the index of its first internal statement
    public type: StatementFunctionType = StatementFunctionType.Null
    public length: number = 0
    public isIndexed: boolean = false

    constructor(blocks?:Statement[]) {
        if(blocks!== undefined){
            this.content = blocks
        }
    }
    toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = ""
        for(let block of this.content){
            result += block.toString(indent_num) + "\n"
        }
        return result
    }
    public equals(other:Program):boolean{
        if(this.content.length !== other.content.length){
            return false
        }
        for(let i = 0; i < this.content.length; ++i){
            if(!this.content[i].equals(other.content[i])){
                return false
            }
        }
        return true
    }
    get blocks(){
        return this.content
    }
    public pushAndGetNewProgram(statementToPush:Statement){
        let tmpProgram = new Program(this.content.slice())
        tmpProgram.content.push(statementToPush)
        return tmpProgram
    }

}
export abstract class Statement {
    public index:number = 0;
    public type:StatementFunctionType = StatementFunctionType.Null;
    public abstract toString(indent_num?: number): string
    public abstract equals(other:Statement):boolean
}
export abstract class Action extends Statement{
    public timestamp:number
    public url:string
    constructor(timestamp:number = 0, url:string = "") {
        super();
        this.timestamp = timestamp
        this.url = url
    }
    public abstract toString(indent_num?:number):string
    public abstract equals(other:Action):boolean
    public abstract getNameAndTimestamp():any
}

export abstract class ActionWithTarget extends Action{
    public target:DOMNodeRepresentative
    constructor(target:DOMNodeRepresentative, timestamp:number = 0, url:string = "") {
        super(timestamp, url)
        this.target = target
    }
}

export class Click extends ActionWithTarget{
    constructor(target:DOMNodeRepresentative, timestamp:number = 0, url:string = "") {
        super(target, timestamp, url)
    }

    public toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.Click + " " + this.target.toString()
        return result;
    }
    public getNameAndTimestamp(): any {
        return {"name":StatementDisplayName.Click, "timestamp":this.timestamp}
    }

    public equals(other: Action): boolean {
        if(this.target instanceof DOMNode && other instanceof Click && other.target instanceof DOMNode)
        {
            return this.target.equals(other.target)
        }
        if(this.target instanceof DOMNodePointer && other instanceof Click && other.target instanceof DOMNodePointer)
        {
            return this.target.equals(other.target)
        }
        if(this.target instanceof DOMNode && other instanceof Click && other.target instanceof DOMNodePointer){
            return other.target.hasNodeEqualTo(this.target)
        }
        return false
    }
}
export class ScrapeText extends ActionWithTarget{
    constructor(target:DOMNodeRepresentative, timestamp:number = 0, url:string = "") {
        super(target, timestamp, url);
    }

    public toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.ScrapeText + " " + this.target.toString()
        return result
    }
    public getNameAndTimestamp(): any {
        return {"name":StatementDisplayName.ScrapeText, "timestamp":this.timestamp}
    }
    public equals(other: Action): boolean {
        if(this.target instanceof DOMNode && other instanceof ScrapeText && other.target instanceof DOMNode)
        {
            return this.target.equals(other.target)
        }
        if(this.target instanceof DOMNodePointer && other instanceof ScrapeText && other.target instanceof DOMNodePointer)
        {
            return this.target.equals(other.target)
        }
        if(this.target instanceof DOMNode && other instanceof ScrapeText && other.target instanceof DOMNodePointer){
            return other.target.hasNodeEqualTo(this.target)
        }
        return false
    }
}
export class ScrapeLink extends ActionWithTarget{
    constructor(target:DOMNodeRepresentative, timestamp:number = 0, url:string = "") {
        super(target, timestamp, url);
    }

    public toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.ScrapeLink + " " + this.target.toString()
        return result
    }
    public getNameAndTimestamp(): any {
        return {"name":StatementDisplayName.ScrapeLink, "timestamp":this.timestamp}
    }
    public equals(other: Action): boolean {
        if(this.target instanceof DOMNode && other instanceof ScrapeLink && other.target instanceof DOMNode)
        {
            return this.target.equals(other.target)
        }
        if(this.target instanceof DOMNodePointer && other instanceof ScrapeLink && other.target instanceof DOMNodePointer)
        {
            return this.target.equals(other.target)
        }
        if(this.target instanceof DOMNode && other instanceof ScrapeLink && other.target instanceof DOMNodePointer){
            return other.target.hasNodeEqualTo(this.target)
        }
        return false
    }
}
export class Download extends ActionWithTarget{
    constructor(target:DOMNodeRepresentative, timestamp:number = 0, url:string = "") {
        super(target, timestamp, url);
    }

    public toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.Download + " " + this.target.toString()
        return result
    }
    public getNameAndTimestamp(): any {
        return {"name":StatementDisplayName.Download, "timestamp":this.timestamp}
    }
    public equals(other: Action): boolean {
        if(this.target instanceof DOMNode && other instanceof Download && other.target instanceof DOMNode)
        {
            return this.target.equals(other.target)
        }
        if(this.target instanceof DOMNodePointer && other instanceof Download && other.target instanceof DOMNodePointer)
        {
            return this.target.equals(other.target)
        }
        if(this.target instanceof DOMNode && other instanceof Download && other.target instanceof DOMNodePointer){
            return other.target.hasNodeEqualTo(this.target)
        }
        return false
    }
}
export class ExtractURL extends Action{

    constructor(timestamp:number = 0, url:string = "") {
        super(timestamp, url);
    }
    public getNameAndTimestamp(): any {
        return {"name":StatementDisplayName.ExtractURL, "timestamp":this.timestamp}
    }
    public toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.ExtractURL
        return result
    }

    equals(other: Action): boolean {
        return other instanceof ExtractURL
    }
}
export class GoBack extends Action{
    constructor(timestamp:number = 0, url:string = "") {
        super(timestamp, url);
    }

    public toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.GoBack
        return result
    }
    public getNameAndTimestamp(): any {
        return {"name":StatementDisplayName.GoBack, "timestamp":this.timestamp}
    }
    public equals(other: Action): boolean {
        return other instanceof GoBack
    }

}
export class SendKeys extends ActionWithTarget{
    public readonly keysText:string = ""

    constructor(target:DOMNodeRepresentative, keysText:string, timestamp:number = 0, url:string = "") {
        super(target, timestamp, url)
        this.keysText = keysText
    }
    public equals(other: Action): boolean {
        if(this.target instanceof DOMNode && other instanceof SendKeys && other.target instanceof DOMNode)
        {
            return this.target.equals(other.target) && this.keysText === other.keysText
        }
        if(this.target instanceof DOMNodePointer && other instanceof SendKeys && other.target instanceof DOMNodePointer)
        {
            return this.target.equals(other.target) && this.keysText === other.keysText
        }
        if(this.target instanceof DOMNode && other instanceof SendKeys && other.target instanceof DOMNodePointer){
            return other.target.hasNodeEqualTo(this.target) && this.keysText === other.keysText
        }
        return false
    }

    public getNameAndTimestamp(): any {
        return {"name":StatementDisplayName.SendKeys, "timestamp":this.timestamp}
    }

    public toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.SendKeys + " " + this.target.toString() + " " + this.keysText
        return result;
    }
}
export class SendData extends ActionWithTarget{
    public readonly dataPath:InputPath
    constructor(target:DOMNodeRepresentative, dataPath:InputPath, timestamp:number = 0, url:string = "") {
        super(target, timestamp, url);
        this.dataPath = dataPath
    }
    public revertDataPath(datapath_dictionary: { [datapath: string]: string }) {
        let newDataPath = new InputPath(datapath_dictionary[this.dataPath.nodeList[0].toString()]);
        return new SendData(this.target, newDataPath, this.timestamp, this.url);
    }
    public toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.SendData + " " + this.target.toString() + " " + this.dataPath.toString()
        return result
    }
    public getNameAndTimestamp(): any {
        return {"name":StatementDisplayName.SendData, "timestamp":this.timestamp}
    }
    equals(other: Action): boolean {
        if(this.target instanceof DOMNode && other instanceof SendData && other.target instanceof DOMNode)
        {
            return this.target.equals(other.target) && this.dataPath.equals(other.dataPath)
        }
        if(this.target instanceof DOMNodePointer && other instanceof SendData && other.target instanceof DOMNodePointer)
        {
            return this.target.equals(other.target) && this.dataPath.equals(other.dataPath)
        }
        if(this.target instanceof DOMNode && other instanceof SendData && other.target instanceof DOMNodePointer){
            return other.target.hasNodeEqualTo(this.target) && this.dataPath.equals(other.dataPath)
        }
        return false
    }
}
export class IterateElement extends ActionWithTarget{
    constructor(target:DOMNodeRepresentative, timestamp:number = 0, url:string = "") {
        super(target, timestamp, url);
    }

    public toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.IterateElement + "@" + this.index + " " + this.target.toString()
        return result
    }
    public getNameAndTimestamp(): any {
        return {"name":StatementDisplayName.IterateElement, "timestamp":this.timestamp}
    }
    public equals(other: Action): boolean {
        if(this.target instanceof DOMNode && other instanceof IterateElement && other.target instanceof DOMNode)
        {
            return this.target.equals(other.target)
        }
        if(this.target instanceof DOMNodePointer && other instanceof IterateElement && other.target instanceof DOMNodePointer)
        {
            return this.target.equals(other.target)
        }
        if(this.target instanceof DOMNode && other instanceof IterateElement && other.target instanceof DOMNodePointer){
            return other.target.hasNodeEqualTo(this.target)
        }
        return false
    }
}
export abstract class LoopyStatement extends Statement{
    public loopBody: Program = new Program()
}
export class ForEachDOMNodes extends LoopyStatement{
    public readonly iteratingVariable: Variable
    public readonly domNodes : DOMNodes

    constructor(iteratingVariable:Variable, domNodes:DOMNodes, loopBody:Program) {
        super();
        this.iteratingVariable = iteratingVariable
        this.domNodes = domNodes
        this.loopBody = loopBody;
    }
    toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.ForEachDOMNodes + " " + this.iteratingVariable.toString() + " in " + this.domNodes.toString() + " do {\n"
            + this.loopBody.toString(indent_num + 2) + getIndent(indent_num) + "}"
        return result;
    }

    public equals(other: ForEachDOMNodes): boolean {
        if(!(other instanceof  ForEachDOMNodes)){
            return false
        }
        return this.iteratingVariable.equals(other.iteratingVariable) && this.domNodes.equals(other.domNodes) && this.loopBody.equals(other.loopBody)
    }

}
export class ForEachInput extends LoopyStatement{
    public readonly iteratingVariable: Variable
    public readonly inputCollection : InputCollection

    constructor(iteratingVariable:Variable, inputCollection:InputCollection, loopBody:Program) {
        super();
        this.iteratingVariable = iteratingVariable
        this.inputCollection = inputCollection
        this.loopBody = loopBody;
    }
    toString(indent_num?: number): string {
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.ForEachInput + " " + this.iteratingVariable.toString() + " in " + this.inputCollection.toString() + " do {\n"
            + this.loopBody.toString(indent_num + 2) + getIndent(indent_num) + "}"
        return result;
    }

    public equals(other: ForEachInput): boolean {
        if(!(other instanceof  ForEachInput)){
            return false
        }
        return this.iteratingVariable.equals(other.iteratingVariable) && this.inputCollection.equals(other.inputCollection)
    }

}
export class WhileLoopWithClick extends LoopyStatement{
    public readonly endAction:Click

    constructor(loopBody:Program, endAction:Click) {
        super();
        this.loopBody = loopBody
        this.endAction = endAction
    }

    toString(indent_num?:number):string{
        indent_num = (indent_num === undefined)? 0:indent_num
        let result = getIndent(indent_num)
        result += StatementDisplayName.WhileLoopWithClick + " true do {\n"
            + this.loopBody.toString(indent_num + 2)
            + getIndent(indent_num + 2) + "if valid(" + this.endAction.target.toString() + ") {\n"
            + this.endAction.toString(indent_num + 4) + "\n"
            + getIndent(indent_num+2) + "}\n"
            + getIndent(indent_num) + "}\n"
        return result;
    }
    public equals(other: WhileLoopWithClick){
        if(!(other instanceof  WhileLoopWithClick)){
            return false
        }
        return this.loopBody.equals(other.loopBody) && this.endAction.equals(other.endAction)
    }
}

/* DOM Node related classes */
export class DOMNodeMatrix{
    private matrix:(DOMNodePart|null)[][][] = []

    public shareAtLeastOneSamePath(other:DOMNodeMatrix):boolean{
        let setForThis = this.expandToSetOfDOMNode()
        let setForOthers = this.expandToSetOfDOMNode()

        for(let nodeForThis of setForThis){
            for(let nodeForOthers of setForOthers){
                if(nodeForThis.equals(nodeForOthers)){
                    return true
                }
            }
        }
        return false
    }

    public static constructFromStringMatrix(stringMatrix:string[][][]):DOMNodeMatrix{
        let tmp = new DOMNodeMatrix()
        for(let i = 0; i < stringMatrix.length; ++i){
            tmp.matrix.push([])
            for(let j = 0; j < stringMatrix[i].length; ++j){
                tmp.matrix[i].push([])
                if(stringMatrix[i][j] === null){
                    continue
                }
                for(let k = 0; k < stringMatrix[i][j].length; ++k){
                    tmp.matrix[i][j].push(DOMNodePartPredicate.constructFromStringWithSearchType(stringMatrix[i][j][k]))
                }
            }
        }
        for(let i = 0; i < tmp.matrix.length; ++i){
            for(let j = i+1; j < tmp.matrix.length;++j){
                if(tmp.matrix[i][j] === null){
                    continue
                }
                tmp.matrix[i][j].sort((a:DOMNodePart|null, b:DOMNodePart|null)=>{
                    if(a === null || b ===null){
                        return 0
                    }
                    let selectorRanking = ["class","name","id"]// rank from low to high
                    if(a instanceof DOMNodePartPredicate && b instanceof DOMNodePartPredicate){
                        if(a.predicate.attributeName === ""){
                            return 1
                        }
                        if(b.predicate.attributeName === ""){
                            return -1
                        }
                        let rankA = selectorRanking.indexOf(a.predicate.attributeName)
                        let rankB = selectorRanking.indexOf(b.predicate.attributeName)
                        return rankB-rankA
                    }
                    return 0

                })
            }
        }
        return tmp
    }

    public toString(){
        let result = ""
        for(let i = 0; i < this.matrix.length-1; ++i){
            result += this.matrix[i][i+1][this.matrix[i][i+1].length-1]
        }
        return result
    }

    public expandToSetOfDOMNode():DOMNode[]{
        let result = []
        let elementIndex = this.matrix.length-1

        // //one-level selector
        // for(let selector of this.matrix[0][elementIndex]){
        //     if(!selector){
        //         continue
        //     }
        //     let tmpDOMNodeOneLevel = new DOMNode()
        //     tmpDOMNodeOneLevel.nodePartList.push(selector)
        //     result.push(tmpDOMNodeOneLevel)
        // }

        // //full xpath
        // let tmpDOMNodeFull = new DOMNode()
        // for(let i = 0; i < this.matrix.length-1; ++i){
        //     let part = this.matrix[i][i+1][this.matrix[i][i+1].length-1]
        //     if(!part){
        //         throw "Wong index in expanding to set of DOM Nodes"
        //     }
        //     tmpDOMNodeFull.nodePartList.push(part)
        // }
        // result.push(tmpDOMNodeFull)




        // two-level selector:todo
        if(SELECTORSYN.twoLevelOn)
        {
            for(let i = elementIndex-1; i >= 3; --i){
                // // start with absolute xpath
                //  for(let selectorSecondLevel of this.matrix[i][elementIndex]){
                //      if(selectorSecondLevel === null){
                //          continue
                //      }
                //      let tmpDOMNodeTwoLevels = new DOMNode()
                //      for(let j = 1; j < i; ++j){
                //          let part = this.matrix[j][j+1][this.matrix[j][j+1].length-1]
                //          if(!part){
                //              throw "Wrong index in expanding to set of DOM Nodes"
                //          }
                //          tmpDOMNodeTwoLevels.nodePartList.push(part)
                //      }
                //
                //      tmpDOMNodeTwoLevels.nodePartList.push(selectorSecondLevel)
                //      result.push(tmpDOMNodeTwoLevels)
                //  }
                //  // end with absolute xpath
                //  for(let selectorFirstLevel of this.matrix[0][i]){
                //      let tmpDOMNodeTwoLevels = new DOMNode()
                //      if(selectorFirstLevel === null){
                //          continue
                //      }
                //      tmpDOMNodeTwoLevels.nodePartList.push(selectorFirstLevel)
                //      for(let j = i; j < elementIndex; ++j){
                //          let part = this.matrix[j][j+1][this.matrix[j][j+1].length-1]
                //          if(!part){
                //              throw "Wrong index in expanding to set of DOM Nodes"
                //          }
                //          tmpDOMNodeTwoLevels.nodePartList.push(part)
                //      }
                //      result.push(tmpDOMNodeTwoLevels)
                //  }

                //rest
                for(let selectorFirstLevel of this.matrix[0][i]){
                    for(let selectorSecondLevel of this.matrix[i][elementIndex]){
                        if(selectorFirstLevel === null || selectorSecondLevel === null){
                            continue
                        }
                        if(selectorFirstLevel instanceof DOMNodePartPredicate){
                            if(selectorFirstLevel.predicate.attributeName === ""){
                                continue
                            }
                            // if(selectorFirstLevel.index < 1){
                            //     continue
                            // }
                        }
                        let tmpDOMNodeTwoLevels = new DOMNode()
                        tmpDOMNodeTwoLevels.nodePartList.push(selectorFirstLevel)
                        tmpDOMNodeTwoLevels.nodePartList.push(selectorSecondLevel)
                        result.push(tmpDOMNodeTwoLevels)
                    }
                }
            }
        }

        //one-level selector
        for(let selector of this.matrix[0][elementIndex]){
            if(!selector){
                continue
            }
            let tmpDOMNodeOneLevel = new DOMNode()
            tmpDOMNodeOneLevel.nodePartList.push(selector)
            result.push(tmpDOMNodeOneLevel)
        }

        //full xpath
        let tmpDOMNodeFull = new DOMNode()
        for(let i = 0; i < this.matrix.length-1; ++i){
            let part = this.matrix[i][i+1][this.matrix[i][i+1].length-1]
            if(!part){
                throw "Wong index in expanding to set of DOM Nodes"
            }
            tmpDOMNodeFull.nodePartList.push(part)
        }
        result.push(tmpDOMNodeFull)

        return result
    }

    public getAbsoluteXpath():DOMNode{
        let tmpDOMNodeFull = new DOMNode()
        for(let i = 0; i < this.matrix.length-1; ++i){
            let part = this.matrix[i][i+1][this.matrix[i][i+1].length-1]
            if(!part){
                throw "Wrong index in getAbsoluteXpath"
            }
            tmpDOMNodeFull.nodePartList.push(part)
        }
        return tmpDOMNodeFull
    }
}
export class DOMNodeData{
    public static data: {[id:number]:DOMNodeMatrix} = {}

    public static clear(){
        DOMNodeData.data = {}
    }
    public static getXpathByID(id:number):DOMNodeMatrix{
        let dataItem = DOMNodeData.data[id]
        if(dataItem === undefined){
            throw "Can't locate DOM Node Data by id " + id
        }
        return dataItem
    }

    public static saveData(id:number, xpath:DOMNodeMatrix){
        DOMNodeData.data[id] = xpath
    }
}
export abstract class DOMNodeRepresentative{
    public abstract getSharedXpath(other:DOMNodeRepresentative):DOMNode[]
    public abstract evaluateToDOMNodeWithoutVariable(env:ExecEnvironment):DOMNode|DOMNodePointer
    public abstract equals(other:DOMNodeRepresentative):boolean
}
export class DOMNodePointer extends DOMNodeRepresentative{
    private id:number = 0
    constructor(data:DOMNodeMatrix) {
        super();
        this.id = DOMNodePointerIDGenerator.getNewID()
        DOMNodeData.saveData(this.id,data)
    }

    public equals(other:DOMNodeRepresentative):boolean{
        if(other instanceof DOMNodePointer)
        {
            let toBeComparedFirst = DOMNodeData.getXpathByID(this.id)
            let toBeComparedSecond = DOMNodeData.getXpathByID(other.id)
            //if two are all DOMNode, then return whether two dom nodes are equal
            if(toBeComparedFirst instanceof DOMNode && toBeComparedSecond instanceof DOMNode){
                return toBeComparedFirst.equals(toBeComparedSecond)
            }
            //if two are all matrix
            if(toBeComparedFirst instanceof DOMNodeMatrix && toBeComparedSecond instanceof DOMNodeMatrix){
                return toBeComparedFirst.shareAtLeastOneSamePath(toBeComparedSecond)
            }
            return false
        }
        if(other instanceof DOMNode){
            return other.equals(this)
        }
        return false

    }

    public toString(){
        return DOMNodeData.getXpathByID(this.id).toString()
    }

    public getNodeSet():DOMNode[]{
        return DOMNodeData.getXpathByID(this.id).expandToSetOfDOMNode()
    }

    public hasNodeEqualTo(target:DOMNode):boolean{
        let tmpSet = DOMNodeData.getXpathByID(this.id).expandToSetOfDOMNode()
        for(let t of tmpSet){
            if(t.equals(target)){
                return true
            }
        }
        return false
    }

    public getSharedXpath(other:DOMNodeRepresentative):DOMNode[] {
        if(other instanceof DOMNode) {
            let result: DOMNode[] = []
            let nodeSet = this.getNodeSet()
            for (let n of nodeSet) {
                if (n.equals(other)) {
                    result.push(n)
                }
            }
            return result
        }
        if(other instanceof DOMNodePointer){
            let result:DOMNode[] = []
            let nodeSetThis = this.getNodeSet()
            let nodeSetOther = other.getNodeSet()
            for(let a of nodeSetThis){
                for(let b of nodeSetOther){
                    if(a.equals(b)){
                        result.push(a)
                    }
                }
            }
            return result
        }
        return []

    }

    public hasNodeDiffInOneIndex(target:DOMNodeRepresentative):boolean{
        if(target instanceof  DOMNode){
            let tmpSet:DOMNode[] = DOMNodeData.getXpathByID(this.id).expandToSetOfDOMNode()
            for(let domNode of tmpSet){
                if(target.onlyDiffInOneOffset(domNode)){
                    return true
                }
            }
            return false
        }
        if(target instanceof DOMNodePointer){
            let tmpSetThis:DOMNode[] = DOMNodeData.getXpathByID(this.id).expandToSetOfDOMNode()
            let tmpSetOther:DOMNode[] = DOMNodeData.getXpathByID(target.id).expandToSetOfDOMNode()
            for(let dn1 of tmpSetThis){
                for(let dn2 of tmpSetOther){
                    if(dn1.onlyDiffInOneOffset(dn2)){
                        return true
                    }
                }
            }
            return false
        }
        return false
    }

    public evaluateToDOMNodeWithoutVariable(env: ExecEnvironment):DOMNodePointer{
        return this
    }
}
export class DOMNodePointerIDGenerator{
    private static curID:number = 0
    public static getNewID(){
        this.curID = this.curID + 1
        return this.curID
    }
}
export class DOMNode extends DOMNodeRepresentative{
    public nodePartList:DOMNodePart[] = []

    public static constructFromString(domNodeString:string):DOMNode{
        let tmp = new DOMNode()
        let dividedArray = domNodeString.split("/")
        for(let i = 1; i < dividedArray.length; ++i){
            if(dividedArray[i] === ""){
                tmp.nodePartList.push(DOMNodePartPredicate.constructFromString(dividedArray[i+1],PredicateSearchType.Descendant))
                i = i+1
            }
            else{
                tmp.nodePartList.push(DOMNodePartPredicate.constructFromString(dividedArray[i],PredicateSearchType.Child))
            }
        }
        return tmp
    }
    public static constructForCollection(root:DOMNode, searchType:PredicateSearchType, predicate:Predicate, index:number): DOMNode{
        let tmp = new DOMNode()
        tmp.nodePartList = root.nodePartList.slice()
        tmp.nodePartList.push(new DOMNodePartPredicate(searchType,index,predicate))
        return tmp
    }
    public static constructFromOtherDOMNode(other:DOMNode, start:number, end:number):DOMNode{
        let tmp = new DOMNode()
        for(let i = start;i < end; ++i){
            tmp.nodePartList.push(other.nodePartList[i])
        }
        return tmp
    }
    public static constructFromSingleVariable(variable:Variable) {
        let tmp = new DOMNode()
        tmp.nodePartList.push(new DOMNodePartVar(variable))
        return tmp
    }

    public evaluateToDOMNodeWithoutVariable(env: ExecEnvironment):DOMNode {
        let headNode = this.nodePartList[0]
        if(headNode instanceof DOMNodePartVar){
            let tmp = new DOMNode()
            tmp.nodePartList = headNode.evaluateVariable(env).evaluateToDOMNodeWithoutVariable(env).nodePartList.slice()
            let restOfList:DOMNodePart[] = this.nodePartList.slice(1)
            for(let nodePart of restOfList){
                if(nodePart instanceof DOMNodePartPredicate){
                    tmp.nodePartList.push(nodePart.evaluateToDOMNodePartWithoutVariable(env))
                }
                else{
                    throw "nodePart has variable in the middle - not allowed"
                }
            }
            return tmp
        }else{
            return this
        }
    }

    public equals(other:DOMNodeRepresentative):boolean{
        if(other instanceof  DOMNode){
            if(this.nodePartList.length !== other.nodePartList.length){
                return false
            }

            for(let i = 0; i < this.nodePartList.length; ++i){
                if(!this.nodePartList[i].equals(other.nodePartList[i])){
                    return false
                }
            }
            return true
        }
        if(other instanceof DOMNodePointer){
            return other.hasNodeEqualTo(this)
        }
        return false
    }

    public getSharedXpath(other:DOMNodeRepresentative):DOMNode[]{
        if(other instanceof DOMNode){
            if(this.equals(other)){
                return [this]
            }
        }
        if(other instanceof DOMNodePointer){
            return other.getSharedXpath(this)
        }
        return []
    }

    public onlyDiffInOneOffset(other:DOMNodeRepresentative):boolean{
        if(other instanceof DOMNode){
            let hasDetectedDiffInOneOffset = false
            if(other.nodePartList.length !== this.nodePartList.length){
                return false
            }
            for(let i = 0; i < this.nodePartList.length; ++i){
                let thisNode = this.nodePartList[i]
                let otherNode = other.nodePartList[i]
                if(thisNode instanceof DOMNodePartPredicate){
                    if(otherNode instanceof DOMNodePartPredicate){
                        if(thisNode.index <= 0 || otherNode.index <= 0){
                            continue
                        }
                        if(thisNode.predicate.equals(otherNode.predicate)){
                            if(otherNode.index - thisNode.index === 1){
                                if(hasDetectedDiffInOneOffset){
                                    return false
                                }
                                hasDetectedDiffInOneOffset = true
                                continue
                            }
                            else if(otherNode.index === thisNode.index){
                                continue
                            }
                            return false
                        }else{
                            return false
                        }

                    }
                    if(otherNode instanceof DOMNodePartVar){
                        return false
                    }
                }
                if(this.nodePartList[i] instanceof DOMNodePartVar){
                    if(otherNode instanceof DOMNodePartPredicate){
                        return false
                    }
                    if(otherNode instanceof DOMNodePartVar){
                        continue
                    }
                }
            }
            return hasDetectedDiffInOneOffset
        }
        if(other instanceof DOMNodePointer){
            return other.hasNodeDiffInOneIndex(this)
        }
        return false
    }

    public toString(){
        let result:string = ""
        for(let nodePart of this.nodePartList){
            if(nodePart instanceof DOMNodePartVar){
                result += nodePart.toString()
            }
            if(nodePart instanceof DOMNodePartPredicate){
                if(nodePart.searchType === PredicateSearchType.Child){
                    result += "/"
                }
                if(nodePart.searchType === PredicateSearchType.Descendant){
                    result += "//"
                }
                result += nodePart.predicate.toString() + (nodePart.index === 0? "" : ("[" + nodePart.index + "]"))
            }
        }
        return result
    }


}



export class DOMNodes{
    public parentNode:DOMNode
    public predicate:Predicate
    public searchType:PredicateSearchType
    public curIndex:number = 0

    constructor(parentNode:DOMNode, predicate:Predicate, searchType:PredicateSearchType, curIndex:number = 0) {
        this.parentNode = parentNode
        this.predicate = predicate
        this.searchType = searchType
        this.curIndex = curIndex
    }

    public next(env:ExecEnvironment):[DOMNode, DOMNodes]{
        let returnDOMNode = DOMNode.constructForCollection(this.parentNode.evaluateToDOMNodeWithoutVariable(env), this.searchType, this.predicate, this.curIndex+1)
        let returnDOMNodes = new DOMNodes(this.parentNode.evaluateToDOMNodeWithoutVariable(env),this.predicate, this.searchType, this.curIndex+1)
        return [returnDOMNode, returnDOMNodes]
    }

    public equals(other:DOMNodes):boolean{
        return this.parentNode.equals(other.parentNode) && this.predicate.equals(other.predicate) && this.searchType === other.searchType
    }

    toString(){
        if(this.searchType === PredicateSearchType.Child){
            return "Children(" + this.parentNode.toString()+", " + this.predicate.toString()+")"
        }
        if(this.searchType === PredicateSearchType.Descendant){
            return "Descendants(" + this.parentNode.toString()+", " + this.predicate.toString()+")"
        }
    }

}
export abstract class DOMNodePart{
    public abstract equals(other:DOMNodePart):boolean
}
export class DOMNodePartPredicate extends DOMNodePart{
    public searchType:PredicateSearchType
    public index:number = 0
    public predicate:Predicate

    constructor(searchType:PredicateSearchType, index:number, predicate:Predicate) {
        super();
        this.searchType = searchType
        this.index = index
        this.predicate = predicate
    }

    public static constructFromString(str:string,searchType:PredicateSearchType):DOMNodePartPredicate{
        //there are following kinds of DOMNodePartPredicate:
        //p -- case I
        //p[1] -- case II
        //p[@attribute=name] -- case III
        //p[@attribute=name][2] -- case IV

        let firstBracketLeftDividerIndex = str.indexOf("[")
        let firstBracketRightDividerIndex = str.indexOf("]")
        let secondBracketLeftDividerIndex = str.lastIndexOf("[")
        let secondBracketRightDividerIndex = str.lastIndexOf("]")

        if(firstBracketLeftDividerIndex === -1){
            //case I
            return new DOMNodePartPredicate(searchType,0,new PredicateConst(str, "", ""))
        }
        if(firstBracketLeftDividerIndex !== -1 && secondBracketLeftDividerIndex !== -1 && firstBracketLeftDividerIndex !== secondBracketLeftDividerIndex){
            //case IV
            let equalSignDividerIndex = str.indexOf("=")
            let tagName = str.substring(0,firstBracketLeftDividerIndex)
            let predicateName = str.substring(firstBracketLeftDividerIndex+1,equalSignDividerIndex)
            let predicateValue = str.substring(equalSignDividerIndex+1,firstBracketRightDividerIndex)
            let index = parseInt(str.substring(secondBracketLeftDividerIndex+1,secondBracketRightDividerIndex))
            return new DOMNodePartPredicate(searchType, index,new PredicateConst(tagName, predicateName, predicateValue))
        }
        if(firstBracketLeftDividerIndex !== -1 && firstBracketLeftDividerIndex === secondBracketLeftDividerIndex){
            let tagName = str.substring(0,firstBracketLeftDividerIndex)
            let numberToParse = parseInt(str.substring(firstBracketLeftDividerIndex+1,firstBracketRightDividerIndex))
            if(Number.isNaN(numberToParse)){
                //case III
                let equalSignDividerIndex = str.indexOf("=")
                let predicateName = str.substring(firstBracketLeftDividerIndex+1,equalSignDividerIndex)
                let predicateValue = str.substring(equalSignDividerIndex+1,firstBracketRightDividerIndex)
                let index = 0
                return new DOMNodePartPredicate(searchType, index,new PredicateConst(tagName, predicateName, predicateValue))
            }
            else{
                //case II
                return new DOMNodePartPredicate(searchType, numberToParse,new PredicateConst(tagName, "", ""))
            }
        }
        throw "shouldn't reach here"
    }

    public static constructFromStringWithSearchType(str:string):DOMNodePartPredicate
    {
        if(str.length < 2){
            throw "Shouldn't reach here - too short to construct. Trying to construct DOMNodePart with string " + str
        }

        if(str[1] !== '/'){
            return DOMNodePartPredicate.constructFromString(str.substring(1),PredicateSearchType.Child)
        }
        if(str[1] === '/'){
            return DOMNodePartPredicate.constructFromString(str.substring(2),PredicateSearchType.Descendant)
        }

        throw "Shouldn't reach here - should covered all cases"

    }
    public equals(other: DOMNodePart): boolean {
        if(other instanceof DOMNodePartPredicate)
        {
            return this.searchType === other.searchType && (this.index === other.index || (this.index === 0 && other.index === 1) || (this.index === 1 && other.index === 0)) && this.predicate.equals(other.predicate)
        }
        return false
    }

    public evaluateToDOMNodePartWithoutVariable(env: ExecEnvironment): DOMNodePartPredicate {
        if(this.predicate instanceof PredicateVar){
            return new DOMNodePartPredicate(this.searchType, this.index,this.predicate.evaluateToPredicateWithoutVariable(env))
        }
        else{
            return this
        }
    }

    public toString(){
        let result = ""
        if(this.searchType === PredicateSearchType.Child){
            result += "/"
        }
        if(this.searchType === PredicateSearchType.Descendant){
            result += "//"
        }
        result += this.predicate.toString() + (this.index === 0? "" : ("[" + this.index + "]"))
        return result
    }
}
export class DOMNodePartVar extends DOMNodePart{
    public readonly variable:Variable

    constructor(variable:Variable) {
        super();
        this.variable = variable
    }
    public evaluateVariable(env:ExecEnvironment):DOMNode{
        return env.load(this.variable)
    }

    public equals(other: DOMNodePart): boolean {
        return other instanceof DOMNodePartVar && this.variable.equals(other.variable)
    }
    public evaluateToDOMNodeWithoutVariable(env: ExecEnvironment): DOMNode {
        let loaded =  env.load(this.variable)
        if(loaded instanceof DOMNode){
            return loaded
        }
        throw "Unknown DOM Part variable type"
    }

    public static newVariableNode():DOMNodePartVar{
        return new DOMNodePartVar(new Variable())
    }

    toString(){
        return "<"+this.variable.toString() + ">"
    }

}
export abstract class Predicate {
    public tagName: string
    public attributeName: string = ""

    public abstract getAttributeValue(env?: ExecEnvironment): string|InputPath

    protected constructor(tagName: string, attributeName: string) {
        this.tagName = tagName
        this.attributeName = attributeName
    }

    public abstract equals(other: Predicate): boolean
}
export class PredicateConst extends Predicate{
    public readonly _attributeValue:string|InputPath = ""

    constructor(tagName:string, attributeName:string, attributeValue:string|InputPath) {
        super(tagName, attributeName)
        this._attributeValue = attributeValue
    }
    public getAttributeValue():string|InputPath{
        return this._attributeValue
    }
    public equals(other: Predicate): boolean {
        return other instanceof PredicateConst && this.tagName === other.tagName &&
            this.attributeName === other.attributeName && this._attributeValue.toString() === other._attributeValue.toString()
    }

    public toString(){
        if(this.attributeName === ""){
            return this.tagName
        }
        else{
            return this.tagName + "[" + this.attributeName + "=" + this._attributeValue.toString() + "]"
        }
    }
}
export class PredicateVar extends Predicate{
    public _attributeValue:Variable

    constructor(tagName:string, attributeName:string, attributeValue:Variable) {
        super(tagName, attributeName)
        this._attributeValue = attributeValue
    }
    public getAttributeValue(env:ExecEnvironment):string|InputPath{
        let attributeValue = env.load(this._attributeValue)
        if(attributeValue instanceof InputPath){
            return attributeValue.evaluateToInputUnitWithoutVariable(env)
        }
        else{
            return attributeValue.toString()
        }
    }

    public equals(other: Predicate): boolean {
        return other instanceof PredicateVar && this._attributeValue.equals(other._attributeValue)
    }

    public toString(){
        return this.tagName + "[" + this.attributeName + "=" + this._attributeValue.toString() + "]"
    }

    public evaluateToPredicateWithoutVariable(env:ExecEnvironment):PredicateConst{
        let constValue =  env.load(this._attributeValue)
        if(typeof constValue === "string" || constValue instanceof InputPath){
            return new PredicateConst(this.tagName, this.attributeName, constValue)
        }
        throw "Unknown predicate attribute Value."
    }

}

/* Input related classes */
export class InputJSON{
    public readonly inputJSON:{ [index: string]: any } = {}


    constructor(data:{ [index: string]: any }){
        this.inputJSON = data
    }

    public valid(path:InputPath):boolean{
        return JSONPersistentVerifier.valid(this,path)
    }

    public __valid(path:InputPath){
        let curPos = this.inputJSON
        for(let node of path.nodes)
        {
            if(!curPos.hasOwnProperty(node.name)){
                return false
            }
            if(node.hasIndex){
                let tmp = curPos[node.name][node.index]
                if(tmp === undefined){
                    return false
                }
                curPos = tmp
            }
            else
            {
                curPos = curPos[node.name]
            }
        }
        return true
    }

    public load(path:InputPath){
        let curPos = this.inputJSON
        for(let node of path.nodes)
        {
            if(!curPos.hasOwnProperty(node.name)){
                throw "Can't load from " + path.toString()
            }
            if(node.hasIndex){
                let tmp = curPos[node.name][node.index]
                if(tmp === undefined){
                    throw "Can't load from " + path.toString()
                }
                curPos = tmp
            }
            else
            {
                curPos = curPos[node.name]
            }
        }
        return curPos
    }
}
export class InputPathNode{
    public name:string = ""
    public hasIndex:boolean = false
    public index:number = 0
    public isVar:boolean = false
    public variable:Variable = new Variable()

    constructor(name:string = "", hasIndex:boolean = false, index:number = 0) {
        this.name = name
        this.hasIndex = hasIndex
        this.index = index

    }

    public static fromString(nodeText:string):InputPathNode{
        let indexStartPos = nodeText.indexOf("[")
        let indexEndPos = nodeText.indexOf("]")
        if(indexStartPos !== -1){
            return new InputPathNode(nodeText.substring(0, indexStartPos), true, parseInt(nodeText.substring(indexStartPos+1, indexEndPos)))
        }
        else
        {
            return new InputPathNode(nodeText, false)
        }
    }
    public static createVarNode(variable:Variable):InputPathNode{
        let tmp:InputPathNode = new InputPathNode()
        tmp.isVar = true
        tmp.variable = variable
        return tmp
    }

    public equals(other:InputPathNode):boolean{
        if(this.isVar)
        {
            return this.variable!.getID === other.variable!.getID
        }
        if(this.hasIndex){
            return this.name === other.name && this.index === other.index
        }
        return this.name === other.name
    }

    public toString(){
        if(this.isVar){
            return "<"+this.variable!.toString()+">"
        }
        if(this.hasIndex){
            return this.name+"["+this.index+"]"
        }
        return this.name
    }
    public static newVariableNode():InputPathNode{
        let tmp = new InputPathNode()
        tmp.variable = new Variable(true)
        tmp.isVar = true
        return tmp
    }

    public evaluateVariable(env:ExecEnvironment):InputPath{
        return env.load(this.variable!)
    }

    public alphaEquiv(other:InputPathNode):boolean{
        if(this.isVar){
            return other.isVar;
        }else{
            return this.equals(other)
        }
    }

}
export class InputPath {
    public nodeList:InputPathNode[] = []

    constructor(inputPath?:string) {
        if(inputPath !== undefined)
        {
            this.initFromString(inputPath)
        }
    }

    public onlyDiffInOneOffset(other:InputPath):boolean{
        let hasDetectedDiffInOneOffset = false
        if(other.nodeList.length !== this.nodeList.length){
            return false
        }
        for(let i = 0; i < this.nodeList.length; ++i){
            let thisNode = this.nodeList[i]
            let otherNode = other.nodeList[i]
            if(!thisNode.isVar){
                if(!otherNode.isVar){
                    if(!thisNode.hasIndex || !otherNode.hasIndex){
                        continue
                    }
                    if(thisNode.name === otherNode.name){
                        if(otherNode.index - thisNode.index === 1){
                            if(hasDetectedDiffInOneOffset){
                                return false
                            }
                            hasDetectedDiffInOneOffset = true
                            continue
                        }
                        else if(otherNode.index === thisNode.index){
                            continue
                        }
                        return false
                    }else{
                        return false
                    }

                }
                if(otherNode instanceof DOMNodePartVar){
                    return false
                }
            }else{
                if(this.nodeList[i] instanceof DOMNodePartVar) {
                    if (otherNode instanceof DOMNodePartPredicate) {
                        return false
                    }
                    if (otherNode instanceof DOMNodePartVar) {
                        continue
                    }
                }
            }
        }
        return hasDetectedDiffInOneOffset
    }

    public equals(other: InputPath):boolean {
        if (this.nodeList.length !== other.nodeList.length) {
            return false
        }

        for (let i = 0; i < this.nodeList.length; ++i) {
            if (!this.nodeList[i].equals(other.nodeList[i])) {
                return false
            }
        }
        return true

    }

    public toString(){
        return this.nodeList.join(".")
    }

    public evaluateToInputUnitWithoutVariable(env: ExecEnvironment): InputPath {
        if(this.nodeList.length === 0){
            return this
        }
        if(!this.nodeList[0].isVar){
            return this
        }
        else
        {
            let tmp = new InputPath()
            tmp.nodeList = this.nodeList[0].evaluateVariable(env).evaluateToInputUnitWithoutVariable(env).nodeList.slice().concat(this.nodeList.slice(1))
            return tmp
        }
    }

    public static constructFromOtherInputPath(other:InputPath, start:number, end:number):InputPath{
        let tmp = new InputPath()
        for(let i = start;i < end; ++i){
            tmp.nodeList.push(other.nodeList[i])
        }
        return tmp
    }

    public static constructForCollection(root:InputPath, nodeName:string, index:number): InputPath{
        let tmp = new InputPath()
        tmp.nodeList = root.nodeList.slice()
        tmp.nodeList.push(new InputPathNode(nodeName, true, index))
        return tmp
    }

    get nodes(){
        return this.nodeList
    }


    public initFromString(inputPath:string){
        let splitArray = inputPath.split(".")
        if(splitArray[0] === "")
        {
            splitArray.shift()
        }
        for(let nodeString of splitArray){
            let tmp = InputPathNode.fromString(nodeString)
            this.nodeList.push(tmp)
        }
    }

    public alphaEquiv(other:InputPath):boolean{
        if(this.nodeList.length !== other.nodeList.length){
            return false
        }
        for(let i = 0; i < this.nodeList.length; ++i){
            if(!this.nodeList[i].alphaEquiv(other.nodeList[i])){
                return false
            }
        }
        return true
    }
}
export class InputCollection{
    public parentNode:InputPath
    public currentNode:InputPathNode
    public curIndex:number = -1

    constructor(parentNode:InputPath, currentNode:InputPathNode, curIndex:number = -1) {
        this.parentNode = parentNode
        this.currentNode = currentNode
        this.curIndex = curIndex
    }

    public next(env:ExecEnvironment):[InputPath, InputCollection]{
        let returnInputPath = InputPath.constructForCollection(this.parentNode.evaluateToInputUnitWithoutVariable(env), this.currentNode.name, this.curIndex+1)
        let returnInputCollection = new InputCollection(this.parentNode.evaluateToInputUnitWithoutVariable(env), this.currentNode, this.curIndex+1)
        return [returnInputPath, returnInputCollection]
    }

    public equals(other:InputCollection):boolean{
        return this.parentNode.equals(other.parentNode) && this.currentNode.name === other.currentNode.name
    }

    toString(){
        return "GetArray(" +this.parentNode.toString() + "." + this.currentNode.name +  ")"
    }

}

/* Util classes */
export abstract class UniqueRealIDGenerator{
    public static curID = 0
    public static getNewId():number{
        UniqueRealIDGenerator.curID = UniqueRealIDGenerator.curID + 1
        return this.curID
    }
}
export abstract class UniqueIDGenerator{
    public static curID = 1
    public static getNewId():number{
        return this.curID
    }
    public static getNewInputId():number{
        return this.curID+1
    }
}
export abstract class UniqueVariableNameGenerator{
    public static curID = 1
    public static getNewName():string{
        return "v"+this.curID
    }
    public static getNewInputName():string{
        return "v"+(this.curID+1)
    }
}
export abstract class AlphaEquivVarPrinter{
    public static curIDList: number[] = []

    public static fresh(){AlphaEquivVarPrinter.curIDList = []}

    public static print(variable:Variable):string{
        let index = AlphaEquivVarPrinter.curIDList.indexOf(variable!.getID)
        if(index > -1){
            return "v" + index
        }
        else{
            AlphaEquivVarPrinter.curIDList.push(variable.getID)
            return "v" + (AlphaEquivVarPrinter.curIDList.length-1)
        }
    }
}

/* Optimizing classes*/
export class DOMPersistentVerifier{
    public static validateMap:Map<string,boolean> = new Map<string, boolean>()
    public static totalTime:number = 0
    public static valid(DOM:DOMState, DOMNode:DOMNode):boolean{
        DOMPersistentVerifier.totalTime = DOMPersistentVerifier.totalTime + 1
        let queryString = DOM.id + ":" + DOMNode.toString()
        let result = DOMPersistentVerifier.validateMap.get(queryString)
        if(result === undefined){
            let start = new Date()
            let verifyResult = DOM.__valid(DOMNode)
            let end = new Date()
            DOMPersistentVerifier.validateMap.set(queryString, verifyResult)

            if(verifyResult){
                console.log("evaluating xpath " + queryString + " -- from scratch:True. Time consumed: " + (end.getTime()-start.getTime()) + " ms")
            }
            else{
                console.log("evaluating xpath " + queryString + " -- from scratch:False. Time consumed: " + (end.getTime()-start.getTime()) + " ms")
            }

            return verifyResult
        }
        else{
            if(DEBUG.on){
                if(result){
                    console.log("evaluating xpath " + queryString + " -- from cache:True")
                }
                else{
                    console.log("evaluating xpath " + queryString + " -- from cache:False")
                }
            }
            return result
        }
    }

    public static addConfirmedElement(id:number, DOMNode:DOMNode){
        let queryString = id + ":" + DOMNode.toString()
        DOMPersistentVerifier.validateMap.set(queryString,true)
    }

    public static initCache(actions:Action[], doms:DOMState[]){
        for(let i = 0; i < actions.length; ++i){
            let tmpAction = actions[i]
            let id = doms[i].id
            if(tmpAction instanceof ActionWithTarget){
                let tmpTarget = tmpAction.target
                if(tmpTarget instanceof DOMNodePointer)
                {
                    let nodeSet:DOMNode[] = tmpTarget.getNodeSet()
                    for(let n of nodeSet) {
                        DOMPersistentVerifier.addConfirmedElement(id,n)
                    }
                }
            }
        }
    }

    public static print(){
        console.log("Total time: " + DOMPersistentVerifier.totalTime)
        console.log(DOMPersistentVerifier.validateMap)
    }

    public static clear(){DOMPersistentVerifier.validateMap = new Map<string, boolean>()}
}
class JSONPersistentVerifier{
    public static validateMap:Map<string,boolean> = new Map<string, boolean>()

    public static valid(input:InputJSON, inputPath:InputPath):boolean{
        let queryString =  inputPath.toString()
        let result = JSONPersistentVerifier.validateMap.get(queryString)
        if(result === undefined){
            let verifyResult = input.__valid(inputPath)
            JSONPersistentVerifier.validateMap.set(queryString, verifyResult)
            return verifyResult
        }
        else{
            return result
        }
    }
}
export class NoRepeatWorkListArray {
    private array:RewriteWorklistUnit[] = []
    private map:Map<string,boolean>
    constructor() {
        this.array = []
        this.map = new Map()
    }

    get(index:number):RewriteWorklistUnit{
        return this.array[index]
    }

    push(item:RewriteWorklistUnit) {
        let str = programToString(item.program)
        if(this.map.has(str)){
            return
        }
        this.map.set(str, true);
        this.array.push(item)
    }

    values():RewriteWorklistUnit[] {
        return this.array
    }

    concat(other:NoRepeatWorkListArray){
        let tmpArray:RewriteWorklistUnit[] = other.array
        for(let a of tmpArray){
            this.push(a)
        }
    }

    get length(){
        return this.array.length
    }

    shift():RewriteWorklistUnit{
        let tmp = this.array.shift()
        if(tmp){
            return tmp
        }
        else{
            throw "Error NonRepeatArray - shift with empty"
        }
    }

    sort(func:any){
        this.array.sort(func)
    }
}
export class NoRepeatActionArray {
    private array:Action[] = []
    private map:Map<string,boolean>
    constructor() {
        this.array = []
        this.map = new Map()
    }

    get(index:number):Action{
        return this.array[index]
    }

    push(item:Action) {
        let str = item.toString()
        if(this.map.has(str)){
            return
        }
        this.map.set(str, true);
        this.array.push(item)
    }

    values() {
        return this.array
    }

    get length(){
        return this.array.length
    }
}

export enum ForLoopCheckValidResult{
    Valid,
    NotValid,
    PredictionExistNoNestedLoopInTheEnd,
    PredictionExistNestedLoopInTheEnd,
    NotDecided
}



