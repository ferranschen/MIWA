import {
    Click,
    DOMNode,
    DOMNodePartVar, DOMNodePointer, DOMNodeRepresentative,
    DOMNodes,
    Download,
    ExtractURL, ForEachDOMNodes, ForEachInput,
    GoBack, InputPath, InputPathNode,
    ScrapeLink,
    ScrapeText, SendData,
    SendKeys,
    Statement,
    Variable, WhileLoopWithClick
} from "./DSL";
import {SELECTORSYN} from "./algorithms";


function getParameterizedDomNode(variable: Variable, headToBeParameterized: DOMNode, domNode: DOMNode, consultDOMNode: DOMNodeRepresentative): DOMNode | null {
    if(!domNode.onlyDiffInOneOffset(consultDOMNode)){
        return null
    }

    if(headToBeParameterized.nodePartList.length > domNode.nodePartList.length){
        return null
    }

    for (let i = 0; i < headToBeParameterized.nodePartList.length; ++i) {
        if (!headToBeParameterized.nodePartList[i].equals(domNode.nodePartList[i])) {
            return null
        }
    }
    let result: DOMNode = DOMNode.constructFromOtherDOMNode(domNode, headToBeParameterized.nodePartList.length, domNode.nodePartList.length)
    result.nodePartList.unshift(new DOMNodePartVar(variable))
    return result
}

function getParameterizedInputPath(variable: Variable, headToBeParameterized: InputPath, inputPath: InputPath, consultInputPath: InputPath): InputPath | null {
    if(!inputPath.onlyDiffInOneOffset(consultInputPath)){
        return null
    }
    if(headToBeParameterized.nodeList.length > inputPath.nodeList.length){
        return null
    }

    for (let i = 0; i < headToBeParameterized.nodeList.length; ++i) {
        if (!headToBeParameterized.nodeList[i].equals(inputPath.nodeList[i])) {
            return null
        }
    }
    let result: InputPath = InputPath.constructFromOtherInputPath(inputPath, headToBeParameterized.nodeList.length, inputPath.nodeList.length)
    result.nodeList.unshift(InputPathNode.createVarNode(variable))
    return result
}

export class Parameterizer {
    public static parameterizeStatementForDOMNode(statement: Statement, variable: Variable, domNode: DOMNode, consultingStatement:Statement): Statement[] {
        if (statement instanceof Click) {
            //if consulting action is not the same as the parameterized statement, then return [] since it will not be able to parameterize.
            if(!(consultingStatement instanceof Click)){
                return []
            }
            if(statement.target instanceof DOMNode){
                //if this is equal to the consulting statement, then it should be const - add it to the result and return
                if(statement.target.equals(consultingStatement.target)){
                    return [statement]
                }
                let result = []
                let parameterizedDomNode = getParameterizedDomNode(variable, domNode, statement.target, consultingStatement.target)
                if (parameterizedDomNode) {
                    result.push(new Click(parameterizedDomNode))
                }
                return result
            }
            if(statement.target instanceof DOMNodePointer){
                let DOMNodeSet = statement.target.getNodeSet()
                let result = []
                for(let d of DOMNodeSet){
                    //if it is equals to the target, then keep this constant
                    if(d.equals(consultingStatement.target)){
                        result.push(new Click(d))
                        if(result.length >= SELECTORSYN.numConst){
                            return result
                        }
                        continue
                    }else {
                        //otherwise see if it can unify to a variable
                        let parameterizedDomNode = getParameterizedDomNode(variable, domNode, d, consultingStatement.target)
                        if (parameterizedDomNode) {
                            result.push(new Click(parameterizedDomNode))
                        }
                    }
                }
                return result
            }
        }
        if (statement instanceof SendKeys) {
            //if consulting action is not the same as the parameterized statement, then return [] since it will not be able to parameterize.
            if(!(consultingStatement instanceof SendKeys)){
                return []
            }
            if(statement.target instanceof DOMNode){
                //if this is equal to the consulting statement, then it should be const - add it to the result and return
                if(statement.target.equals(consultingStatement.target)){
                    return [statement]
                }
                let result = []
                let parameterizedDomNode = getParameterizedDomNode(variable, domNode, statement.target, consultingStatement.target)
                if (parameterizedDomNode) {
                    result.push(new SendKeys(parameterizedDomNode, statement.keysText))
                }
                return result
            }
            if(statement.target instanceof DOMNodePointer){
                let DOMNodeSet = statement.target.getNodeSet()
                let result = []
                for(let d of DOMNodeSet){
                    //if it is equals to the target, then keep this constant
                    if(d.equals(consultingStatement.target)){
                        result.push(new SendKeys(d, statement.keysText))
                        if(result.length >= SELECTORSYN.numConst){
                            return result
                        }
                        continue
                    }else {
                        //otherwise see if it can unify to a variable
                        let parameterizedDomNode = getParameterizedDomNode(variable, domNode, d, consultingStatement.target)
                        if (parameterizedDomNode) {
                            result.push(new SendKeys(parameterizedDomNode, statement.keysText))
                        }
                    }
                }
                return result
            }
        }
        if (statement instanceof ScrapeText) {
            //if consulting action is not the same as the parameterized statement, then return [] since it will not be able to parameterize.
            if(!(consultingStatement instanceof ScrapeText)){
                return []
            }
            if(statement.target instanceof DOMNode){
                //if this is equal to the consulting statement, then it should be const - add it to the result and return
                if(statement.target.equals(consultingStatement.target)){
                    return [statement]
                }
                let result = []
                let parameterizedDomNode = getParameterizedDomNode(variable, domNode, statement.target, consultingStatement.target)
                if (parameterizedDomNode) {
                    result.push(new ScrapeText(parameterizedDomNode))
                }
                return result
            }
            if(statement.target instanceof DOMNodePointer){
                let DOMNodeSet = statement.target.getNodeSet()
                let result = []
                for(let d of DOMNodeSet){
                    //if it is equals to the target, then keep this constant
                    if(d.equals(consultingStatement.target)){
                        result.push(new ScrapeText(d))
                        if(result.length >= SELECTORSYN.numConst){
                            return result
                        }
                        continue
                    }else {
                        //otherwise see if it can unify to a variable
                        let parameterizedDomNode = getParameterizedDomNode(variable, domNode, d, consultingStatement.target)
                        if (parameterizedDomNode) {
                            result.push(new ScrapeText(parameterizedDomNode))
                        }
                    }
                }
                return result
            }
        }
        if (statement instanceof ScrapeLink) {
            //if consulting action is not the same as the parameterized statement, then return [] since it will not be able to parameterize.
            if(!(consultingStatement instanceof ScrapeLink)){
                return []
            }
            if(statement.target instanceof DOMNode){
                //if this is equal to the consulting statement, then it should be const - add it to the result and return
                if(statement.target.equals(consultingStatement.target)){
                    return [statement]
                }
                let result = []
                let parameterizedDomNode = getParameterizedDomNode(variable, domNode, statement.target, consultingStatement.target)
                if (parameterizedDomNode) {
                    result.push(new ScrapeLink(parameterizedDomNode))
                }
                return result
            }
            if(statement.target instanceof DOMNodePointer){
                let DOMNodeSet = statement.target.getNodeSet()
                let result = []
                for(let d of DOMNodeSet){
                    //if it is equals to the target, then keep this constant
                    if(d.equals(consultingStatement.target)){
                        result.push(new ScrapeLink(d))
                        if(result.length >= SELECTORSYN.numConst){
                            return result
                        }
                        continue
                    }else {
                        //otherwise see if it can unify to a variable
                        let parameterizedDomNode = getParameterizedDomNode(variable, domNode, d, consultingStatement.target)
                        if (parameterizedDomNode) {
                            result.push(new ScrapeLink(parameterizedDomNode))
                        }
                    }
                }
                return result
            }
        }
        if (statement instanceof Download) {
            //if consulting action is not the same as the parameterized statement, then return [] since it will not be able to parameterize.
            if(!(consultingStatement instanceof Download)){
                return []
            }
            if(statement.target instanceof DOMNode){
                //if this is equal to the consulting statement, then it should be const - add it to the result and return
                if(statement.target.equals(consultingStatement.target)){
                    return [statement]
                }
                let result = []
                let parameterizedDomNode = getParameterizedDomNode(variable, domNode, statement.target, consultingStatement.target)
                if (parameterizedDomNode) {
                    result.push(new Download(parameterizedDomNode))
                }
                return result
            }
            if(statement.target instanceof DOMNodePointer){
                let DOMNodeSet = statement.target.getNodeSet()
                let result = []
                for(let d of DOMNodeSet){
                    //if it is equals to the target, then keep this constant
                    if(d.equals(consultingStatement.target)){
                        result.push(new Download(d))
                        if(result.length >= SELECTORSYN.numConst){
                            return result
                        }
                        continue
                    }else {
                        //otherwise see if it can unify to a variable
                        let parameterizedDomNode = getParameterizedDomNode(variable, domNode, d, consultingStatement.target)
                        if (parameterizedDomNode) {
                            result.push(new Download(parameterizedDomNode))
                        }
                    }
                }
                return result
            }
        }
        if (statement instanceof GoBack) {
            if(consultingStatement instanceof GoBack){
                return [statement]
            }
            else{
                return []
            }

        }
        if (statement instanceof ExtractURL) {
            if(consultingStatement instanceof ExtractURL){
                return [statement]
            }
            else{
                return []
            }
        }
        if(statement instanceof ForEachDOMNodes){
            if(!(consultingStatement instanceof ForEachDOMNodes)){
                return []
            }
            let result:Statement[] = []
            let parameterizedCollection = Parameterizer.parameterizeCollection(statement.domNodes, variable, domNode, statement.domNodes)
            for(let c of parameterizedCollection){
                result.push(new ForEachDOMNodes(statement.iteratingVariable, c, statement.loopBody))
            }
            return result
        }
        if(statement instanceof SendData){
            if(consultingStatement instanceof SendData){
                if(!statement.dataPath.equals(consultingStatement.dataPath)){
                    return []
                }
                let sharedXpath = statement.target.getSharedXpath(consultingStatement.target)
                let result = []
                let limit = 0
                for(let s of sharedXpath){
                    result.push(new SendData(s, statement.dataPath))
                    limit = limit + 1
                    if(limit >= SELECTORSYN.numConst){
                        break
                    }
                }
                return result
            }
            return []
        }
        if(statement instanceof ForEachInput){
            if(consultingStatement instanceof ForEachInput){
                if(statement.equals(consultingStatement))
                {
                    return [statement]
                }
                else{
                    return []
                }
            }
            return []
        }

        if(statement instanceof WhileLoopWithClick){
            if(consultingStatement instanceof WhileLoopWithClick){
                if(statement.equals(consultingStatement))
                {
                    return [statement]
                }
                else{
                    return []
                }
            }
            return []
        }
        throw "Parameterizer for DOMNode: No matching rule for parameterizer: " + statement.toString()

    }
    public static parameterizeStatementForInputNode(statement: Statement, variable: Variable, inputPath: InputPath, consultingStatement:Statement): Statement[] {
        if (statement instanceof SendData) {
            //if consulting action is not the same as the parameterized statement, then return [] since it will not be able to parameterize.
            if(!(consultingStatement instanceof SendData)){
                return []
            }
            if(!statement.target.equals(consultingStatement.target)){
                return []
            }
            let sharedXpath:DOMNode[] = statement.target.getSharedXpath(consultingStatement.target)

            let result = []
            let parameterizedInputPath = getParameterizedInputPath(variable, inputPath, statement.dataPath, consultingStatement.dataPath)
            if (parameterizedInputPath) {
                let limit = 0
                for(let s of sharedXpath){
                    result.push(new SendData(s,parameterizedInputPath))
                    limit = limit + 1
                    if(limit >= SELECTORSYN.numConst){
                        break
                    }
                }
            }
            return result
        }
        if(statement instanceof Click){
            if(consultingStatement instanceof Click){
                let sharedXpath = statement.target.getSharedXpath(consultingStatement.target)
                let result = []
                let limit = 0
                for(let s of sharedXpath){
                    result.push(new Click(s))
                    limit = limit + 1
                    if(limit >= SELECTORSYN.numConst){
                        break
                    }
                }
                return result
            }
            return []
        }
        if(statement instanceof SendKeys){
            if(consultingStatement instanceof SendKeys){
                if(statement.keysText !== consultingStatement.keysText){
                    return []
                }
                let sharedXpath = statement.target.getSharedXpath(consultingStatement.target)
                let result = []
                let limit = 0
                for(let s of sharedXpath){
                    result.push(new SendKeys(s, statement.keysText))
                    limit = limit + 1
                    if(limit >= SELECTORSYN.numConst){
                        break
                    }
                }
                return result
            }
            return []
        }

        if(statement instanceof ScrapeText){
            if(consultingStatement instanceof ScrapeText){
                let sharedXpath = statement.target.getSharedXpath(consultingStatement.target)
                let result = []
                let limit = 0
                for(let s of sharedXpath){
                    result.push(new ScrapeText(s))
                    limit = limit + 1
                    if(limit >= SELECTORSYN.numConst){
                        break
                    }
                }
                return result
            }
            return []
        }

        if(statement instanceof ScrapeLink){
            if(consultingStatement instanceof ScrapeLink){
                let sharedXpath = statement.target.getSharedXpath(consultingStatement.target)
                let result = []
                let limit = 0
                for(let s of sharedXpath){
                    result.push(new ScrapeLink(s))
                    limit = limit + 1
                    if(limit >= SELECTORSYN.numConst){
                        break
                    }
                }
                return result
            }
            return []
        }

        if(statement instanceof Download){
            if(consultingStatement instanceof Download){
                let sharedXpath = statement.target.getSharedXpath(consultingStatement.target)
                let result = []
                let limit = 0
                for(let s of sharedXpath){
                    result.push(new Download(s))
                    limit = limit + 1
                    if(limit >= SELECTORSYN.numConst){
                        break
                    }
                }
                return result
            }
            return []
        }

        if(statement instanceof ExtractURL){
            if(consultingStatement instanceof ExtractURL){
                let result = []
                result.push(new ExtractURL())
                return result
            }
            return []
        }

        if(statement instanceof GoBack){
            if(consultingStatement instanceof GoBack){
                let result = []
                result.push(new GoBack())
                return result
            }
            return []
        }

        if(statement instanceof ForEachDOMNodes){
            if(consultingStatement instanceof ForEachDOMNodes){
                if(statement.equals(consultingStatement))
                {
                    return [statement]
                }
                else{
                    return []
                }
            }
            return []
        }
        if(statement instanceof ForEachInput){
            if(consultingStatement instanceof ForEachInput){
                if(statement.equals(consultingStatement))
                {
                    return [statement]
                }
                else{
                    return []
                }
            }
            return []
        }
        if(statement instanceof WhileLoopWithClick){
            if(consultingStatement instanceof WhileLoopWithClick){
                if(statement.equals(consultingStatement))
                {
                    return [statement]
                }
                else{
                    return []
                }
            }
            return []
        }



        throw "Parameterizer for input: No matching rule for parameterizer: " + statement.toString()

    }

    public static parameterizeCollection(collection: DOMNodes, variable: Variable, domNode: DOMNode, consultDOMNodes: DOMNodes): DOMNodes[] {
        if(collection.equals(consultDOMNodes)){
            return [collection]
        }
        let result = []
        let parameterizedDomNode = getParameterizedDomNode(variable, domNode, collection.parentNode, consultDOMNodes.parentNode)
        if (parameterizedDomNode) {
            result.push(new DOMNodes(parameterizedDomNode, collection.predicate, collection.searchType))
        }
        return result
    }
}