import {
    Action,
    ActionTrace,
    ActionWithTarget,
    Click,
    DOMNode,
    DOMNodes,
    DOMState,
    DOMStateTrace,
    Download,
    ExecEnvironment,
    ExtractURL,
    ForEachDOMNodes,
    ForEachInput,
    ForLoopCheckValidResult,
    GlobalRunningEnv,
    GoBack,
    InputCollection,
    InputJSON,
    InputPath,
    IterateElement,
    LoopyStatement,
    Program,
    ScrapeLink,
    ScrapeText,
    SendData,
    SendKeys,
    Statement,
    StatementDisplayName,
    WhileLoopWithClick
} from "./DSL";
import {BackendSynthesizer} from "./backendSynthesizer";

/* Interpreter state related class */
export class Bottom {

}
export class RunningState {
    public domStateTrace: DOMStateTrace | Bottom
    public actionTrace: ActionTrace | Bottom
    public environment: ExecEnvironment

    constructor(domStateTrace: DOMStateTrace | Bottom = new Bottom(),
                actionTrace: ActionTrace | Bottom = new Bottom(),
                environment: ExecEnvironment = new ExecEnvironment()) {
        this.domStateTrace = domStateTrace
        this.actionTrace = actionTrace
        this.environment = environment
    }
}

export class ForLoopVerifyStatus {
    public domStateTrace: DOMStateTrace | Bottom
    public actionTrace: ActionTrace | Bottom
    public environment: ExecEnvironment
    public verifyStatus: ForLoopCheckValidResult

    constructor(domStateTrace: DOMStateTrace | Bottom = new Bottom(),
                actionTrace: ActionTrace | Bottom = new Bottom(),
                environment: ExecEnvironment = new ExecEnvironment(),
                verifyStatus: ForLoopCheckValidResult = ForLoopCheckValidResult.NotValid) {
        this.domStateTrace = domStateTrace
        this.actionTrace = actionTrace
        this.environment = environment
        this.verifyStatus = verifyStatus
    }
}

/* Interpreter related functions */
export function domTraceMinus(left:DOMStateTrace|Bottom, right:DOMStateTrace|Bottom):DOMStateTrace|Bottom {
    if(left instanceof Bottom || right instanceof Bottom){
        return new Bottom()
    }
    //if right is empty, then return left
    if(right.empty()){
        return left
    }
    //if left is empty, then return empty
    if(left.empty()){
        return left
    }
    if(right.start === left.start && right.end <= left.end){
        //if right is a prefix of left, then return [right.end+1,left.end]
        return new DOMStateTrace(right.end+1, left.end)
    }
    else if(right.start === left.start && left.end <= right.end){
        //if left if a prefix of right, then return [left.end+1,left.end] -- empty
        return new DOMStateTrace(left.end+1, left.end)
    }
    else{
        return new Bottom()
    }

}
export function actionTraceMinus(left:ActionTrace|Bottom, right:ActionTrace|Bottom):ActionTrace|Bottom {
    if(left instanceof Bottom || right instanceof Bottom){
        return new Bottom()
    }

    //if right is empty, then return left
    if(right.empty()){
        return left
    }
    //if left is empty, then return empty
    if(left.empty()){
        return left
    }
    if(right.start === left.start && right.end <= left.end){
        //if right is a prefix of left, then return [right.end+1,left.end]
        return new ActionTrace(right.end+1, left.end)
    }
    else if(right.start === left.start && left.end <= right.end){
        //if left if a prefix of right, then return [left.end+1,left.end] -- empty
        return new ActionTrace(left.end+1, left.end)
    }
    else{
        return new Bottom()
    }

}
export function domTraceConcat(left:DOMStateTrace|Bottom, right:DOMStateTrace|Bottom):DOMStateTrace|Bottom{
    if(left instanceof Bottom || right instanceof Bottom){
        return new Bottom()
    }
    if(left.empty()){
        return right
    }
    if(right.empty()){
        return left
    }
    if(left.end+1 === right.start){
        return new DOMStateTrace(left.start, right.end)
    }
    throw "wrong DOM trace concat parameters: left:[" + left.start + ", " + left.end + "] and right:[" + right.start + ", " + right.end + "]"

}
export function actionTraceConcat(left:ActionTrace|Bottom, right:ActionTrace|Bottom):ActionTrace|Bottom{
    if(left instanceof Bottom || right instanceof Bottom){
        return new Bottom()
    }
    if(left.empty()){
        return right
    }
    if(right.empty()){
        return left
    }
    if(left.end+1 === right.start){
        return new ActionTrace(left.start, right.end, right.prediction)
    }
    if(right.prediction){
        return new ActionTrace(left.start, left.end, right.prediction)
    }
    throw "wrong action trace concat parameters: left:[" + left.start + ", " + left.end + "] with prediction = "+left.prediction + " and right:[" + right.start + ", " + right.end + "] with prediction " + right.prediction + " "

}
export function actionConsistent(action:Action, actionTrace:ActionTrace|Bottom):boolean{
    if(actionTrace instanceof Bottom){
        return false
    }
    //if trace is empty, then return true
    if(actionTrace.empty()){
        return true
    }
    //if trace is nonempty, then return if left is the prefix of actionTrace
    return action.equals(GlobalRunningEnv.getActionByIndex(actionTrace.start))
}

/* Interpreter */
export class Interpreter {
    public static initWithTrace(domStates:DOMState[], actions:Action[], inputJson:InputJSON){
        GlobalRunningEnv.init(actions, domStates, inputJson)
    }
    public static evaluate(state: RunningState, statement: Statement|Program, usingDOMVerification = false, outermost = false): RunningState {
        //rule (2)
        if(state.domStateTrace instanceof Bottom || state.actionTrace instanceof Bottom) {
            return new RunningState()
        }
        //rule (3)
        if(state.domStateTrace instanceof DOMStateTrace && state.domStateTrace.empty()){
            return new RunningState(new DOMStateTrace(), new ActionTrace(), state.environment)
        }
        //rule (1)
        if(statement instanceof Program){
            let resultActionTrace:Bottom|ActionTrace = new ActionTrace()
            let resultDomStateTrace:Bottom|DOMStateTrace = new DOMStateTrace()
            for(let i = 0; i < statement.blocks.length; ++i){
                let s = statement.blocks[i]
                let runningState = Interpreter.evaluate(state,s, usingDOMVerification)
                if(runningState.domStateTrace instanceof Bottom){
                    return new RunningState()
                }
                if(runningState.domStateTrace.empty() && i != statement.blocks.length-1 && outermost){
                    return new RunningState()
                }
                state = new RunningState(domTraceMinus(state.domStateTrace,runningState.domStateTrace), actionTraceMinus(state.actionTrace, runningState.actionTrace), state.environment)
                resultActionTrace = actionTraceConcat(resultActionTrace,runningState.actionTrace)
                resultDomStateTrace = domTraceConcat(resultDomStateTrace, runningState.domStateTrace)
            }
            return new RunningState(resultDomStateTrace, resultActionTrace, state.environment)
        }
        //rule (4)
        if(statement instanceof Click){
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let action = new Click(targetDomNode)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new RunningState(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(-1,-2,action),state.environment)
                }
                return new RunningState(new DOMStateTrace(state.domStateTrace.start,state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment)
            }
            else{
                return new RunningState()
            }
        }
        if(statement instanceof Download){
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let action = new Download(targetDomNode)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new RunningState(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(-1,-2,action),state.environment)
                }
                return new RunningState(new DOMStateTrace(state.domStateTrace.start,state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment)
            }
            else{
                return new RunningState()
            }
        }
        //rule (5)
        if(statement instanceof GoBack){
            let action = new GoBack()
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new RunningState(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(-1,-2,action),state.environment)
                }
                return new RunningState(new DOMStateTrace(state.domStateTrace.start,state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment)
            }
            else{
                return new RunningState()
            }
        }

        if(statement instanceof ExtractURL){
            let action = new ExtractURL()
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new RunningState(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(-1,-2,action),state.environment)
                }
                return new RunningState(new DOMStateTrace(state.domStateTrace.start,state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment)
            }
            else{
                return new RunningState()
            }
        }
        //rule (6)
        if(statement instanceof ScrapeText){
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let action = new ScrapeText(targetDomNode)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new RunningState(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(-1,-2,action),state.environment)
                }
                return new RunningState(new DOMStateTrace(state.domStateTrace.start,state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment)
            }
            // else if(!GlobalRunningEnv.getDomByIndex(state.domStateTrace.start).checkValidFromDOM(targetDomNode)){
            //     return new RunningState(new DOMStateTrace(), new ActionTrace(), state.environment)
            // }
            else{
                return new RunningState()
            }
        }
        if(statement instanceof ScrapeLink){
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let action = new ScrapeLink(targetDomNode)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new RunningState(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(-1,-2,action),state.environment)
                }
                return new RunningState(new DOMStateTrace(state.domStateTrace.start,state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment)
            }
            // else if(!GlobalRunningEnv.getDomByIndex(state.domStateTrace.start).checkValidFromDOM(targetDomNode)){
            //     return new RunningState(new DOMStateTrace(), new ActionTrace(), state.environment)
            // }
            else{
                return new RunningState()
            }
        }
        //rule (7)
        if(statement instanceof SendKeys){
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let keysText = statement.keysText
            let action = new SendKeys(targetDomNode,keysText)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new RunningState(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(-1,-2,action),state.environment)
                }
                return new RunningState(new DOMStateTrace(state.domStateTrace.start,state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment)
            }
            else{
                return new RunningState()
            }
        }
        //rule (8)
        if(statement instanceof SendData){
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let dataPath = statement.dataPath.evaluateToInputUnitWithoutVariable(state.environment)
            let action = new SendData(targetDomNode,dataPath)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new RunningState(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(-1,-2,action),state.environment)
                }
                return new RunningState(new DOMStateTrace(state.domStateTrace.start,state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment)
            }
            else{
                return new RunningState()
            }
        }
        //rule (9)
        if(statement instanceof ForEachDOMNodes)
        {
            if(getLoopNestedLevel(statement) >= 2 && usingDOMVerification === false){
                return Interpreter.evaluate(state,statement,true)
            }

            let [curDOMNode,curDOMNodes]:[DOMNode, DOMNodes] = statement.domNodes.next(state.environment)
            //if not valid, then return []
            // if(DEBUG.on){
            //     console.log("validating xpath for For loop: " + curDOMNode.toString())
            // }
            state.environment.save(statement.iteratingVariable,curDOMNode)
            // if(DEBUG.on){
            //     console.log("DEBUG action - state.domStateTrace.start: " + state.domStateTrace.start)
            // }

            let validStatus:ForLoopCheckValidResult = GlobalRunningEnv.getDomByIndex(state.domStateTrace.start).checkValidForLoop(state.domStateTrace, state.actionTrace, state.environment, statement.loopBody)
            if(validStatus === ForLoopCheckValidResult.Valid){
                state.environment.save(statement.iteratingVariable,curDOMNode)

                let newSubProgram = new Program([statement.loopBody,
                    new ForEachDOMNodes(statement.iteratingVariable,curDOMNodes,statement.loopBody)])

                return Interpreter.evaluate(state,newSubProgram, usingDOMVerification)
            }

            if(validStatus === ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd || validStatus === ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd){
                if(validStatus === ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd || usingDOMVerification){
                    if(!GlobalRunningEnv.getDomByIndex(state.domStateTrace.start).checkValidFromDOM(curDOMNode)) {
                        return new RunningState(new DOMStateTrace(), new ActionTrace(), state.environment)
                    }
                }
                state.environment.save(statement.iteratingVariable,curDOMNode)
                let newSubProgram = new Program([statement.loopBody,
                    new ForEachDOMNodes(statement.iteratingVariable,curDOMNodes,statement.loopBody)])
                return Interpreter.evaluate(state,newSubProgram, usingDOMVerification)
            }

            //if not valid
            return new RunningState(new DOMStateTrace(), new ActionTrace(), state.environment)


        }

        if(statement instanceof ForEachInput)
        {
            let [curInputPath,curCollection]:[InputPath, InputCollection] = statement.inputCollection.next(state.environment)
            //if not valid, then return []
            // if(DEBUG.on){
            //     console.log("validating xpath for For loop: " + curDOMNode.toString())
            // }
            state.environment.save(statement.iteratingVariable,curInputPath)

            let validStatus:boolean = GlobalRunningEnv.inputData.valid(curInputPath)
            if(validStatus){
                state.environment.save(statement.iteratingVariable,curInputPath)

                let newSubProgram = new Program([statement.loopBody,
                    new ForEachInput(statement.iteratingVariable,curCollection,statement.loopBody)])

                return Interpreter.evaluate(state,newSubProgram, true)
            }
            else{
                return new RunningState(new DOMStateTrace(), new ActionTrace(), state.environment)
            }



        }

        if(statement instanceof WhileLoopWithClick){
            let runningState = Interpreter.evaluate(state, statement.loopBody, true)
            let resultActionTrace = runningState.actionTrace
            let resultDOMTrace = runningState.domStateTrace

            if(runningState.domStateTrace instanceof  Bottom || runningState.actionTrace instanceof Bottom){
                return new RunningState()
            }
            let newState = new RunningState(domTraceMinus(state.domStateTrace, runningState.domStateTrace), actionTraceMinus(state.actionTrace, runningState.actionTrace), runningState.environment)
            if(newState.domStateTrace instanceof  Bottom){
                return new RunningState()
            }
            if(actionConsistent(statement.endAction,newState.actionTrace)){
                if(newState.domStateTrace.length > 0){
                    if(!GlobalRunningEnv.getDomByIndex(newState.domStateTrace.start).checkValidFromDOM(statement.endAction.target.evaluateToDOMNodeWithoutVariable(runningState.environment))) {
                        return new RunningState(resultDOMTrace, resultActionTrace, runningState.environment)
                    }
                }
                let newSubProgram = new Program([statement.endAction,statement])
                let resultState:RunningState = Interpreter.evaluate(newState, newSubProgram, true)
                return new RunningState(domTraceConcat(resultDOMTrace, resultState.domStateTrace), actionTraceConcat(resultActionTrace, resultState.actionTrace), resultState.environment)
            }
            else if(!GlobalRunningEnv.getDomByIndex(newState.domStateTrace.start).checkValidFromDOM(statement.endAction.target.evaluateToDOMNodeWithoutVariable(runningState.environment))){
                return new RunningState(resultDOMTrace, resultActionTrace, runningState.environment)
            }
            else{
                return new RunningState(new DOMStateTrace(), new ActionTrace(), runningState.environment)
            }
        }

        throw "invalid evaluate parameter --- " + statement.toString()
    }

    public static interpret(environment: ExecEnvironment, currentDOM: DOMState, statement: Statement | Program): ActionWithTarget[] {
        if (statement instanceof Program) {
            let actions: ActionWithTarget[] = [];
            for (let thisStatement of statement.content) {
                actions = actions.concat(this.interpret(environment, currentDOM, thisStatement));
            }
            return actions;
        }
        if (statement instanceof ForEachDOMNodes) {
            let variableTarget = DOMNode.constructFromSingleVariable(statement.iteratingVariable);
            let actions: ActionWithTarget[] = [];
            let dynamicStatement: ForEachDOMNodes = statement;
            while (true) {
                let [nextDOMNode, nextDOMNodes] = dynamicStatement.domNodes.next(environment);
                environment.save(dynamicStatement.iteratingVariable, nextDOMNode);
                let interpretedTarget = variableTarget.evaluateToDOMNodeWithoutVariable(environment);
                let interpretedAction = new IterateElement(interpretedTarget)
                interpretedAction.index = statement.index;
                let newActions = this.interpret(environment, currentDOM, dynamicStatement.loopBody);
                if (!currentDOM.__valid(<DOMNode>newActions[0].target)) {
                    break;
                }
                actions = actions.concat([interpretedAction]).concat(newActions);
                dynamicStatement = new ForEachDOMNodes(dynamicStatement.iteratingVariable, nextDOMNodes, dynamicStatement.loopBody)
            }
            return actions;
        }
        if (statement instanceof ForEachInput) {
            return this.interpret(environment, currentDOM, statement.loopBody);
        }
        if (statement instanceof WhileLoopWithClick) {
            return this.interpret(environment, currentDOM, statement.loopBody)
                .concat(this.interpret(environment, currentDOM, statement.endAction));
        }
        if (statement instanceof ScrapeText) {
            let interpretedTarget = statement.target.evaluateToDOMNodeWithoutVariable(environment);
            let interpretedAction = new ScrapeText(interpretedTarget, statement.timestamp, statement.url);
            interpretedAction.index = statement.index;
            return [interpretedAction];
        }
        if (statement instanceof ScrapeLink) {
            let interpretedTarget = statement.target.evaluateToDOMNodeWithoutVariable(environment);
            let interpretedAction = new ScrapeLink(interpretedTarget, statement.timestamp, statement.url);
            interpretedAction.index = statement.index;
            return [interpretedAction];
        }
        if (statement instanceof Click) {
            let interpretedTarget = statement.target.evaluateToDOMNodeWithoutVariable(environment);
            let interpretedAction = new Click(interpretedTarget, statement.timestamp, statement.url);
            interpretedAction.index = statement.index;
            return [interpretedAction];
        }
        if (statement instanceof SendKeys) {
            let interpretedTarget = statement.target.evaluateToDOMNodeWithoutVariable(environment);
            let interpretedAction = new SendKeys(interpretedTarget, statement.keysText, statement.timestamp, statement.url);
            interpretedAction.index = statement.index;
            return [interpretedAction];
        }
        if (statement instanceof SendData) {
            let interpretedTarget = statement.target.evaluateToDOMNodeWithoutVariable(environment);
            let interpretedAction = new SendData(interpretedTarget, statement.dataPath, statement.timestamp, statement.url);
            interpretedAction.index = statement.index;
            return [interpretedAction];
        }
        return [];
    }
}

export class InterpreterForForLoopValid {
    public static evaluate(state: ForLoopVerifyStatus, statement: Statement|Program, useDOM = false): ForLoopVerifyStatus {
        if(state.verifyStatus === ForLoopCheckValidResult.NotValid){
            return new ForLoopVerifyStatus()
        }
        if(state.verifyStatus === ForLoopCheckValidResult.Valid){
            return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.Valid)
        }
        if(state.verifyStatus === ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd){
            return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd)
        }
        if(state.verifyStatus === ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd){
            return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd)
        }

        //rule (2)
        if(state.actionTrace instanceof Bottom || state.domStateTrace instanceof Bottom) {
            return new ForLoopVerifyStatus()
        }
        //rule (3)
        if(state.domStateTrace instanceof DOMStateTrace && state.domStateTrace.empty()){
            return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(),state.environment, ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd)
        }
        //rule (1)
        if(statement instanceof Program){
            let resultActionTrace:Bottom|ActionTrace = new ActionTrace()
            let resultDomStateTrace:Bottom|DOMStateTrace = new DOMStateTrace()

            for(let s of statement.blocks){
                let runningState = InterpreterForForLoopValid.evaluate(state,s)
                if(runningState.verifyStatus === ForLoopCheckValidResult.NotValid){
                    return new ForLoopVerifyStatus()
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.Valid){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.Valid)
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd && s instanceof LoopyStatement){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd)
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd && !(s instanceof LoopyStatement)){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd)
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd)
                }
                state = new ForLoopVerifyStatus(domTraceMinus(state.domStateTrace, runningState.domStateTrace),actionTraceMinus(state.actionTrace, runningState.actionTrace), state.environment, ForLoopCheckValidResult.NotDecided)
                resultActionTrace = actionTraceConcat(resultActionTrace,runningState.actionTrace)
                resultDomStateTrace = domTraceConcat(resultDomStateTrace, runningState.domStateTrace)
                if(s instanceof LoopyStatement){
                    return new ForLoopVerifyStatus(resultDomStateTrace, resultActionTrace, state.environment, ForLoopCheckValidResult.NotDecided)
                }
            }
            return new ForLoopVerifyStatus(resultDomStateTrace, resultActionTrace, state.environment, ForLoopCheckValidResult.NotDecided)
        }
        //rule (4)
        if(statement instanceof Click){
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let action = new Click(targetDomNode)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd)
                }
                return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment, ForLoopCheckValidResult.NotDecided)
            }
            else{
                return new ForLoopVerifyStatus()
            }
        }
        if(statement instanceof Download){
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let action = new Download(targetDomNode)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd)
                }
                return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment, ForLoopCheckValidResult.NotDecided)
            }
            else{
                return new ForLoopVerifyStatus()
            }
        }
        //rule (5)
        if(statement instanceof GoBack){
            let action = new GoBack()
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd)
                }
                return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment, ForLoopCheckValidResult.NotDecided)
            }
            else{
                return new ForLoopVerifyStatus()
            }
        }

        if(statement instanceof ExtractURL){
            let action = new ExtractURL()
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd)
                }
                return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment, ForLoopCheckValidResult.NotDecided)
            }
            else{
                return new ForLoopVerifyStatus()
            }
        }
        //rule (6)
        if(statement instanceof ScrapeText){
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let action = new ScrapeText(targetDomNode)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd)
                }
                return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment, ForLoopCheckValidResult.NotDecided)
            }
            // else if(!GlobalRunningEnv.getDomByIndex(state.domStateTrace.start).checkValidFromDOM(targetDomNode)){
            //     return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.NotDecided)
            // }
            else{
                return new ForLoopVerifyStatus()
            }
        }
        if(statement instanceof ScrapeLink){
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let action = new ScrapeLink(targetDomNode)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd)
                }
                return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment, ForLoopCheckValidResult.NotDecided)
            }
            // else if(!GlobalRunningEnv.getDomByIndex(state.domStateTrace.start).checkValidFromDOM(targetDomNode)){
            //     return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.NotDecided)
            // }
            else{
                return new ForLoopVerifyStatus()
            }
        }
        //rule (7)
        if(statement instanceof SendKeys){
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let keysText = statement.keysText
            let action = new SendKeys(targetDomNode, keysText)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd)
                }
                return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment, ForLoopCheckValidResult.NotDecided)
            }
            else{
                return new ForLoopVerifyStatus()
            }
        }
        //rule (8)
        if(statement instanceof SendData){
            let dataPath = statement.dataPath.evaluateToInputUnitWithoutVariable(state.environment)
            let targetDomNode = statement.target.evaluateToDOMNodeWithoutVariable(state.environment)
            let action = new SendData(targetDomNode, dataPath)
            if(actionConsistent(action,state.actionTrace)){
                if(state.actionTrace instanceof ActionTrace && state.actionTrace.empty()){
                    //here we make a prediction
                    return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                        new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd)
                }
                return new ForLoopVerifyStatus(new DOMStateTrace(state.domStateTrace.start, state.domStateTrace.start),
                    new ActionTrace(state.actionTrace.start, state.actionTrace.start),state.environment, ForLoopCheckValidResult.NotDecided)
            }
            else{
                return new ForLoopVerifyStatus()
            }
        }
        //rule (9)
        if(statement instanceof ForEachDOMNodes)
        {
            let [curDOMNode,curDOMNodes]:[DOMNode, DOMNodes] = statement.domNodes.next(state.environment)
            //if not valid, then return []
            // if(DEBUG.on){
            //     console.log("validating xpath for For loop: " + curDOMNode.toString())
            // }
            state.environment.save(statement.iteratingVariable,curDOMNode)

            let resultActionTrace:Bottom|ActionTrace = new ActionTrace()
            let resultDomStateTrace:Bottom|DOMStateTrace = new DOMStateTrace()

            for(let s of statement.loopBody.blocks){
                let runningState = InterpreterForForLoopValid.evaluate(state,s)
                if(runningState.verifyStatus === ForLoopCheckValidResult.NotValid){
                    return new ForLoopVerifyStatus()
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.Valid){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.Valid)
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd)
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd)
                }
                state = new ForLoopVerifyStatus(domTraceMinus(state.domStateTrace, runningState.domStateTrace),actionTraceMinus(state.actionTrace, runningState.actionTrace), state.environment, ForLoopCheckValidResult.NotDecided)
                resultActionTrace = actionTraceConcat(resultActionTrace,runningState.actionTrace)
                resultDomStateTrace = domTraceConcat(resultDomStateTrace, runningState.domStateTrace)
                if(s instanceof LoopyStatement){
                    return new ForLoopVerifyStatus(resultDomStateTrace, resultActionTrace, state.environment, ForLoopCheckValidResult.NotDecided)
                }
            }
            return new ForLoopVerifyStatus(resultDomStateTrace, resultActionTrace, state.environment, ForLoopCheckValidResult.NotDecided)


        }

        if(statement instanceof ForEachInput)
        {
            let [curInputPath,curCollection]:[InputPath, InputCollection] = statement.inputCollection.next(state.environment)
            //if not valid, then return []
            // if(DEBUG.on){
            //     console.log("validating xpath for For loop: " + curDOMNode.toString())
            // }
            state.environment.save(statement.iteratingVariable,curInputPath)

            let resultActionTrace:Bottom|ActionTrace = new ActionTrace()
            let resultDomStateTrace:Bottom|DOMStateTrace = new DOMStateTrace()

            for(let s of statement.loopBody.blocks){
                let runningState = InterpreterForForLoopValid.evaluate(state,s)
                if(runningState.verifyStatus === ForLoopCheckValidResult.NotValid){
                    return new ForLoopVerifyStatus()
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.Valid){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.Valid)
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd)
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd)
                }
                state = new ForLoopVerifyStatus(domTraceMinus(state.domStateTrace, runningState.domStateTrace),actionTraceMinus(state.actionTrace, runningState.actionTrace), state.environment, ForLoopCheckValidResult.NotDecided)
                resultActionTrace = actionTraceConcat(resultActionTrace,runningState.actionTrace)
                resultDomStateTrace = domTraceConcat(resultDomStateTrace, runningState.domStateTrace)
                if(s instanceof LoopyStatement){
                    return new ForLoopVerifyStatus(resultDomStateTrace, resultActionTrace, state.environment, ForLoopCheckValidResult.NotDecided)
                }
            }
            return new ForLoopVerifyStatus(resultDomStateTrace, resultActionTrace, state.environment, ForLoopCheckValidResult.NotDecided)

        }

        if(statement instanceof WhileLoopWithClick){
            let resultActionTrace:Bottom|ActionTrace = new ActionTrace()
            let resultDomStateTrace:Bottom|DOMStateTrace = new DOMStateTrace()

            for(let s of statement.loopBody.blocks){
                let runningState = InterpreterForForLoopValid.evaluate(state,s)
                if(runningState.verifyStatus === ForLoopCheckValidResult.NotValid){
                    return new ForLoopVerifyStatus()
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.Valid){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.Valid)
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.PredictionExistNoNestedLoopInTheEnd){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd)
                }
                if(runningState.verifyStatus === ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd){
                    return new ForLoopVerifyStatus(new DOMStateTrace(), new ActionTrace(), state.environment, ForLoopCheckValidResult.PredictionExistNestedLoopInTheEnd)
                }

                state = new ForLoopVerifyStatus(domTraceMinus(state.domStateTrace, runningState.domStateTrace),actionTraceMinus(state.actionTrace, runningState.actionTrace), state.environment, ForLoopCheckValidResult.NotDecided)
                resultActionTrace = actionTraceConcat(resultActionTrace,runningState.actionTrace)
                resultDomStateTrace = domTraceConcat(resultDomStateTrace, runningState.domStateTrace)
                if(s instanceof LoopyStatement){
                    return new ForLoopVerifyStatus(resultDomStateTrace, resultActionTrace, state.environment, ForLoopCheckValidResult.NotDecided)
                }
            }
            return new ForLoopVerifyStatus(resultDomStateTrace, resultActionTrace, state.environment, ForLoopCheckValidResult.NotDecided)
        }
        throw "invalid evaluate parameter --- " + statement.toString()
    }
}

function getLoopNestedLevel(p:Program|Statement):number{
    if(p instanceof Program){
        let maxNestedLevel = 0
        for(let s of p.blocks){
            let nestedLevelForS = getLoopNestedLevel(s)
            if(maxNestedLevel< nestedLevelForS){
                maxNestedLevel = nestedLevelForS
            }
        }
        return maxNestedLevel
    }
    if(p instanceof LoopyStatement){
        return getLoopNestedLevel(p.loopBody) + 1
    }
    return 0
}
