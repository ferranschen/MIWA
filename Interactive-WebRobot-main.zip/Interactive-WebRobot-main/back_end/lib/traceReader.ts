import {Action, actionFactory, ActionTrace, DOMState, InputJSON} from "./DSL";
import {readFileSync} from "fs"
import {resolve,dirname} from "path"

var MAX_TRACE_LEN = 200

export function readTraceFromJson(jsonFilePath:string):[actions:Action[],doms:DOMState[]]{
    let dataJSON = JSON.parse(readFileSync(jsonFilePath).toString())
    let actions: { [index:string]:any }[] = dataJSON["actions"]
    let doms:string[] = dataJSON["doms"]
    if(doms === undefined)
    {
        doms = dataJSON["states"]
    }

    if(actions[0].actionName.indexOf("OpenURL")!== -1){
        actions.shift()
        doms.shift()
    }

    if(actions.length > MAX_TRACE_LEN){
        actions = actions.slice(0,MAX_TRACE_LEN)
        doms = doms.slice(0,MAX_TRACE_LEN+1)
    }

    let resultActionTrace:Action[] = []
    let resultDOMTrace:DOMState[] = []

    for(let action of actions){
        resultActionTrace.push(actionFactory(action))
    }
    for(let dom of doms){
        resultDOMTrace.push(new DOMState(readFileSync(dirname(jsonFilePath)+"/doms/"+dom).toString()))
    }
    return [resultActionTrace,resultDOMTrace]
}
