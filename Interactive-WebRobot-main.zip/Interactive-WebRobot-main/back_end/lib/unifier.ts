import {
    Click,
    DOMNode, DOMNodePartPredicate, DOMNodePartVar, DOMNodePointer, DOMNodes,
    Download, ExtractURL, ForEachDOMNodes,
    GoBack, InputCollection,
    InputPath,
    InputPathNode,
    ScrapeLink,
    ScrapeText, SendData,
    SendKeys, Statement,
    Variable
} from "./DSL";


export class DOMNodeUnifyResultUnit {
    public parameterizedPath: DOMNode
    public variable: Variable
    public collection: DOMNodes

    constructor(parameterizedPath: DOMNode, variable: Variable, collection: DOMNodes) {
        this.parameterizedPath = parameterizedPath
        this.variable = variable
        this.collection = collection
    }
}

export class InputPathUnifyResultUnit {
    public parameterizedPath: InputPath
    public variable: Variable
    public collection: InputCollection

    constructor(parameterizedPath: InputPath, variable: Variable, collection: InputCollection) {
        this.parameterizedPath = parameterizedPath
        this.variable = variable
        this.collection = collection
    }
}

export class StatementDOMNodeUnifyResultUnit {
    public parameterizedStatement: Statement;
    public variable: Variable
    public collection: DOMNodes

    constructor(parameterizedStatement:Statement, variable: Variable, collection: DOMNodes) {
        this.parameterizedStatement = parameterizedStatement
        this.variable = variable
        this.collection = collection
    }
}

export class StatementInputPathUnifyResultUnit {
    public parameterizedStatement: Statement;
    public variable: Variable
    public collection: InputCollection

    constructor(parameterizedStatement:Statement, variable: Variable, collection: InputCollection) {
        this.parameterizedStatement = parameterizedStatement
        this.variable = variable
        this.collection = collection
    }
}

export class CollectionUnifyResultUnit {
    public collection: DOMNodes
    public variable: Variable
    public parameterizedCollection: DOMNodes

    constructor(collection: DOMNodes, variable: Variable, parameterizedCollection: DOMNodes) {
        this.collection = collection
        this.variable = variable
        this.parameterizedCollection = parameterizedCollection
    }
}


function unifyDOMNodePointer(left:DOMNodePointer, right:DOMNodePointer):DOMNodeUnifyResultUnit[]|null{
    let leftDOMNodeSet = left.getNodeSet()
    let rightDOMNodeSet = right.getNodeSet()
    let result:DOMNodeUnifyResultUnit[] = []
    for(let l of leftDOMNodeSet){
        for(let r of rightDOMNodeSet){
            let unifyResult = unifyDOMNode(l, r)
            if(unifyResult !== null){
                result.push(unifyResult)
            }
        }
    }
    return result
}

function unifyDOMNode(left: DOMNode, right: DOMNode): DOMNodeUnifyResultUnit|null {
    if (!(left instanceof DOMNode && right instanceof DOMNode)) {
        return null
    }
    if (left.nodePartList.length !== right.nodePartList.length) {
        return null
    }
    //find the node with different index. If there's more than 1 node that are different, then return []
    let diffIndex = -1
    for (let i = 0; i < left.nodePartList.length; ++i) {
        if (!left.nodePartList[i].equals(right.nodePartList[i])) {
            let leftNodePart = left.nodePartList[i]
            let rightNodePart = right.nodePartList[i]
            if(leftNodePart instanceof DOMNodePartPredicate && rightNodePart instanceof DOMNodePartPredicate){
                if (leftNodePart.index !== 1 || rightNodePart.index !== 2 || !(leftNodePart.predicate.equals(rightNodePart.predicate))) {
                    return null
                }
                if (diffIndex === -1) {
                    diffIndex = i
                } else {
                    return null // if there's more than one node different in index, then return []
                }
            }
            else{
                return null
            }
        }
    }
    if (diffIndex === -1) {
        return null
    }
    //now, two DOMNode are only different in nodeList[diffIndex] and has index 1 and 2
    let resultDOMNodeHead: DOMNode = DOMNode.constructFromOtherDOMNode(left, 0, diffIndex)
    let parameterizedPath: DOMNode = DOMNode.constructFromOtherDOMNode(left, diffIndex + 1, left.nodePartList.length)
    let variableNode = DOMNodePartVar.newVariableNode()
    parameterizedPath.nodePartList.unshift(variableNode)
    let diffNode = left.nodePartList[diffIndex]
    if(!(diffNode instanceof DOMNodePartPredicate)){
        throw "Error DOM Node Part Type!"
    }
    let resultCollection = new DOMNodes(resultDOMNodeHead, diffNode.predicate,diffNode.searchType)
    return new DOMNodeUnifyResultUnit(parameterizedPath, variableNode.variable, resultCollection)
}

function unifyInputPath(left: InputPath, right: InputPath): InputPathUnifyResultUnit|null {
    if (left.nodeList.length !== right.nodeList.length) {
        return null
    }
    //find the node with different index. If there's more than 1 node that are different, then return []
    let diffIndex = -1
    for (let i = 0; i < left.nodeList.length; ++i) {
        if (!left.nodeList[i].equals(right.nodeList[i])) {
            let leftNode = left.nodeList[i]
            let rightNode = right.nodeList[i]
            if (leftNode.index !== 0 || rightNode.index !== 1 || !(leftNode.name === rightNode.name)) {
                return null
            }
            if (diffIndex === -1) {
                diffIndex = i
            } else {
                return null // if there's more than one node different in index, then return []
            }
        }
    }
    if (diffIndex === -1) {
        return null
    }
    //now, two DOMNode are only different in nodeList[diffIndex] and has index 1 and 2
    let resultInputPathHead: InputPath = InputPath.constructFromOtherInputPath(left, 0, diffIndex)
    let parameterizedPath: InputPath = InputPath.constructFromOtherInputPath(left, diffIndex + 1, left.nodeList.length)
    let variableNode = InputPathNode.newVariableNode()
    parameterizedPath.nodeList.unshift(variableNode)
    let diffNode = left.nodeList[diffIndex]

    let resultCollection = new InputCollection(resultInputPathHead, diffNode)
    return new InputPathUnifyResultUnit(parameterizedPath, variableNode.variable, resultCollection)
}

export class Unifier {
    public static unifyDOMNode(left: DOMNode, right: DOMNode):DOMNodeUnifyResultUnit|null {
        //rule 5
        if (left instanceof DOMNode && right instanceof DOMNode) {
            return unifyDOMNode(left, right)
        }
        throw "Error type in unifyDOMNode!"
    }
    public static unifyDOMNodePointer(left: DOMNodePointer, right: DOMNodePointer):DOMNodeUnifyResultUnit[]|null {
        //rule 5
        if (left instanceof DOMNode && right instanceof DOMNode) {
            return unifyDOMNodePointer(left, right)
        }
        throw "Error type in unifyDOMNodePointer!"
    }


    public static unifyStatementsForInputPathLoop(left:Statement, right:Statement): StatementInputPathUnifyResultUnit[]|null{
        if(left instanceof SendData && right instanceof SendData){
            let inputUnifyResult: InputPathUnifyResultUnit|null = unifyInputPath(left.dataPath, right.dataPath)
            if(inputUnifyResult){
                let sharedXpath:DOMNode[] = left.target.getSharedXpath(right.target)
                let result:StatementInputPathUnifyResultUnit[] = []
                for(let s of sharedXpath){
                    result.push(new StatementInputPathUnifyResultUnit(new SendData(s, inputUnifyResult.parameterizedPath), inputUnifyResult.variable, inputUnifyResult.collection))
                }
                return result
            }
        else{
                return null
            }
        }
        else{
            return null
        }
    }


    public static unifyStatementsForDomNodeLoop(left:Statement, right:Statement): StatementDOMNodeUnifyResultUnit[]|null {
        if (left.constructor !== right.constructor) {
            return null
        }
        //rule 4
        if (left instanceof Click && right instanceof Click) {
            if(left.target instanceof DOMNode && right.target instanceof DOMNode){
                let domNodeUnifyResult: DOMNodeUnifyResultUnit|null = unifyDOMNode(left.target, right.target)
                if(domNodeUnifyResult){
                    return [new StatementDOMNodeUnifyResultUnit(new Click(domNodeUnifyResult.parameterizedPath), domNodeUnifyResult.variable, domNodeUnifyResult.collection)]
                }
                else{
                    return null
                }
            }
            if(left.target instanceof DOMNodePointer && right.target instanceof DOMNodePointer){
                let result:StatementDOMNodeUnifyResultUnit[] = []
                let domNodePointerUnifyResult:DOMNodeUnifyResultUnit[]|null = unifyDOMNodePointer(left.target, right.target)
                if(domNodePointerUnifyResult){
                    for(let r of domNodePointerUnifyResult){
                        if(r !== null){
                            result.push(new StatementDOMNodeUnifyResultUnit(new Click(r.parameterizedPath), r.variable, r.collection))
                        }
                    }
                    return result
                }
                else{
                    return null
                }
            }
            return null
        }
        if (left instanceof ScrapeText && right instanceof ScrapeText) {
            if(left.target instanceof DOMNode && right.target instanceof DOMNode){
                let domNodeUnifyResult: DOMNodeUnifyResultUnit|null = unifyDOMNode(left.target, right.target)
                if(domNodeUnifyResult){
                    return [new StatementDOMNodeUnifyResultUnit(new ScrapeText(domNodeUnifyResult.parameterizedPath), domNodeUnifyResult.variable, domNodeUnifyResult.collection)]
                }
                else{
                    return null
                }
            }
            if(left.target instanceof DOMNodePointer && right.target instanceof DOMNodePointer){
                let result:StatementDOMNodeUnifyResultUnit[] = []
                let domNodePointerUnifyResult:DOMNodeUnifyResultUnit[]|null = unifyDOMNodePointer(left.target, right.target)
                if(domNodePointerUnifyResult){
                    for(let r of domNodePointerUnifyResult){
                        if(r !== null){
                            result.push(new StatementDOMNodeUnifyResultUnit(new ScrapeText(r.parameterizedPath), r.variable, r.collection))
                        }
                    }
                    return result
                }
                else{
                    return null
                }
            }
            return null
        }
        if (left instanceof ScrapeLink && right instanceof ScrapeLink) {
            if(left.target instanceof DOMNode && right.target instanceof DOMNode){
                let domNodeUnifyResult: DOMNodeUnifyResultUnit|null = unifyDOMNode(left.target, right.target)
                if(domNodeUnifyResult){
                    return [new StatementDOMNodeUnifyResultUnit(new ScrapeLink(domNodeUnifyResult.parameterizedPath), domNodeUnifyResult.variable, domNodeUnifyResult.collection)]
                }
                else{
                    return null
                }
            }
            if(left.target instanceof DOMNodePointer && right.target instanceof DOMNodePointer){
                let result:StatementDOMNodeUnifyResultUnit[] = []
                let domNodePointerUnifyResult:DOMNodeUnifyResultUnit[]|null = unifyDOMNodePointer(left.target, right.target)
                if(domNodePointerUnifyResult){
                    for(let r of domNodePointerUnifyResult){
                        if(r !== null){
                            result.push(new StatementDOMNodeUnifyResultUnit(new ScrapeLink(r.parameterizedPath), r.variable, r.collection))
                        }
                    }
                    return result
                }
                else{
                    return null
                }
            }
            return null
        }
        if (left instanceof Download && right instanceof Download) {
            if(left.target instanceof DOMNode && right.target instanceof DOMNode){
                let domNodeUnifyResult: DOMNodeUnifyResultUnit|null = unifyDOMNode(left.target, right.target)
                if(domNodeUnifyResult){
                    return [new StatementDOMNodeUnifyResultUnit(new Download(domNodeUnifyResult.parameterizedPath), domNodeUnifyResult.variable, domNodeUnifyResult.collection)]
                }
                else{
                    return null
                }
            }
            if(left.target instanceof DOMNodePointer && right.target instanceof DOMNodePointer){
                let result:StatementDOMNodeUnifyResultUnit[] = []
                let domNodePointerUnifyResult:DOMNodeUnifyResultUnit[]|null = unifyDOMNodePointer(left.target, right.target)
                if(domNodePointerUnifyResult){
                    for(let r of domNodePointerUnifyResult){
                        if(r !== null){
                            result.push(new StatementDOMNodeUnifyResultUnit(new Download(r.parameterizedPath), r.variable, r.collection))
                        }
                    }
                    return result
                }
                else{
                    return null
                }
            }
            return null
        }
        if (left instanceof ExtractURL && right instanceof ExtractURL) {
            return null
        }
        if (left instanceof GoBack && right instanceof GoBack) {
            return null
        }
        if (left instanceof SendKeys && right instanceof SendKeys) {
            if(left.target instanceof DOMNode && right.target instanceof DOMNode){
                if(left.keysText !== right.keysText){
                    return null
                }
                let domNodeUnifyResult: DOMNodeUnifyResultUnit|null = unifyDOMNode(left.target, right.target)
                if(domNodeUnifyResult){
                    return [new StatementDOMNodeUnifyResultUnit(new SendKeys(domNodeUnifyResult.parameterizedPath, left.keysText), domNodeUnifyResult.variable, domNodeUnifyResult.collection)]
                }
                else{
                    return null
                }
            }
            if(left.target instanceof DOMNodePointer && right.target instanceof DOMNodePointer){
                if(left.keysText !== right.keysText){
                    return null
                }
                let result:StatementDOMNodeUnifyResultUnit[] = []
                let domNodePointerUnifyResult:DOMNodeUnifyResultUnit[]|null = unifyDOMNodePointer(left.target, right.target)
                if(domNodePointerUnifyResult){
                    for(let r of domNodePointerUnifyResult){
                        if(r !== null){
                            result.push(new StatementDOMNodeUnifyResultUnit(new SendKeys(r.parameterizedPath, left.keysText), r.variable, r.collection))
                        }
                    }
                    return result
                }
                else{
                    return null
                }
            }
            return null

        }
        if (left instanceof ForEachDOMNodes && right instanceof ForEachDOMNodes) {
            if (!left.loopBody.equals(right.loopBody)) {
                return null
            }
            if(!left.iteratingVariable.equals(right.iteratingVariable)){
                return null
            }
            let collectionUnifyResult = Unifier.unifyCollections(left.domNodes, right.domNodes)
            if(collectionUnifyResult){
                return [new StatementDOMNodeUnifyResultUnit(new ForEachDOMNodes(left.iteratingVariable,collectionUnifyResult.parameterizedCollection,left.loopBody),
                    collectionUnifyResult.variable, collectionUnifyResult.collection)]
            }
            else
            {
                return null
            }

        }
        return null
        //throw "Can't unify " + left.toString() + " and " + right.toString()
    }

    public static unifyCollections(left:DOMNodes, right:DOMNodes): CollectionUnifyResultUnit|null {
        if (left instanceof DOMNodes && right instanceof DOMNodes) {
            if(left.searchType === right.searchType){
                let domNodeUnifyResult = unifyDOMNode(left.parentNode, right.parentNode)
                if(domNodeUnifyResult){
                    return new CollectionUnifyResultUnit(domNodeUnifyResult.collection, domNodeUnifyResult.variable,
                        new DOMNodes(domNodeUnifyResult.parameterizedPath,left.predicate, left.searchType))
                }
                else
                {
                    return null
                }
            }
            else{
                return null
            }
        }
        else{
            throw "Can't unify " + left.toString() + " and " + right.toString()
        }

    }
}