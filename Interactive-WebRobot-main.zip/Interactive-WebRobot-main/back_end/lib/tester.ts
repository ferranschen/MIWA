import {Action, DOMState} from "./DSL";
import {DEBUG, synthesize} from "./algorithms";
import {BackendSynthesizer} from "./backendSynthesizer";

export class Tester{
    private actionTrace:Action[]
    private domTrace:DOMState[]
    private correctPredictionsSoFar:number = 0
    private timeSpentSoFar:number = 0
    private longestPredictionTimeSoFar:number = 0
    private totalActionsSoFar:number = 0

    constructor(actionTrace:Action[], domTrace:DOMState[]) {
        if(actionTrace.length !== domTrace.length - 1){
            throw "Invalid action trace and DOM trace: the length of DOM trace should be 1 longer than action trace."
        }
        this.actionTrace = actionTrace
        this.domTrace = domTrace
    }

    public startTest(){
        let backendSynthesizer = new BackendSynthesizer()
        for(let i = 0; i <= 1; ++i){
            backendSynthesizer.appendActionAndDOM(this.actionTrace[i],this.domTrace[i])
        }
        for(let i = 2; i < this.actionTrace.length; ++i){
            this.totalActionsSoFar = this.totalActionsSoFar + 1

            let timeStart = new Date()
            //let [programs,predictedActions] = synthesize(this.domTrace.slice(0,i+1),this.actionTrace.slice(0,i))
            let [programs,predictedActions] = backendSynthesizer.getNextPrediction(this.domTrace[i])
            let timeEnd = new Date()
            let timeSpendInMs = timeEnd.getTime()-timeStart.getTime()

            this.timeSpentSoFar += timeSpendInMs
            if(timeSpendInMs > this.longestPredictionTimeSoFar){
                this.longestPredictionTimeSoFar = timeSpendInMs
            }

            if(predictedActions.length > 0){
                let matched = false;
                for(let p of predictedActions){
                    if(p.equals(this.actionTrace[i])){
                        console.log('\x1b[32m%s\x1b[0m', (i+1) + "th action - matched. Time spent: " + timeSpendInMs + " ms");
                        this.correctPredictionsSoFar = this.correctPredictionsSoFar + 1
                        matched = true
                        break
                    }
                }
                if(matched){
                    if(DEBUG.showTestingResult){
                        console.log("predicted actions:")
                        for(let a of predictedActions){
                            console.log(a.toString())
                        }
                        console.log("predicted programs:")
                        for(let p of programs){
                            console.log(p.toString())
                        }
                    }
                }
                if(!matched){
                    console.log('\x1b[31m%s\x1b[0m', (i+1) + "th action - wrong prediction. Time spent: " + timeSpendInMs + " ms");
                    backendSynthesizer.clearCachedProgram()
                   if(DEBUG.showTestingResult)
                   {
                       console.log("all predictions:")
                       for(let action of predictedActions){
                           console.log(action.toString())
                       }
                       console.log("all programs:")
                       for(let p of programs){
                           console.log(p.toString())
                       }
                       console.log("correct: " + this.actionTrace[i+1].toString())
                   }
                }
            }
            else{
                console.log('\x1b[33m%s\x1b[0m', (i+1) + "th action - no prediction. Time spent: " + timeSpendInMs + " ms");
            }
            console.log("So far, # of actions: " + this.totalActionsSoFar + ", # of correct actions: " + this.correctPredictionsSoFar + ", accuracy: " + (this.correctPredictionsSoFar/this.totalActionsSoFar) +"  average time per prediction: " + (this.timeSpentSoFar/this.totalActionsSoFar) + " ms, longest prediction time: " + this.longestPredictionTimeSoFar + " ms.")
            backendSynthesizer.appendDOM(this.domTrace[i])
            backendSynthesizer.appendAction(this.actionTrace[i])
        }
    }
}