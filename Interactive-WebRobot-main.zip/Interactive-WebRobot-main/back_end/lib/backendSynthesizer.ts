import {
    Action,
    ActionTrace,
    ActionWithTarget,
    Click,
    DOMNode,
    DOMState,
    DOMStateTrace,
    Download,
    ExecEnvironment,
    ExtractURL,
    GlobalRunningEnv,
    GoBack,
    InputJSON,
    IterateElement,
    LoopyStatement,
    NoRepeatActionArray,
    NoRepeatWorkListArray,
    Program,
    ScrapeLink,
    ScrapeText,
    SendData,
    SendKeys,
    Statement,
    StatementFunctionType,
    WhileLoopWithClick
} from "./DSL";
import {DEBUG, isStrictPrefixActionTrace, RewriteWorklistUnit, synthesize} from "./algorithms";
import {Interpreter, RunningState} from "./interpreter";
import {AnomalyStatus} from "../server";

export class BackendSynthesizer{
    // data
    private doms:DOMState[] = []
    private actions:Action[] = []
    private inputData:InputJSON = new InputJSON({})
    private variablePattern:RegExp = /<v\d+>/
    //cache related
    private previousCorrectRewriteUnits:RewriteWorklistUnit[] = []
    private cachedRewriteUnits:RewriteWorklistUnit[] = []
    private previousCorrect:boolean = false
    private lastCachedRewriteUnits:RewriteWorklistUnit[] = []
    private lastPredictions:Action[] = []
    private tmpWorklistToCombine:RewriteWorklistUnit[] = []
    private lastColumnMappings:number[][] = [] // lastColumnMappings[programID][columnID] = index of action in program
    private lastActionList:string[][] = [] // lastActionList[programID][index] = string of action target in program
    //scrape in bulk related
    private inScrapeInBulkMode = false
    private bulkStartIndex = -1
    // incremental synthesis cache
    private previousCorrectRewriteIsc:RewriteWorklistUnit[][] = []
    private cachedRewriteIsc:RewriteWorklistUnit[][] = []
    private previousCorrectIsc:boolean[] = []
    private lastCachedRewriteIsc:RewriteWorklistUnit[][] = []

    public updateIsc() {
        this.previousCorrectRewriteIsc.push(this.previousCorrectRewriteUnits);
        this.cachedRewriteIsc.push(this.lastCachedRewriteUnits);
        this.previousCorrectIsc.push(this.previousCorrect);
        this.lastCachedRewriteIsc.push(this.lastCachedRewriteUnits);
    }

    private reduceIsc(index:number = 0) {
        this.previousCorrectRewriteIsc.splice(index);
        this.cachedRewriteIsc.splice(index);
        this.previousCorrectIsc.splice(index);
        this.lastCachedRewriteIsc.splice(index);
        if (index > 0) {
            this.previousCorrectRewriteUnits = this.previousCorrectRewriteIsc[index - 1];
            this.cachedRewriteUnits = this.cachedRewriteIsc[index - 1];
            this.previousCorrect = this.previousCorrectIsc[index - 1];
            this.lastCachedRewriteUnits = this.lastCachedRewriteIsc[index - 1];
        } else {
            this.previousCorrectRewriteUnits = [];
            this.cachedRewriteUnits = [];
            this.previousCorrect = false;
            this.lastCachedRewriteUnits = [];
        }
    }

    public appendActionAndDOM(action:Action, dom:DOMState){
        this.appendDOM(dom)
        this.appendAction(action)
    }

    public getActionTrace(){
        return this.actions
    }

    public getActionByTimestamp(timestamp:number){
        for (let a of this.actions){
            if (a.timestamp === timestamp){
                return a
            }
        }
        return null
    }

    public getIndexByTimestamp(timestamp:number){
        for (let i = 0; i < this.actions.length; i++) {
            if (this.actions[i].timestamp === timestamp) {
                return i
            }
        }
        return -1
    }

    public getActionTraceWithNameAndTimestamp(){
        let result:any = []
        for(let action of this.actions){
            result.push(action.getNameAndTimestamp())
        }
        return result
    }

    public restart(input_data: { [index: string]: any }) {
        this.doms = []
        this.actions = []
        this.inputData = new InputJSON(input_data)
        this.previousCorrectRewriteUnits = []
        this.cachedRewriteUnits = []
        this.previousCorrect = false
        this.lastCachedRewriteUnits = []
        this.lastPredictions= []
        this.tmpWorklistToCombine = []
        this.reduceIsc();
    }

    public deleteAction(timestamp:number): [boolean, Action]{
        let indexToBeDeleted = this.getIndexByTimestamp(timestamp)
        if(indexToBeDeleted === -1){
            throw "Wrong timestamp to delete - can't find corresponding action!"
        }
        this.reduceIsc(indexToBeDeleted);
        this.actions.splice(indexToBeDeleted, 1)
        this.doms.splice(indexToBeDeleted, 1) // here we do this because DOM and action are always dealt parallely
        return [indexToBeDeleted === this.actions.length, this.actions[this.actions.length - 1]]
    }

    public updateAction(timestamp:number, action:Action, dom:DOMState): boolean{
        let indexToBeDeleted = this.getIndexByTimestamp(timestamp)
        if(indexToBeDeleted === -1){
            throw "Wrong timestamp to update - can't find corresponding action!"
        }
        this.reduceIsc(indexToBeDeleted);
        this.actions.splice(indexToBeDeleted, 1, action)
        this.doms.splice(indexToBeDeleted, 1, dom)
        return indexToBeDeleted === this.actions.length
    }

    public updateActionForBulk(actions:Action[]){
        for (let i = this.bulkStartIndex; i < this.bulkStartIndex + actions.length; i++) {
            this.actions[i] = actions[i - this.bulkStartIndex]
        }
        this.actions.splice(this.bulkStartIndex + actions.length)
        let tmpNewCachedRewriteUnits: RewriteWorklistUnit[] = []
        for (let c of this.cachedRewriteUnits) {
            tmpNewCachedRewriteUnits.push(c.deleteLastRangeUntil(this.bulkStartIndex + actions.length - 1))
        }
        this.cachedRewriteUnits = tmpNewCachedRewriteUnits
    }

    public insertAction(timestamp:number, action:Action, dom:DOMState){
        let indexToBeDeleted = this.getIndexByTimestamp(timestamp)
        if(indexToBeDeleted === -1){
            throw "Wrong timestamp to update - can't find corresponding action!"
        }
        this.reduceIsc(indexToBeDeleted);
        this.actions.splice(indexToBeDeleted, 0, action)
        this.doms.splice(indexToBeDeleted, 0, dom)
    }

    public appendAction(action:Action){
        //if we are in scrape in bulk mode, then every program will make correct prediction we assume
        if(this.inScrapeInBulkMode){
            this.actions.push(action)
            let tmpNewCachedRewriteUnits:RewriteWorklistUnit[] = []
            for(let c of this.cachedRewriteUnits){
                tmpNewCachedRewriteUnits.push(c.extendOneWithEndForLoop())
            }
            this.cachedRewriteUnits = tmpNewCachedRewriteUnits
            return
        }

        let correctPrediction = false
        if(this.lastPredictions.length !== 0){
            for(let a of this.lastPredictions){
                if(a.equals(action)){
                    correctPrediction = true
                    break
                }
            }
            if(!correctPrediction){
                if(DEBUG.procedureInfoDisplay){
                    console.log("resume last cached program!!!!!!")
                }

                this.resumeLastCachedProgram()
                this.lastPredictions = []
            }
        }
        this.actions.push(action)
        if(!this.previousCorrect){
            //if previous cached programs can't generate correct results, then we need to update it with the most current action
            let tmpNewCachedRewriteUnits:RewriteWorklistUnit[] = []
            for(let c of this.cachedRewriteUnits){
                tmpNewCachedRewriteUnits.push(c.extendOneWithNewAction(action))
            }
            this.cachedRewriteUnits = tmpNewCachedRewriteUnits
        }
        else{
            //if previous cached programs can generate correct results, then we need to extend it with loop.
            let tmpNewCachedRewriteUnits:RewriteWorklistUnit[] = []
            for(let c of this.cachedRewriteUnits){
                tmpNewCachedRewriteUnits.push(c.extendOneWithEndForLoop())
            }
            this.cachedRewriteUnits = tmpNewCachedRewriteUnits
        }
    }
    public appendDOM(dom:DOMState){
        this.doms.push(dom)
    }

    public setInputData(inputJSON:InputJSON){
        this.inputData = inputJSON
    }

    public clearCachedProgram(){
        this.previousCorrectRewriteUnits = []
        this.cachedRewriteUnits = []
        this.lastCachedRewriteUnits = []
        this.previousCorrect = false
    }
    public resumeLastCachedProgram(){
        if(DEBUG.procedureInfoDisplay){
            console.log("wrong prediction - resume cached program")
        }

        this.cachedRewriteUnits = this.lastCachedRewriteUnits
        // this.cachedRewriteUnits = []
        this.previousCorrect = false
        this.previousCorrectRewriteUnits = []
    }

    public getNextPredictionInBulk(currentDOM: DOMState, datapath_dictionary: { [datapath: string]: string },
                                   bulkSizeLimit: number): [Program[], Action[], AnomalyStatus] {
        let resultPrograms:Program[] = []
        let resultActions:Action[] = []
        let anomalyStatus:AnomalyStatus = AnomalyStatus.VALID;
        this.inScrapeInBulkMode = true
        this.bulkStartIndex = this.actions.length
        while (resultActions.length < bulkSizeLimit) {
            let [programs, rawPredictedActions] = this.getNextPrediction(currentDOM, false)
            if (rawPredictedActions.length > 0) {
                let predictedActions = [];
                for (let thisAction of rawPredictedActions) {
                    if (!(thisAction instanceof ActionWithTarget) || currentDOM.__valid(<DOMNode>thisAction.target)) {
                        if (thisAction instanceof SendData) {
                            if (thisAction.index < Object.keys(datapath_dictionary).length) {
                                predictedActions.push(thisAction.revertDataPath(datapath_dictionary));
                            }
                        } else {
                            predictedActions.push(thisAction);
                        }
                    }
                }
                if (programs.length > 0) {
                    resultPrograms = programs
                } else {
                    console.log("scrape in bulk has stopped generating - no more valid program")
                    break
                }
                if (predictedActions.length > 0) {
                    let action = predictedActions[0]
                    if (action instanceof Click || action instanceof GoBack) {
                        console.log("scrape in bulk has stopped generating - reached an action that requires page reload")
                        if (resultActions.length === 0) {
                            resultActions.push(action)
                            this.appendDOM(currentDOM)
                        }
                        break
                    } else {
                        resultActions.push(action)
                        this.appendDOM(currentDOM)
                    }
                } else {
                    console.log("scrape in bulk has stopped generating - no more valid predicted action")
                    anomalyStatus = AnomalyStatus.INVALID_NOT_EXIST;
                    break
                }
            } else {
                console.log("scrape in bulk can't generate anything - no valid program yet")
                break
            }
        }
        this.inScrapeInBulkMode = false
        console.log("scrape in bulk has generated " + resultActions.length.toString() + " action(s)")
        return [resultPrograms, resultActions, anomalyStatus]
    }

    public getNextPrediction(currentDOM:DOMState, allowResynthesize:boolean = true):[Program[], Action[]]{
        //TODO:ablation-incremental
        // this.cachedRewriteUnits = []
        // this.previousCorrectRewriteUnits = []
        // this.previousCorrect = false
       // console.log("Cached predictions num: " + this.cachedRewriteUnits.length + " at action length " + this.actions.length)
        //update for fault-recover
        // if(this.actions.length === 3194){
        //     DEBUG.on = true
        // }
        let originLastCachedRewriteUnits = this.lastCachedRewriteUnits
        this.lastCachedRewriteUnits = this.cachedRewriteUnits
        this.tmpWorklistToCombine = []


        //we push DOM to our synthesizer, but we should pop it later because we don't want it as a recorded thing.
        this.doms.push(currentDOM)
        let newRewriteUnits:NoRepeatWorkListArray = new NoRepeatWorkListArray()
        let predictions:NoRepeatActionArray = new NoRepeatActionArray()
        GlobalRunningEnv.init(this.actions, this.doms,this.inputData)

        //first test if previous programs can be used to generate prediction
        //here we will generate predictions UNTIL it reaches NonScrape action or no action -- optimize for scraping in bulk
        for(let p of this.previousCorrectRewriteUnits){
            let runningState:RunningState = Interpreter.evaluate(new RunningState(new DOMStateTrace(0,this.doms.length-1),new ActionTrace(0,this.actions.length-1),
                new ExecEnvironment()),p.program,false,true)
            if(isStrictPrefixActionTrace(new ActionTrace(0, this.actions.length-1),runningState.actionTrace)){
                newRewriteUnits.push(p.extendOneWithEndForLoop())
                let tmp:ActionTrace = <ActionTrace>runningState.actionTrace
                predictions.push(tmp.trace[tmp.trace.length-1])
            }
        }
        //if previous programs can be used to generate predictions, then use them. If some can generate and some can't, then probably there's new pattern - need to pay attention to.
        if(predictions.length > 0){
            this.previousCorrect = true
            //if previous programs can be used to generate prediction, then generate it
            if(DEBUG.procedureInfoDisplay){
                console.log("predicted by previous program")
            }
            this.previousCorrectRewriteUnits = newRewriteUnits.values()
            let programs:Program[] = []
            for(let r of newRewriteUnits.values()){
                programs.push(r.program)
            }
            //pop dom
            this.doms.pop()
            this.lastPredictions = predictions.values()
            return [programs
                ,predictions.values()]
        }
        //scrape in bulk - we don't want side effects
        if(!allowResynthesize){
            this.doms.pop()
            this.lastCachedRewriteUnits = originLastCachedRewriteUnits
            return [[],[]]
        }
        //if previous programs can't be used to generate predictions, then we need to synthesis from the cached worklists.
        this.previousCorrect = false
        this.previousCorrectRewriteUnits = []
        if(DEBUG.procedureInfoDisplay){
            console.log("predicted by newly generated program")
        }

        //if has previous cached worklist, then synthesis from there
        if(this.cachedRewriteUnits.length > 0) {
            let [cachedRewriteUnits, tmpRewriteUnits, tmpActions] = synthesize(this.doms, this.actions, this.inputData, this.cachedRewriteUnits)
            if (tmpRewriteUnits.length === 0 && this.cachedRewriteUnits.length !== 0) {
                if(DEBUG.procedureInfoDisplay){
                    console.log("No prediction, cached worklist maintained.")
                }

                //in this case, there's no new prediction available but has previous cached worklist. We synthesis from scratch -- only if action length < 300
                //initialize the plain workList Item
                let tmpCombinedWorklist = (this.actions.length < 30)? getInitWorklist(this.actions):[]
                let [t1,t2,t3] = synthesize(this.doms, this.actions,this.inputData, tmpCombinedWorklist)
                //deal with combining worklist
                let tmpCombinedWorklistNoRepeat:NoRepeatWorkListArray = new NoRepeatWorkListArray()
                if(cachedRewriteUnits.length !== 0){
                    for(let prevWorklist of cachedRewriteUnits){
                        tmpCombinedWorklistNoRepeat.push(prevWorklist)
                    }
                }
                else{
                    for(let prevWorklist of this.cachedRewriteUnits){
                        tmpCombinedWorklistNoRepeat.push(prevWorklist)
                    }
                }

                for(let curCombinedWorklist of t1){
                    tmpCombinedWorklistNoRepeat.push(curCombinedWorklist)
                }
                let tmpcachedRewriteUnits = tmpCombinedWorklistNoRepeat.values().sort(workListSortFunc)
                let tmpRewriteUnits = t2
                let tmpActions = t3

                //see if synthesized programs can generate new prediction
                if(tmpRewriteUnits.length > 0) {
                    //newly synthesized programs can generate new actions. For those can generate new actions,
                    //extend rewrite units by length 1 because when we reach here the last for loop can predict(if any)
                    if(DEBUG.procedureInfoDisplay){
                        console.log("newly generated programs can predict")
                    }

                    this.previousCorrectRewriteUnits = tmpRewriteUnits
                    this.previousCorrect = true
                    this.cachedRewriteUnits = cachedRewriteUnits
                    let tmpProgram: Program[] = []
                    for (let r of tmpRewriteUnits) {
                        tmpProgram.push(r.program)
                    }
                    //pop dom
                    this.doms.pop()
                    this.lastPredictions = tmpActions
                    return [tmpProgram, tmpActions]
                }
                else{
                    //if no result, then return empty
                    if(DEBUG.procedureInfoDisplay){
                        console.log("newly generated programs can't predict")
                    }

                    //pop dom
                    this.doms.pop()
                    this.lastPredictions = []
                    this.cachedRewriteUnits = tmpcachedRewriteUnits
                    return [[],[]]
                }
            }
            if(tmpRewriteUnits.length > 0){
                //in this case, there's new prediction available and has new cached rewrite units.
                if(DEBUG.procedureInfoDisplay){
                    console.log("newly generated programs can predict")
                }


                this.previousCorrectRewriteUnits = tmpRewriteUnits
                this.previousCorrect = true
                this.cachedRewriteUnits = cachedRewriteUnits
                let tmpProgram: Program[] = []
                for (let r of tmpRewriteUnits) {
                    tmpProgram.push(r.program)
                }
                //pop dom
                this.doms.pop()
                this.lastPredictions = tmpActions
                return [tmpProgram, tmpActions]
            }
            else{
                if(DEBUG.procedureInfoDisplay){
                    console.log("No prediction, cached worklist maintained.")
                }

                //in this case, there's no new prediction available but has previous cached worklist. We synthesis from scratch, but with previous worklist(they are also valid) -- do it only when action length < 30
                //initialize the plain workList Item
                let tmpCombinedWorklist = (this.actions.length < 30)? getInitWorklist(this.actions):[]

                let [t1,t2,t3] = synthesize(this.doms, this.actions,this.inputData, tmpCombinedWorklist)
                //deal with combining worklist
                let tmpCombinedWorklistNoRepeat:NoRepeatWorkListArray = new NoRepeatWorkListArray()
                for(let prevWorklist of this.tmpWorklistToCombine){
                    tmpCombinedWorklistNoRepeat.push(prevWorklist)
                }
                for(let curCombinedWorklist of t1){
                    tmpCombinedWorklistNoRepeat.push(curCombinedWorklist)
                }
                let cachedRewriteUnits = tmpCombinedWorklistNoRepeat.values().sort(workListSortFunc)
                let tmpRewriteUnits = t2
                let tmpActions = t3

                //see if synthesized programs can generate new prediction
                if(tmpRewriteUnits.length > 0) {
                    //newly synthesized programs can generate new actions. For those can generate new actions,
                    //extend rewrite units by length 1 because when we reach here the last for loop can predict(if any)
                    if(DEBUG.procedureInfoDisplay){
                        console.log("newly generated programs can predict")
                    }

                    this.previousCorrectRewriteUnits = tmpRewriteUnits
                    this.previousCorrect = true
                    this.cachedRewriteUnits = cachedRewriteUnits
                    let tmpProgram: Program[] = []
                    for (let r of tmpRewriteUnits) {
                        tmpProgram.push(r.program)
                    }
                    //pop dom
                    this.doms.pop()
                    this.lastPredictions = tmpActions
                    return [tmpProgram, tmpActions]
                }
                else{
                    //if no result, then return empty
                    if(DEBUG.procedureInfoDisplay){
                        console.log("newly generated programs can't predict")
                    }

                    //pop dom
                    this.doms.pop()
                    this.lastPredictions = []
                    this.cachedRewriteUnits = tmpRewriteUnits
                    return [[],[]]
                }
            }

        }
        else {
            //if there's no previous cached worklist, then we need to synthesis from scratch
            if(DEBUG.procedureInfoDisplay){
                console.log("No prediction and no cached worklist, synthesis from scratch.")
            }
            //initialize the plain workList Item
            let tmpCombinedWorklist = getInitWorklist(this.actions)
            let [t1,t2,t3] = synthesize(this.doms, this.actions,this.inputData, tmpCombinedWorklist)
            let cachedRewriteUnits = t1
            let tmpRewriteUnits = t2
            let tmpActions = t3

            //see if synthesized programs can generate new prediction
            if(tmpRewriteUnits.length > 0) {
                //newly synthesized programs can generate new actions. For those can generate new actions,
                //extend rewrite units by length 1 because when we reach here the last for loop can predict(if any)
                if(DEBUG.procedureInfoDisplay){
                    console.log("newly generated programs can predict")
                }

                this.previousCorrectRewriteUnits = tmpRewriteUnits
                this.previousCorrect = true
                this.cachedRewriteUnits = cachedRewriteUnits
                let tmpProgram: Program[] = []
                for (let r of tmpRewriteUnits) {
                    tmpProgram.push(r.program)
                }
                //pop dom
                this.doms.pop()
                this.lastPredictions = tmpActions
                return [tmpProgram, tmpActions]
            }
            else{
                //if no result, then return empty
                if(DEBUG.procedureInfoDisplay){
                    console.log("newly generated programs can't predict")
                }

                //pop dom
                this.doms.pop()
                this.lastPredictions = []
                return [[],[]]
            }
        }
        throw "shouldn't reach here - in getNextPrediction function"
        return [[],[]]

    }

    private static traverseProgram(program: Program, columnMapping: number[], actionList: string[], nextIndex: number): number {
        let dynamicNextIndex: number = nextIndex;
        program.index = dynamicNextIndex;
        for (let statement of program.content) {
            statement.index = dynamicNextIndex;
            if (statement instanceof Action) {
                if (statement instanceof ActionWithTarget) {
                    actionList[dynamicNextIndex] = statement.target.toString();
                }
                if (statement instanceof ScrapeText || statement instanceof ScrapeLink) {
                    statement.type = StatementFunctionType.Scrape;
                    columnMapping.push(dynamicNextIndex);
                } else if (statement instanceof Download || statement instanceof ExtractURL) {
                    statement.type = StatementFunctionType.Scrape;
                } else if (statement instanceof SendKeys || statement instanceof SendData) {
                    statement.type = StatementFunctionType.Input;
                } else if (statement instanceof Click) {
                    statement.type = StatementFunctionType.Click;
                } else if (statement instanceof GoBack) {
                    statement.type = StatementFunctionType.Navigate;
                }
                dynamicNextIndex++;
            } else if (statement instanceof LoopyStatement) {
                statement.type = StatementFunctionType.Control;
                dynamicNextIndex = this.traverseProgram(statement.loopBody, columnMapping, actionList, dynamicNextIndex + 1);
                if (statement instanceof WhileLoopWithClick) {
                    statement.endAction.index = dynamicNextIndex;
                    statement.endAction.type = StatementFunctionType.Navigate;
                    actionList[dynamicNextIndex] = statement.endAction.target.toString();
                    statement.loopBody.length += 3;
                    dynamicNextIndex += 3;
                }
            }
        }
        dynamicNextIndex++; // offset that accounts for the closing loop bracket
        program.length = dynamicNextIndex - program.index;
        program.isIndexed = true;
        return dynamicNextIndex;
    }

    private indexLastCachedProgram(programID: number) {
        if (this.previousCorrectRewriteUnits.length > 0 && !this.previousCorrectRewriteUnits[0].program.isIndexed) {
            this.lastColumnMappings = [];
            this.lastActionList = [];
            /*
             Due to potential deep copy issue, a statement's index in a previous program might be
             overwritten to another value while traversing a later one, if that same statement appears
             at a different index in the later program. This function is modified to only index a
             specified program now.
             */
            let thisProgram = this.previousCorrectRewriteUnits[programID].program;
            let thisColumnMapping: number[] = [];
            let thisActionList: string[] = [];
            BackendSynthesizer.traverseProgram(thisProgram, thisColumnMapping, thisActionList, 1);
            thisProgram.length--; // inverse offset since the outermost program has no closing bracket
            this.lastColumnMappings.push(thisColumnMapping);
            this.lastActionList.push(thisActionList);
        }
    }

    public interpretByIndex(programID: number, index: number, currentDOM: DOMState): string[] {
        if (programID >= 0 && programID < this.previousCorrectRewriteUnits.length) {
            this.indexLastCachedProgram(programID);
            let thisProgram = this.previousCorrectRewriteUnits[programID].program;
            if (index > 0 && index <= thisProgram.length) {
                let pending_highlight_xpath: string[] = [];
                let interpretedActions = Interpreter.interpret(new ExecEnvironment(), currentDOM, thisProgram);
                for (let action of interpretedActions) {
                    if (action.index === index) {
                        pending_highlight_xpath.push(action.target.toString());
                    }
                }
                return pending_highlight_xpath;
            }
        }
        return [];
    }

    public queryIndexByColumnID(programID: number, columnID: number): number {
        this.indexLastCachedProgram(programID);
        if (!(programID >= 0 && programID < this.lastColumnMappings.length
            && columnID >= 0 && columnID < this.lastColumnMappings[programID].length)) {
            return -1;
        }
        return this.lastColumnMappings[programID][columnID];
    }

    public queryColumnIDByIndex(programID: number, index: number): number {
        this.indexLastCachedProgram(programID);
        if (programID >= 0 && programID < this.lastColumnMappings.length) {
            for (let columnID: number = 0; columnID < this.lastColumnMappings[programID].length; columnID++) {
                if (this.lastColumnMappings[programID][columnID] === index) {
                    return columnID;
                }
            }
        }
        return -1;
    }

    public queryStatementByIndex(programID: number, index: number): Statement {
        if (programID >= 0 && programID < this.previousCorrectRewriteUnits.length) {
            this.indexLastCachedProgram(programID);
            let thisProgram = this.previousCorrectRewriteUnits[programID].program;
            if (index > 0 && index <= thisProgram.length) {
                let dynamicProgram: Program = thisProgram;
                while (true) {
                    for (let statement of dynamicProgram.content) {
                        if (statement instanceof WhileLoopWithClick) {
                            if (index === statement.endAction.index) {
                                return statement.endAction;
                            } else if (index >= statement.loopBody.index + statement.loopBody.length - 4
                                && index < statement.loopBody.index + statement.loopBody.length) {
                                return new IterateElement(DOMNode.constructFromString(""));
                            }
                        }
                        if (statement instanceof LoopyStatement && index >= statement.loopBody.index
                            && index < statement.loopBody.index + statement.loopBody.length) {
                            if (index === statement.loopBody.index + statement.loopBody.length - 1) {
                                return new IterateElement(DOMNode.constructFromString(""));
                            }
                            dynamicProgram = statement.loopBody;
                            break;
                        }
                        if (statement.index === index) {
                            return statement;
                        }
                    }
                }
            }
        }
        return new IterateElement(DOMNode.constructFromString("")); // invalid or not found statement
    }

    public queryFunctionTypeByIndex(programID: number, index: number): StatementFunctionType {
        return this.queryStatementByIndex(programID, index).type;
    }

    public getIndexDictionary(programID: number): { [index: number]: string } {
        if (programID >= 0 && programID < this.previousCorrectRewriteUnits.length) {
            this.indexLastCachedProgram(programID);
            let thisActionList = this.lastActionList[programID];
            let thisIndexDictionary: { [index: number]: string } = {};
            for (let index = 1; index <= thisActionList.length; index++) {
                if (thisActionList[index] !== undefined && this.queryFunctionTypeByIndex(programID, index) !== StatementFunctionType.Scrape) {
                    thisIndexDictionary[index] = this.variablePattern.test(thisActionList[index]) ?
                        "//" : thisActionList[index];
                }
            }
            return thisIndexDictionary;
        }
        return {};
    }

    public mergeQueryXpath(programID: number, queryXpath: string[]) {
        if (programID >= 0 && programID < this.previousCorrectRewriteUnits.length) {
            let indexDictionary: { [index: number]: string } = this.getIndexDictionary(programID);
            for (let index in indexDictionary) {
                if (indexDictionary[index].length > 2 && queryXpath.indexOf(indexDictionary[index]) === -1) {
                    queryXpath.push(indexDictionary[index]);
                }
            }
        }
    }
}

function getInitWorklist(actions:Action[]){
    //initialize the plain workList Item
    let initProgram = new Program(actions)
    let domStatesVec:DOMStateTrace[] = []
    let actionTraceVec:ActionTrace[] = []
    for(let i = 0; i < actions.length; ++i){
        domStatesVec.push(new DOMStateTrace(i, i))
    }

    for(let i = 0; i < actions.length; ++i){
        actionTraceVec.push(new ActionTrace(i, i))
    }
    let tmpCombinedWorklist:RewriteWorklistUnit[] = []
    tmpCombinedWorklist.push(new RewriteWorklistUnit(initProgram, domStatesVec, actionTraceVec, 0))
    return tmpCombinedWorklist
}

function workListSortFunc(a:RewriteWorklistUnit, b:RewriteWorklistUnit){
    if(a.program.blocks.length > b.program.blocks.length){
        return 1
    }
    if(a.program.blocks.length < b.program.blocks.length){
        return -1
    }
    return 0
}